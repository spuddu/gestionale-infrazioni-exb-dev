import { type ImmutableObject } from 'jimu-core'

export interface Config {
  serviceUrl?: string
  parentTableUrl?: string
  title?: string
}

export type IMConfig = ImmutableObject<Config>
