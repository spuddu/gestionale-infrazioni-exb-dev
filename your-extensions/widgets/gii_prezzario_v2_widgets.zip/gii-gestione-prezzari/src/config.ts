import { type ImmutableObject } from 'jimu-core'

export interface Config {
  prezzariUrl?: string
  vociUrl?: string
  analisiUrl?: string
  title?: string
}

export type IMConfig = ImmutableObject<Config>
