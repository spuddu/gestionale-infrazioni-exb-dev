PACCHETTO NOTA SPESE / PREZZARIO V2

Contenuto:
- gii-editing-ti (modificato)
- gii-gestione-prezzari
- gii-gestione-voci-prezzario
- gii-gestione-prezzario-interno
- gii-gestione-analisi-prezzario-interno
- gii-gestione-ns-parametri

LOGICA:
- prezzario ufficiale regionale versionato
- una sola versione attiva per volta
- voci interne del Consorzio come eccezione
- analisi voci interne per categorie regionali: MANODOPERA / NOLO / TRASPORTO / MATERIALI
- tab Nota spese del cw editing per le stesse categorie

TABELLE AGOL ATTESE:
1) GII_PREZZARI_CARICATI
   campi minimi: codice_prezzario (text), anno_prezzario (short), descrizione (text), attivo (short), data_import (date), num_voci (long), num_analisi (long), note (text)
2) GII_PREZZARIO_VOCI
   campi minimi: prezzario_codice (text), anno_prezzario (short), origine_voce (text), codice_voce (text), descrizione (text), unita_misura (text), prezzo_unitario (double), famiglia (text), capitolo (text), sottocapitolo (text), categoria_default (text), selezionabile (short), attivo (short)
3) GII_PREZZARIO_ANALISI
   campi minimi: prezzario_codice (text), codice_analisi (text), codice_elemento (text), quantita (double), prezzo_unitario (double), importo (double)
4) GII_PREZZARIO_INTERNO
   campi minimi: codice_voce (text), descrizione (text), unita_misura (text), prezzo_unitario (double), categoria_default (text), attivo (short), note (text)
5) GII_ANALISI_PREZZARIO_INTERNO
   campi minimi: codice_voce_parent (text), categoria_costo (text), codice_riferimento (text), descrizione (text), unita_misura (text), quantita (double), prezzo_unitario (double), importo (double), ordine (long), note (text)
6) GII_PARAMETRI_NOTA_SPESE
   campi minimi: codice_parametro (text), descrizione (text), anno_riferimento (short), valore_percentuale (double), attivo (short), data_validita_da (date), data_validita_a (date), note (text)
7) GII_NOTA_SPESE_DETTAGLIO
   campi minimi: parent_globalid (guid/text se non disponibile guid), categoria_costo (text), origine_voce_snapshot (text), codice_voce_snapshot (text), descrizione_snapshot (text), unita_misura_snapshot (text), prezzo_unitario_snapshot (double), quantita (double), importo_riga (double), anno_prezzario_snapshot (short), ordine (long), note (text)

CAMPI CONSIGLIATI SUL LAYER RAPPORTI:
- GlobalID
- ns_totale_manodopera (double)
- ns_totale_noli (double)
- ns_totale_trasporti (double)
- ns_totale_materiali (double)
- ns_spese_generali_perc (double)
- ns_importo_spese_generali (double)
- ns_totale_complessivo (double)
- ns_ricalcolata_il (date)

RETROCOMPATIBILITÀ:
Se nel layer rapporti esistono solo i vecchi campi ns_totale_personale / ns_totale_mezzi / ns_totale_materiali, il widget prova comunque a valorizzarli con:
- personale = manodopera
- mezzi = noli + trasporti
- materiali = materiali
