/** @jsx jsx */
/** @jsxFrag React.Fragment */
import { React, jsx } from 'jimu-core'
import { type AllWidgetSettingProps } from 'jimu-for-builder'
import { defaultConfig, type IMConfig } from '../config'

const P = {
  wrap: { padding: '0 12px 32px', fontSize: 13, background: '#1a1f2e', minHeight: '100%', color: '#e5e7eb' } as React.CSSProperties,
  sec: { fontSize: 11, fontWeight: 700, color: '#c4b5fd', textTransform: 'uppercase' as const, letterSpacing: 1.2, borderBottom: '1px solid rgba(255,255,255,0.10)', paddingBottom: 6, marginBottom: 14, marginTop: 22 } as React.CSSProperties,
  lbl: { fontSize: 11.5, fontWeight: 600, color: '#d1d5db', display: 'block', marginBottom: 4, marginTop: 10 } as React.CSSProperties,
  hint: { fontSize: 10.5, color: '#a0aec0', marginTop: 3, lineHeight: 1.4 } as React.CSSProperties,
  row2: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 } as React.CSSProperties,
  inp: { width: '100%', padding: '5px 8px', fontSize: 12, border: '1px solid rgba(255,255,255,0.15)', borderRadius: 6, outline: 'none', boxSizing: 'border-box' as const, background: 'rgba(255,255,255,0.07)', color: '#e5e7eb' } as React.CSSProperties,
  check: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#d1d5db', cursor: 'pointer', marginTop: 8 } as React.CSSProperties
}

function Inp (p: { value: string | number; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return <input type={p.type || 'text'} value={p.value} onChange={e => p.onChange(e.target.value)} placeholder={p.placeholder} style={P.inp} />
}

function NumInp (p: { value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number }) {
  return <input type='number' value={p.value} min={p.min} max={p.max} step={p.step || 1} onChange={e => p.onChange(Number(e.target.value))} style={P.inp} />
}

function ColInp (p: { value: string; onChange: (v: string) => void }) {
  const hexVal = /^#[0-9a-fA-F]{3,8}$/.test(p.value) ? p.value : '#1d4ed8'
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
      <input type='color' value={hexVal} onChange={e => p.onChange(e.target.value)}
        style={{ width: 32, height: 28, padding: 2, border: '1px solid rgba(255,255,255,0.15)', borderRadius: 6, cursor: 'pointer', background: 'transparent', flexShrink: 0 }} />
      <input type='text' value={p.value} onChange={e => p.onChange(e.target.value)} placeholder='#rrggbb o rgba(...)' style={{ ...P.inp, flex: 1, fontSize: 11 }} />
    </div>
  )
}

function Check (p: { value: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label style={P.check}>
      <input type='checkbox' checked={p.value} onChange={e => p.onChange(e.target.checked)} />
      {p.label}
    </label>
  )
}

export default function Setting (props: AllWidgetSettingProps<IMConfig>) {
  const cfgSrc: any = props.config as any
  const cfg: any = {
    ...defaultConfig,
    ...(cfgSrc?.asMutable ? cfgSrc.asMutable({ deep: true }) : cfgSrc?.toJS ? cfgSrc.toJS() : (cfgSrc || {}))
  }

  const update = (key: string, value: any) => {
    props.onSettingChange({
      id: props.id,
      config: props.config.set ? props.config.set(key as any, value) : ({ ...cfg, [key]: value } as any)
    })
  }

  React.useEffect(() => {
    if ((props as any).useDataSourcesEnabled || ((props as any).useDataSources?.length || 0) > 0) {
      props.onSettingChange({ id: props.id, useDataSources: [] as any, useDataSourcesEnabled: false as any })
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div style={P.wrap}>
      <div style={P.sec}>Contenuto</div>
      <label style={P.lbl}>Titolo</label>
      <Inp value={cfg.title} onChange={v => update('title', v)} />
      <label style={P.lbl}>Sottotitolo</label>
      <Inp value={cfg.subtitle} onChange={v => update('subtitle', v)} />

      <div style={P.sec}>Titolo pagina comune</div>
      <div style={P.hint}>Titolo, icona e descrizione sono letti dalla card della Home associata alla pagina.</div>
      <label style={{ ...P.lbl, display:'flex', alignItems:'center', gap:8 }}><input type='checkbox' checked={cfg.showTitleSubtitle !== false} onChange={e => update('showTitleSubtitle', e.target.checked)} /> Mostra sottotitolo / descrizione</label>
      <label style={{ ...P.lbl, display:'flex', alignItems:'center', gap:8 }}><input type='checkbox' checked={cfg.showTitleDivider !== false} onChange={e => update('showTitleDivider', e.target.checked)} /> Mostra separatore sotto il titolo</label>
      <div style={P.row2}>
        <div><label style={P.lbl}>Dimensione titolo</label><NumInp value={Number(cfg.pageTitleFontSize ?? defaultConfig.pageTitleFontSize)} min={12} max={40} onChange={v => update('pageTitleFontSize', v)} /></div>
        <div><label style={P.lbl}>Dimensione icona</label><NumInp value={Number(cfg.titleIconSize ?? defaultConfig.titleIconSize)} min={12} max={48} onChange={v => update('titleIconSize', v)} /></div>
        <div><label style={P.lbl}>Dimensione descrizione</label><NumInp value={Number(cfg.pageTitleDescriptionFontSize ?? defaultConfig.pageTitleDescriptionFontSize)} min={10} max={24} onChange={v => update('pageTitleDescriptionFontSize', v)} /></div>
        <div><label style={P.lbl}>Spessore separatore (0 = nascosto)</label><NumInp value={Number(cfg.titleDividerWidth ?? defaultConfig.titleDividerWidth)} min={0} max={8} onChange={v => update('titleDividerWidth', v)} /></div>
      </div>
      <label style={P.lbl}>Colore descrizione sotto il separatore</label>
      <ColInp value={String(cfg.pageTitleDescriptionColor || defaultConfig.pageTitleDescriptionColor)} onChange={v => update('pageTitleDescriptionColor', v)} />
      <label style={P.lbl}>Colore separatore</label>
      <ColInp value={String(cfg.titleDividerColor || defaultConfig.titleDividerColor)} onChange={v => update('titleDividerColor', v)} />

      <div style={P.sec}>Query</div>
      <label style={P.lbl}>Where clause aggiuntiva</label>
      <Inp value={cfg.whereClause || '1=1'} onChange={v => update('whereClause', v)} placeholder='1=1' />
      <div style={P.hint}>Il report parte sempre dalle pratiche consultabili dall’utente collegato. Questa clausola serve solo per restringere ulteriormente i risultati.</div>
      <div style={P.row2}>
        <div>
          <label style={P.lbl}>Limite record</label>
          <NumInp value={Number(cfg.pageSize || 2000)} min={100} step={100} onChange={v => update('pageSize', v)} />
        </div>
        <div>
          <label style={P.lbl}>Righe per pagina</label>
          <NumInp value={Number(cfg.tableRows || 25)} min={5} step={5} onChange={v => update('tableRows', v)} />
        </div>
      </div>
      <label style={P.lbl}>Soglia pratiche ferme, giorni</label>
      <NumInp value={Number(cfg.staleDays || 15)} min={1} onChange={v => update('staleDays', v)} />
      <Check value={cfg.showTechnicalInfo === true} onChange={v => update('showTechnicalInfo', v)} label='Mostra informazioni tecniche sull’ambito dati' />

      <div style={P.sec}>Spaziatura</div>
      <div style={P.hint}>Valori in pixel. Il padding esterno separa il pannello dai bordi del custom widget; il padding interno regola lo spazio tra il bordo del pannello e il suo contenuto.</div>
      <label style={P.lbl}>Padding esterno</label>
      <div style={P.row2}>
        <div>
          <label style={P.lbl}>Alto</label>
          <NumInp value={Number(cfg.outerPaddingTop ?? defaultConfig.outerPaddingTop)} min={0} max={100} onChange={v => update('outerPaddingTop', v)} />
        </div>
        <div>
          <label style={P.lbl}>Destro</label>
          <NumInp value={Number(cfg.outerPaddingRight ?? defaultConfig.outerPaddingRight)} min={0} max={100} onChange={v => update('outerPaddingRight', v)} />
        </div>
        <div>
          <label style={P.lbl}>Basso</label>
          <NumInp value={Number(cfg.outerPaddingBottom ?? defaultConfig.outerPaddingBottom)} min={0} max={100} onChange={v => update('outerPaddingBottom', v)} />
        </div>
        <div>
          <label style={P.lbl}>Sinistro</label>
          <NumInp value={Number(cfg.outerPaddingLeft ?? defaultConfig.outerPaddingLeft)} min={0} max={100} onChange={v => update('outerPaddingLeft', v)} />
        </div>
      </div>
      <label style={P.lbl}>Padding interno pannello</label>
      <div style={P.row2}>
        <div>
          <label style={P.lbl}>Alto</label>
          <NumInp value={Number(cfg.panelPaddingTop ?? defaultConfig.panelPaddingTop)} min={0} max={100} onChange={v => update('panelPaddingTop', v)} />
        </div>
        <div>
          <label style={P.lbl}>Destro</label>
          <NumInp value={Number(cfg.panelPaddingRight ?? defaultConfig.panelPaddingRight)} min={0} max={100} onChange={v => update('panelPaddingRight', v)} />
        </div>
        <div>
          <label style={P.lbl}>Basso</label>
          <NumInp value={Number(cfg.panelPaddingBottom ?? defaultConfig.panelPaddingBottom)} min={0} max={100} onChange={v => update('panelPaddingBottom', v)} />
        </div>
        <div>
          <label style={P.lbl}>Sinistro</label>
          <NumInp value={Number(cfg.panelPaddingLeft ?? defaultConfig.panelPaddingLeft)} min={0} max={100} onChange={v => update('panelPaddingLeft', v)} />
        </div>
      </div>

      <div style={P.sec}>Aspetto schede</div>
      <label style={P.lbl}>Radius schede (px)</label>
      <NumInp value={Number(cfg.cardRadius ?? defaultConfig.cardRadius)} min={0} max={100} onChange={v => update('cardRadius', v)} />

      <div style={P.sec}>Colori</div>
      <label style={P.lbl}>Colore accento</label>
      <ColInp value={cfg.accentColor || '#b79ffe'} onChange={v => update('accentColor', v)} />
      <label style={P.lbl}>Sfondo pannello</label>
      <ColInp value={cfg.panelBg || 'rgba(11,26,48,0.92)'} onChange={v => update('panelBg', v)} />
      <label style={P.lbl}>Sfondo card</label>
      <ColInp value={cfg.cardBg || 'rgba(255,255,255,0.08)'} onChange={v => update('cardBg', v)} />
      <label style={P.lbl}>Bordo card</label>
      <ColInp value={cfg.cardBorder || 'rgba(255,255,255,0.14)'} onChange={v => update('cardBorder', v)} />
      <label style={P.lbl}>Testo</label>
      <ColInp value={cfg.textColor || '#ffffff'} onChange={v => update('textColor', v)} />
      <label style={P.lbl}>Testo secondario</label>
      <ColInp value={cfg.mutedColor || 'rgba(255,255,255,0.70)'} onChange={v => update('mutedColor', v)} />
    </div>
  )
}
