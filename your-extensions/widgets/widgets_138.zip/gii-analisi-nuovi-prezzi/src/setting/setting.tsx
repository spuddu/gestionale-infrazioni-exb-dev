/** @jsx jsx */
/** @jsxFrag React.Fragment */
import { React, jsx } from 'jimu-core'
import type { AllWidgetSettingProps } from 'jimu-for-builder'
import type { IMConfig } from '../config'

const box: React.CSSProperties = { padding: '12px', background: '#1a1f2e', minHeight: '100%', color: '#e5e7eb', boxSizing: 'border-box', overflowX: 'hidden' }
const section: React.CSSProperties = { marginTop: 12, padding: 10, border: '1px solid rgba(255,255,255,0.12)', borderRadius: 8, background: 'rgba(255,255,255,0.04)', boxSizing: 'border-box' }
const sectionTitle: React.CSSProperties = { fontSize: 12.5, fontWeight: 700, color: '#93c5fd', marginBottom: 8 }
const lbl: React.CSSProperties = { fontSize: 11.5, fontWeight: 600, color: '#d1d5db', display: 'block', marginBottom: 4, marginTop: 10 }
const inp: React.CSSProperties = { width: '100%', minWidth: 0, padding: '6px 8px', fontSize: 12, border: '1px solid rgba(255,255,255,0.15)', borderRadius: 6, outline: 'none', boxSizing: 'border-box', background: 'rgba(255,255,255,0.07)', color: '#e5e7eb' }
const colorRow: React.CSSProperties = { display: 'grid', gridTemplateColumns: '58px minmax(0, 1fr)', gap: 8, alignItems: 'center' }
const colorInp: React.CSSProperties = { width: 48, height: 34, padding: 2, border: '1px solid rgba(255,255,255,0.15)', borderRadius: 6, background: 'rgba(255,255,255,0.07)', boxSizing: 'border-box', cursor: 'pointer' }
const hint: React.CSSProperties = { fontSize: 10.5, color: '#a0aec0', marginTop: 4, lineHeight: 1.5 }

export default function Setting(props: AllWidgetSettingProps<IMConfig>) {
  const cfg: any = props.config || {}
  const titleColor = String(cfg.titleColor || '#1F4E79')
  const titleFontSize = Number(cfg.titleFontSize || 15)
  const sectionTitleColor = String(cfg.sectionTitleColor || '#1F4E79')
  const sectionTitleFontSize = Number(cfg.sectionTitleFontSize || 12.5)
  const toolbarLabelColor = String(cfg.toolbarLabelColor || '#1F4E79')
  const toolbarLabelFontSize = Number(cfg.toolbarLabelFontSize || 11.5)
  const detailCardBackgroundColor = String(cfg.detailCardBackgroundColor || '#f5f9ff')
  const recordsCardBackgroundColor = String(cfg.recordsCardBackgroundColor || '#f5f9ff')
  const set = (k: string, v: any) => props.onSettingChange({ id: props.id, config: (props.config as any)?.set ? (props.config as any).set(k, v) : { ...cfg, [k]: v } as any })
  return (
    <div style={box}>
      <div style={{ fontSize: 13, fontWeight: 700, color: '#93c5fd', marginBottom: 8 }}>Configurazione widget</div>

      <div style={section}>
        <div style={sectionTitle}>Titolo principale</div>

        <label style={lbl}>Titolo</label>
        <input style={inp} value={cfg.title || ''} onChange={(e) => set('title', e.target.value)} />

        <label style={lbl}>Colore titolo principale</label>
        <div style={colorRow}>
          <input style={colorInp} type='color' value={titleColor} onChange={(e) => set('titleColor', e.target.value)} aria-label='Colore titolo principale' />
          <input style={inp} value={titleColor} onChange={(e) => set('titleColor', e.target.value)} placeholder='#1F4E79' />
        </div>

        <label style={lbl}>Dimensione titolo principale (px)</label>
        <input style={inp} type='number' min={10} max={36} step={1} value={titleFontSize} onChange={(e) => set('titleFontSize', Number(e.target.value || 15))} />

        <label style={{ ...lbl, display: 'flex', alignItems: 'center', gap: 8 }}>
          <input type='checkbox' checked={cfg.showTitleSubtitle !== false} onChange={(e) => set('showTitleSubtitle', e.target.checked)} />
          Mostra sottotitolo / descrizione
        </label>
        <label style={lbl}>Colore descrizione sotto il separatore</label>
        <div style={colorRow}>
          <input style={colorInp} type='color' value={String(cfg.subtitleColor || '#475569')} onChange={(e) => set('subtitleColor', e.target.value)} aria-label='Colore descrizione' />
          <input style={inp} value={String(cfg.subtitleColor || '#475569')} onChange={(e) => set('subtitleColor', e.target.value)} />
        </div>
        <label style={lbl}>Dimensione descrizione sotto il separatore (px)</label>
        <input style={inp} type='number' min={10} max={30} step={1} value={Number(cfg.subtitleFontSize || Math.max(12, titleFontSize - 2))} onChange={(e) => set('subtitleFontSize', Number(e.target.value || 13))} />

        <label style={lbl}>Dimensione icona titolo (px)</label>
        <input style={inp} type='number' min={12} max={48} step={1} value={Number(cfg.titleIconSize || Math.max(22, titleFontSize + 6))} onChange={(e) => set('titleIconSize', Number(e.target.value || 22))} />

        <label style={{ ...lbl, display: 'flex', alignItems: 'center', gap: 8 }}>
          <input type='checkbox' checked={cfg.showTitleDivider !== false} onChange={(e) => set('showTitleDivider', e.target.checked)} />
          Mostra separatore sotto il titolo
        </label>
        <label style={lbl}>Colore separatore titolo</label>
        <div style={colorRow}>
          <input style={colorInp} type='color' value={String(cfg.titleDividerColor || titleColor)} onChange={(e) => set('titleDividerColor', e.target.value)} aria-label='Colore separatore titolo' />
          <input style={inp} value={String(cfg.titleDividerColor || titleColor)} onChange={(e) => set('titleDividerColor', e.target.value)} />
        </div>

        <label style={lbl}>Spessore separatore titolo (px; 0 = nascosto)</label>
        <input style={inp} type='number' min={0} max={8} step={1} value={Number(cfg.titleDividerWidth ?? 2)} onChange={(e) => set('titleDividerWidth', Math.max(0, Number(e.target.value || 0)))} />
      </div>

      <div style={section}>
        <div style={sectionTitle}>Etichette barra superiore</div>

        <label style={lbl}>Colore etichetta Nuovo Prezzo</label>
        <div style={colorRow}>
          <input style={colorInp} type='color' value={toolbarLabelColor} onChange={(e) => set('toolbarLabelColor', e.target.value)} aria-label='Colore etichetta barra superiore' />
          <input style={inp} value={toolbarLabelColor} onChange={(e) => set('toolbarLabelColor', e.target.value)} placeholder='#1F4E79' />
        </div>

        <label style={lbl}>Dimensione etichetta Nuovo Prezzo (px)</label>
        <input style={inp} type='number' min={10} max={24} step={0.5} value={toolbarLabelFontSize} onChange={(e) => set('toolbarLabelFontSize', Number(e.target.value || 11.5))} />

        <div style={hint}>Queste impostazioni si applicano all'etichetta sopra la combo di selezione del Nuovo Prezzo.</div>
      </div>

      <div style={section}>
        <div style={sectionTitle}>Titoli interni pannelli</div>

        <label style={lbl}>Colore titoli interni pannelli</label>
        <div style={colorRow}>
          <input style={colorInp} type='color' value={sectionTitleColor} onChange={(e) => set('sectionTitleColor', e.target.value)} aria-label='Colore titoli interni pannelli' />
          <input style={inp} value={sectionTitleColor} onChange={(e) => set('sectionTitleColor', e.target.value)} placeholder='#1F4E79' />
        </div>

        <label style={lbl}>Dimensione titoli interni pannelli (px)</label>
        <input style={inp} type='number' min={10} max={24} step={0.5} value={sectionTitleFontSize} onChange={(e) => set('sectionTitleFontSize', Number(e.target.value || 12.5))} />

        <div style={hint}>Queste impostazioni si applicano ai titoli dei pannelli interni del widget.</div>
      </div>

      <div style={section}>
        <div style={sectionTitle}>Schede inserimento e modifica</div>
        <label style={lbl}>Colore di sfondo</label>
        <div style={colorRow}>
          <input style={colorInp} type='color' value={detailCardBackgroundColor} onChange={(e) => set('detailCardBackgroundColor', e.target.value)} aria-label='Colore di sfondo delle schede inserimento e modifica' />
          <input style={inp} value={detailCardBackgroundColor} onChange={(e) => set('detailCardBackgroundColor', e.target.value)} placeholder='#f5f9ff' />
        </div>
        <div style={hint}>Imposta lo sfondo delle schede usate per creare o modificare la testata e le righe di analisi.</div>
      </div>

      <div style={section}>
        <div style={sectionTitle}>Scheda righe di analisi salvate</div>
        <label style={lbl}>Colore di sfondo</label>
        <div style={colorRow}>
          <input style={colorInp} type='color' value={recordsCardBackgroundColor} onChange={(e) => set('recordsCardBackgroundColor', e.target.value)} aria-label='Colore di sfondo della scheda righe di analisi salvate' />
          <input style={inp} value={recordsCardBackgroundColor} onChange={(e) => set('recordsCardBackgroundColor', e.target.value)} placeholder='#f5f9ff' />
        </div>
        <div style={hint}>Imposta lo sfondo della scheda in cui sono visualizzate le righe di analisi già salvate.</div>
      </div>

      <div style={section}>
        <div style={sectionTitle}>Tabelle</div>

        <label style={lbl}>URL tabella analisi nuovi prezzi</label>
        <input style={inp} value={cfg.serviceUrl || ''} onChange={(e) => set('serviceUrl', e.target.value)} placeholder='https://services2.arcgis.com/.../FeatureServer/0' />

        <label style={lbl}>URL tabella nuovi prezzi</label>
        <input style={inp} value={cfg.parentTableUrl || ''} onChange={(e) => set('parentTableUrl', e.target.value)} placeholder='https://services2.arcgis.com/.../FeatureServer/0' />

        <label style={lbl}>URL tabella articoli prezzario regionale</label>
        <input style={inp} value={cfg.regionalTableUrl || ''} onChange={(e) => set('regionalTableUrl', e.target.value)} placeholder='https://services2.arcgis.com/.../FeatureServer/0' />

        <label style={lbl}>URL tabella articoli prezzario interno</label>
        <input style={inp} value={cfg.internalTableUrl || ''} onChange={(e) => set('internalTableUrl', e.target.value)} placeholder='https://services2.arcgis.com/.../FeatureServer/0' />

        <label style={lbl}>URL tabella dati generali</label>
        <input style={inp} value={cfg.generalDataUrl || ''} onChange={(e) => set('generalDataUrl', e.target.value)} placeholder='https://services2.arcgis.com/.../FeatureServer/0' />
      </div>

      <div style={hint}>Questo widget gestisce l’intero workflow dei Nuovi Prezzi: creazione ELEMENTARE o ANALIZZATA, generazione automatica del codice NPxx_..., composizione con sorgenti REGIONALE / INTERNO / NUOVO PREZZO e lettura di UM / Super Capitoli / Capitoli / Sub Capitoli da GII_DATI_GENERALI.</div>
    </div>
  )
}
