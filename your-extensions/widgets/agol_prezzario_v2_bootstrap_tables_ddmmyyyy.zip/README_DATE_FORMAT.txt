In questa versione le celle data nei file Excel sono formattate come DD/MM/YYYY.
Il valore resta una vera data Excel, non testo.
