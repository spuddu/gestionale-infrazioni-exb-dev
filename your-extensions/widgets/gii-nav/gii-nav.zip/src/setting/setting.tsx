/** @jsx jsx */
/** @jsxFrag React.Fragment */
import { React, jsx, getAppStore } from 'jimu-core'
import { type AllWidgetSettingProps } from 'jimu-for-builder'
import { defaultConfig, type IMConfig, type NavItem } from '../config'

const P = {
  wrap:    { padding:'0 12px 32px', fontSize:13, background:'#1a1f2e', minHeight:'100%', color:'#e5e7eb' } as React.CSSProperties,
  sec:     { fontSize:11, fontWeight:700, color:'#93c5fd', textTransform:'uppercase' as const, letterSpacing:1.2, borderBottom:'1px solid rgba(255,255,255,0.10)', paddingBottom:6, marginBottom:14, marginTop:22, cursor:'pointer', display:'flex', justifyContent:'space-between', alignItems:'center' } as React.CSSProperties,
  lbl:     { fontSize:11.5, fontWeight:600, color:'#d1d5db', display:'block', marginBottom:4, marginTop:10 } as React.CSSProperties,
  hint:    { fontSize:10.5, color:'#a0aec0', marginTop:3, lineHeight:1.4 } as React.CSSProperties,
  row2:    { display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 } as React.CSSProperties,
  row3:    { display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8 } as React.CSSProperties,
  inp:     { width:'100%', padding:'5px 8px', fontSize:12, border:'1px solid rgba(255,255,255,0.15)', borderRadius:6, outline:'none', boxSizing:'border-box' as const, background:'rgba(255,255,255,0.07)', color:'#e5e7eb' } as React.CSSProperties,
  check:   { display:'flex', alignItems:'center', gap:8, fontSize:12, color:'#d1d5db', cursor:'pointer', marginTop:8 } as React.CSSProperties,
  cardBox: { border:'1px solid rgba(255,255,255,0.10)', borderRadius:10, padding:'10px 12px', marginBottom:8, background:'rgba(255,255,255,0.04)' } as React.CSSProperties,
}

// ── Micro-componenti ──────────────────────────────────────────────────────────
function Inp(p: { value:string|number; onChange:(v:string)=>void; type?:string; placeholder?:string }) {
  return <input type={p.type||'text'} value={p.value} onChange={e=>p.onChange(e.target.value)} placeholder={p.placeholder} style={P.inp}/>
}
function NumInp(p: { value:number; onChange:(v:number)=>void; min?:number; max?:number; step?:number; unit?:string }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:5 }}>
      <input type='number' value={p.value} min={p.min} max={p.max} step={p.step||1}
        onChange={e=>p.onChange(Number(e.target.value))} style={{ ...P.inp, width:68 }}/>
      {p.unit && <span style={{ fontSize:11, color:'#a0aec0', flexShrink:0 }}>{p.unit}</span>}
    </div>
  )
}
function ColInp(p: { value:string; onChange:(v:string)=>void }) {
  const hexVal = /^#[0-9a-fA-F]{3,8}$/.test(p.value) ? p.value : '#1d4ed8'
  return (
    <div style={{ display:'flex', alignItems:'center', gap:7 }}>
      <input type='color' value={hexVal} onChange={e=>p.onChange(e.target.value)}
        style={{ width:32, height:28, padding:2, border:'1px solid rgba(255,255,255,0.15)', borderRadius:6, cursor:'pointer', background:'transparent', flexShrink:0 }}/>
      <input type='text' value={p.value} onChange={e=>p.onChange(e.target.value)}
        placeholder='#rrggbb o rgba(...)' style={{ ...P.inp, flex:1, fontSize:11 }}/>
    </div>
  )
}
function Check(p: { value:boolean; onChange:(v:boolean)=>void; label:string }) {
  return (
    <label style={P.check}>
      <input type='checkbox' checked={p.value} onChange={e=>p.onChange(e.target.checked)}/>
      {p.label}
    </label>
  )
}
function Sel(p: { value:string; onChange:(v:string)=>void; options:Array<{value:string;label:string}> }) {
  return (
    <select value={p.value} onChange={e=>p.onChange(e.target.value)} style={{ ...P.inp, cursor:'pointer' }}>
      {p.options.map(o=><option key={o.value} value={o.value} style={{ background:'#1a1f2e', color:'#e5e7eb' }}>{o.label}</option>)}
    </select>
  )
}
function ImgUpload(p: { value:string; onChange:(v:string)=>void }) {
  const ref = React.useRef<HTMLInputElement|null>(null)
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
      {p.value && (
        <div style={{ width:64, height:64, borderRadius:10, overflow:'hidden', border:'1px solid rgba(255,255,255,0.15)', background:'#000', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <img src={p.value} alt='preview' style={{ width:'100%', height:'100%', objectFit:'contain' }}/>
        </div>
      )}
      <div style={{ display:'flex', gap:8, flexWrap:'wrap' as const }}>
        <button type='button' onClick={()=>ref.current?.click()}
          style={{ padding:'6px 14px', borderRadius:7, border:'1px solid rgba(147,197,253,0.4)', background:'rgba(59,130,246,0.15)', color:'#93c5fd', fontSize:12, fontWeight:600, cursor:'pointer' }}>
          📁 Scegli dal PC
        </button>
        {p.value && (
          <button type='button' onClick={()=>p.onChange('')}
            style={{ padding:'6px 12px', borderRadius:7, border:'1px solid rgba(252,165,165,0.4)', background:'rgba(239,68,68,0.12)', color:'#fca5a5', fontSize:12, fontWeight:600, cursor:'pointer' }}>
            ✕ Rimuovi
          </button>
        )}
        <input ref={ref} type='file' accept='image/*' style={{ display:'none' }}
          onChange={e=>{ const f=e.target.files?.[0]; if(!f) return; const r=new FileReader(); r.onload=()=>{ if(typeof r.result==='string') p.onChange(r.result) }; r.readAsDataURL(f); if(ref.current) ref.current.value='' }}/>
      </div>
      <div style={P.hint}>PNG, SVG o JPG. Salvato come base64 nella configurazione.</div>
    </div>
  )
}


// ── Selezione pagina ExB ──────────────────────────────────────────────────────
function PageSel(p: { value:string; onChange:(v:string)=>void }) {
  const pages = React.useMemo(() => {
    try {
      const state: any = getAppStore()?.getState?.()

      // In Builder: l'app che stai editando è qui (non l'app del Builder)
      const appConfig = state?.appStateInBuilder?.appConfig ?? state?.appConfig

      const rawPages: any = appConfig?.pages ?? {}
      const pagesMap: Record<string, any> =
        rawPages?.asMutable ? rawPages.asMutable({ deep: true }) :
        rawPages?.toJS ? rawPages.toJS() :
        rawPages

      const entries = Object.entries(pagesMap)
      if (entries.length === 0) return []

      return entries
        .filter(([, pg]: any) => pg?.isVisible !== false)
        .map(([pageId, pg]: [string, any]) => {
          const label = pg?.label || pg?.title || pg?.name || pageId

          // value = quello che conviene salvare per la navigazione (di solito pg.name, cioè lo "slug" in URL)
          const value =
            pg?.name ||
            appConfig?.historyLabels?.page?.[pageId] ||
            pageId

          return { value: String(value), label: String(label) }
        })
        .sort((a, b) => a.label.localeCompare(b.label, 'it'))
    } catch (e) {
      console.warn('GII Homepage: impossibile leggere le pagine', e)
      return []
    }
  }, [])

  if (pages.length === 0) {
    return (
      <div>
        <Inp value={p.value} onChange={p.onChange} placeholder='inserisci il nome/ID della pagina'/>
        <div style={{ ...P.hint, color:'#f87171', marginTop:4 }}>
          ⚠ Impossibile leggere le pagine dell'app. Inserisci manualmente il valore che vedi nell&apos;URL quando apri la pagina (es: .../page/NOME-PAGINA).
        </div>
      </div>
    )
  }

  return (
    <div>
      <select
        value={p.value}
        onChange={e=>p.onChange(e.target.value)}
        style={{ ...P.inp, cursor:'pointer' }}
      >
        <option value='' style={{ background:'#1a1f2e', color:'#9ca3af' }}>— seleziona una pagina —</option>
        {pages.map(pg=>(
          <option key={pg.value} value={pg.value} style={{ background:'#1a1f2e', color:'#e5e7eb' }}>
            {pg.label}
          </option>
        ))}
      </select>

      {p.value && <div style={{ fontSize:10, color:'#a0aec0', marginTop:3 }}>Target: {p.value}</div>}
      <div style={P.hint}>Scegli la pagina che si apre al click sulla card.</div>
    </div>
  )
}

const FONTS = [
  { value:"'Crimson Pro', Georgia, serif",           label:'Crimson Pro (serif)' },
  { value:"'Source Sans 3', 'Segoe UI', sans-serif", label:'Source Sans 3 (sans)' },
  { value:"Georgia, serif",                          label:'Georgia' },
  { value:"'Times New Roman', serif",                label:'Times New Roman' },
  { value:"'Trebuchet MS', sans-serif",              label:'Trebuchet MS' },
  { value:"'Palatino Linotype', serif",              label:'Palatino Linotype' },
  { value:"'Courier New', monospace",                label:'Courier New' },
  { value:"Impact, sans-serif",                      label:'Impact' },
]
const WEIGHTS = [300,400,500,600,700,800,900].map(w=>({
  value:String(w),
  label:`${w} — ${['Thin','Regular','Medium','SemiBold','Bold','ExtraBold','Black'][[300,400,500,600,700,800,900].indexOf(w)]}`
}))
const ROLE_OPTIONS = [
  {value:'*',label:'Tutti'},{value:'TR',label:'TR'},{value:'TI',label:'TI'},
  {value:'RZ',label:'RZ'},{value:'RI',label:'RI'},{value:'DT',label:'DT'},
  {value:'DA',label:'DA'},{value:'ADMIN',label:'ADMIN'}
]

export default function Setting(props: AllWidgetSettingProps<IMConfig>) {
  const cfg: any = { ...defaultConfig, ...(props.config as any) }
  const items: NavItem[] = Array.isArray(cfg.items) ? cfg.items.map((i:any)=>({...i})) : defaultConfig.items
  const [openItem, setOpenItem] = React.useState<string|null>(null)

  const set = (key:string, value:any) =>
    props.onSettingChange({ id:props.id, config:{ ...cfg, [key]:value } as any })
  const setItem = (idx:number, patch:Partial<NavItem>) =>
    set('items', items.map((it,i)=>i===idx?{...it,...patch}:it))
  const moveItem = (idx:number, dir:-1|1) => {
    const next=items.map(i=>({...i})); const t=idx+dir
    if(t<0||t>=next.length) return
    ;[next[idx].order,next[t].order]=[next[t].order,next[idx].order]
    set('items',next)
  }

  const sorted = [...items].sort((a,b)=>a.order-b.order)

  return (
    <div style={P.wrap}>

      {/* Layout */}
      <div style={P.sec}>⚙ Layout</div>
      <label style={P.lbl}>Orientamento</label>
      <Sel value={cfg.direction} onChange={v=>set('direction',v)} options={[
        {value:'vertical',label:'Verticale (sidebar)'},
        {value:'horizontal',label:'Orizzontale (toolbar)'}
      ]}/>
      <div style={P.row3}>
        <div><label style={P.lbl}>Gap</label><NumInp value={cfg.gap} onChange={v=>set('gap',v)} min={0} max={24} unit='px'/></div>
        <div><label style={P.lbl}>Bordi arrot.</label><NumInp value={cfg.itemBorderRadius} onChange={v=>set('itemBorderRadius',v)} min={0} max={30} unit='px'/></div>
        <div><label style={P.lbl}>Padding</label><NumInp value={cfg.itemPadding} onChange={v=>set('itemPadding',v)} min={4} max={30} unit='px'/></div>
      </div>
      <label style={P.lbl}>Font etichette</label>
      <Sel value={cfg.labelFont} onChange={v=>set('labelFont',v)} options={FONTS}/>
      <div style={P.row2}>
        <div><label style={P.lbl}>Dimensione</label><NumInp value={cfg.labelSize} onChange={v=>set('labelSize',v)} min={10} max={22} unit='px'/></div>
        <div><label style={P.lbl}>Peso</label><Sel value={String(cfg.labelWeight)} onChange={v=>set('labelWeight',Number(v))} options={WEIGHTS}/></div>
      </div>

      {/* Voci */}
      <div style={P.sec}>🔗 Voci di navigazione</div>
      {sorted.map((item, si) => {
        const ri = items.findIndex(it=>it.id===item.id)
        const isO = openItem===item.id
        return (
          <div key={item.id} style={{ ...{border:'1px solid rgba(255,255,255,0.10)',borderRadius:10,padding:'10px 12px',marginBottom:8,background:'rgba(255,255,255,0.04)'}, opacity:item.visible?1:0.55 }}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',cursor:'pointer',userSelect:'none' as const}}
              onClick={()=>setOpenItem(isO?null:item.id)}>
              <div style={{display:'flex',alignItems:'center',gap:8,minWidth:0}}>
                <div style={{width:12,height:12,borderRadius:3,background:item.colorBg,flexShrink:0,border:`1px solid ${item.colorAccent}`}}/>
                <span style={{fontWeight:600,fontSize:12,color:'#e5e7eb',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap' as const}}>{item.label}</span>
                {!item.visible && <span style={{fontSize:10,color:'#a0aec0',fontStyle:'italic',flexShrink:0}}>(nascosta)</span>}
              </div>
              <div style={{display:'flex',alignItems:'center',gap:3,flexShrink:0}}>
                {si>0 && <button type='button' onClick={e=>{e.stopPropagation();moveItem(ri,-1)}} style={{padding:'1px 5px',fontSize:11,border:'1px solid rgba(255,255,255,0.15)',borderRadius:4,background:'rgba(255,255,255,0.05)',color:'#d1d5db',cursor:'pointer'}}>↑</button>}
                {si<sorted.length-1 && <button type='button' onClick={e=>{e.stopPropagation();moveItem(ri,1)}} style={{padding:'1px 5px',fontSize:11,border:'1px solid rgba(255,255,255,0.15)',borderRadius:4,background:'rgba(255,255,255,0.05)',color:'#d1d5db',cursor:'pointer'}}>↓</button>}
                <span style={{fontSize:10,color:'#a0aec0',marginLeft:2}}>{isO?'▲':'▼'}</span>
              </div>
            </div>
            {isO && <div style={{marginTop:10,paddingTop:10,borderTop:'1px solid rgba(255,255,255,0.08)'}}>
              <Check value={item.visible} onChange={v=>setItem(ri,{visible:v})} label='Visibile'/>
              <label style={P.lbl}>Etichetta</label><Inp value={item.label} onChange={v=>setItem(ri,{label:v})}/>
              <label style={P.lbl}>Pagina di destinazione</label>
              <PageSel value={item.hashPage} onChange={v=>setItem(ri,{hashPage:v})}/>
              <div style={P.row2}>
                <div><label style={P.lbl}>Colore sfondo</label><ColInp value={item.colorBg} onChange={v=>setItem(ri,{colorBg:v})}/></div>
                <div><label style={P.lbl}>Colore accento</label><ColInp value={item.colorAccent} onChange={v=>setItem(ri,{colorAccent:v})}/></div>
                </div>
                <div style={P.row2}>
                <div><label style={P.lbl}>Sfondo a riposo</label><ColInp value={item.colorBgRest||'rgba(255,255,255,0.04)'} onChange={v=>setItem(ri,{colorBgRest:v})}/></div>
                <div><label style={P.lbl}>Sfondo hover</label><ColInp value={item.colorBgHover||`${item.colorBg}ee`} onChange={v=>setItem(ri,{colorBgHover:v})}/></div>
              </div>
              <label style={P.lbl}>Ruoli visibili</label>
              <div style={{display:'flex',flexWrap:'wrap' as const,gap:5,marginTop:4}}>
                {ROLE_OPTIONS.map(ro=>{
                  const isAll=ro.value==='*'
                  const checked=isAll?item.roles.includes('*'):(!item.roles.includes('*')&&item.roles.includes(ro.value))
                  return (
                    <label key={ro.value} style={{display:'flex',alignItems:'center',gap:4,fontSize:11,cursor:'pointer',
                      background:checked?'rgba(59,130,246,0.25)':'rgba(255,255,255,0.06)',
                      border:`1px solid ${checked?'#93c5fd':'rgba(255,255,255,0.12)'}`,
                      borderRadius:6,padding:'3px 8px',color:checked?'#93c5fd':'#9ca3af',userSelect:'none' as const}}>
                      <input type='checkbox' checked={checked} style={{display:'none'}} onChange={()=>{
                        let next=[...item.roles]
                        if(isAll){next=checked?[]:['*']}
                        else{if(next.includes('*'))next=[];if(checked)next=next.filter(r=>r!==ro.value);else next=[...next,ro.value]}
                        setItem(ri,{roles:next})
                      }}/>
                      {ro.label}
                    </label>
                  )
                })}
              </div>
            </div>}
          </div>
        )
      })}

      <div style={{marginTop:24,paddingTop:14,borderTop:'1px solid rgba(255,255,255,0.08)'}}>
        <button type='button'
          onClick={()=>{if(window.confirm('Ripristinare i valori predefiniti?')) props.onSettingChange({id:props.id,config:defaultConfig as any})}}
          style={{padding:'6px 14px',borderRadius:7,border:'1px solid rgba(252,165,165,0.4)',background:'rgba(239,68,68,0.10)',color:'#fca5a5',fontSize:12,cursor:'pointer',fontWeight:600}}>
          ↺ Ripristina predefiniti
        </button>
      </div>
    </div>
  )
}
