/** @jsx jsx */
/** @jsxFrag React.Fragment */
import { React, jsx, type AllWidgetProps, DataSourceComponent, DataSourceManager } from 'jimu-core'
import { JimuMapViewComponent, type JimuMapView } from 'jimu-arcgis'
import { Button } from 'jimu-ui'
import { createPortal } from 'react-dom'
import type { IMConfig, TabConfig } from '../config'
import { defaultConfig } from '../config'

type MsgKind = 'info' | 'ok' | 'err'
type Msg = { kind: MsgKind; text: string }

type SelState = {
  ds: any
  oid: number | null
  idFieldName: string
  data: any | null
  sig: string
}

function unwrapJsapiLayer (maybe: any) {
  return (maybe && (maybe.layer || maybe)) || null
}

// Caricamento moduli ArcGIS JS API (AMD) senza dipendenze extra.
function loadEsriModule<T = any> (path: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const req = (window as any).require
    if (!req) {
      reject(new Error('AMD require non disponibile'))
      return
    }
    try {
      req([path], (mod: T) => resolve(mod), (err: any) => reject(err))
    } catch (e) {
      reject(e)
    }
  })
}

// In Experience Builder, una Data View / Output Data Source può non esporre direttamente un FeatureLayer.
// Questa funzione prova più strade (DS corrente, DS da manager, DS padre) e, se serve, crea un FeatureLayer dal URL.
async function resolveFeatureLayerForAttachments (ds: any): Promise<any | null> {
  if (!ds) return null

  const candidates: any[] = []
  const push = (x: any) => {
    if (x && !candidates.includes(x)) candidates.push(x)
  }

  push(ds)

  try {
    const dm = DataSourceManager.getInstance()
    const byId = ds?.id ? dm.getDataSource(ds.id) : null
    push(byId)
    const belongId = ds?.belongToDataSource
    if (typeof belongId === 'string' && belongId) {
      push(dm.getDataSource(belongId))
    }
  } catch {
    // ignore
  }

  for (const c of candidates) {
    const cAny: any = c
    const l = unwrapJsapiLayer(
      (typeof cAny.getLayer === 'function' ? cAny.getLayer() : null) ??
      (typeof cAny.getJsApiLayer === 'function' ? cAny.getJsApiLayer() : null) ??
      (typeof cAny.getJSAPILayer === 'function' ? cAny.getJSAPILayer() : null) ??
      cAny.layer
    ) as any
    if (l && typeof l.queryAttachments === 'function') return l
  }

  // Fallback: crea un FeatureLayer a partire dal URL del DS (se presente)
  try {
    const dsAny: any = ds
    const url: any = dsAny?.getDataSourceJson?.()?.url ?? dsAny?.dataSourceJson?.url
    if (!url || typeof url !== 'string') return null
    const FeatureLayer = await loadEsriModule<any>('esri/layers/FeatureLayer')
    const fl = new FeatureLayer({ url })
    if (typeof fl?.load === 'function') await fl.load().catch(() => {})
    if (fl && typeof fl.queryAttachments === 'function') return fl
  } catch {
    // ignore
  }

  return null
}


function isFiniteNum (n: any): boolean {
  return typeof n === 'number' && Number.isFinite(n)
}

function isValidOfficePoint (lon: any, lat: any): boolean {
  if (!isFiniteNum(lon) || !isFiniteNum(lat)) return false
  // evita default 0,0 (non configurato)
  if (Number(lon) === 0 && Number(lat) === 0) return false
  // range WGS84
  if (Number(lon) < -180 || Number(lon) > 180) return false
  if (Number(lat) < -90 || Number(lat) > 90) return false
  return true
}

function makeWgs84Point (lon: number, lat: number): any {
  return { x: lon, y: lat, spatialReference: { wkid: 4326 } }
}

async function toWgs84Point (mapPoint: any): Promise<any | null> {
  if (!mapPoint) return null
  const sr = mapPoint?.spatialReference?.wkid
  if (sr === 4326) {
    const lon = isFiniteNum(mapPoint.longitude) ? mapPoint.longitude : mapPoint.x
    const lat = isFiniteNum(mapPoint.latitude) ? mapPoint.latitude : mapPoint.y
    if (!isFiniteNum(lon) || !isFiniteNum(lat)) return null
    return makeWgs84Point(Number(lon), Number(lat))
  }

  // WebMercator (3857/102100)
  if (sr === 3857 || sr === 102100) {
    try {
      const webMercatorUtils = await loadEsriModule<any>('esri/geometry/support/webMercatorUtils')
      const g = webMercatorUtils?.webMercatorToGeographic?.(mapPoint)
      if (g) return makeWgs84Point(Number(g.x), Number(g.y))
    } catch { /* ignore */ }
  }

  // Fallback: projection
  try {
    const SpatialReference = await loadEsriModule<any>('esri/geometry/SpatialReference')
    const projection = await loadEsriModule<any>('esri/geometry/projection')
    if (projection?.load) await projection.load()
    const out = projection?.project?.(mapPoint, new SpatialReference({ wkid: 4326 }))
    if (out) return makeWgs84Point(Number(out.x), Number(out.y))
  } catch { /* ignore */ }

  return null
}


function pickOidFromData (data: any, idFieldName: string) {
  if (!data) return null
  if (idFieldName && data[idFieldName] != null) return data[idFieldName]
  return data.OBJECTID ?? data.ObjectId ?? data.objectid ?? data.objectId ?? null
}

function norm (v: any): string {
  return String(v ?? '').trim().toLowerCase()
}



function normKey (v: any): string {
  // lowercase + remove diacritics + replace non-alphanum with spaces
  return String(v ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ')
}


// Survey (XLS) — req_point
const NORMA3_REQ_POINT = new Set([
  'Art12','Art27','Art28','Art30','Art31','Art32','Art33','Art34','Art35','Art36','Art37','Art39'
])

function parseMultiSelect (val: any): string[] {
  if (!val) return []
  if (Array.isArray(val)) return val.map(String)
  // Survey123 salva select_multiple spesso come stringa separata da spazio
  return String(val).split(/\s+/).filter(Boolean)
}

function computeReqPoint (attrs: Record<string, any>): 0 | 1 {
  const p = String(attrs?.norma15_parziale ?? '')
  const t = String(attrs?.norma15_totale ?? '')
  if (p === 'Art15.1' || p === 'Art15.2') return 1
  if (t === 'Art15.3' || t === 'Art15.4') return 1

  const norma3 = parseMultiSelect(attrs?.norma_violata3)
  if (norma3.some(v => NORMA3_REQ_POINT.has(v))) return 1
  return 0
}


function isEmptyValue (v: any): boolean {
  if (v == null) return true
  if (typeof v === 'string') return v.trim() === ''
  if (Array.isArray(v)) return v.length === 0
  return false
}

function escRe (s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function hasToken (hay: string, token: string): boolean {
  const h = normKey(hay)
  const t = normKey(token)
  if (!t) return false
  const re = new RegExp(`(^| )${escRe(t)}( |$)`)
  return re.test(h)
}

function findTipoSoggettoFieldName (ds: any): string | null {
  try {
    const schema = ds?.getSchema?.()
    const fields = schema?.fields || {}
    const names = Object.keys(fields)
    if (!names.length) return null

    const directCandidates = [
      'tipo_soggetto', 'TIPO_SOGGETTO',
      'tipoSoggetto', 'TipoSoggetto',
      'tipo_sogg', 'TIPO_SOGG',
      'tipo', 'TIPO'
    ]
    for (const c of directCandidates) {
      if (c && fields[c]) return c
    }

    // Cerca per alias/label
    for (const n of names) {
      const f = fields[n]
      const alias = norm(f?.alias || f?.label || f?.title || '')
      const nn = norm(n)
      if ((nn.includes('tipo') && nn.includes('sogg')) || alias.includes('tipo soggetto') || alias.includes('tipologia soggetto')) return n
    }

    // Fallback: primo campo che contiene entrambe le parole
    const loose = names.find(n => {
      const nn = norm(n)
      return nn.includes('tipo') && nn.includes('sogg')
    })
    return loose || null
  } catch {
    return null
  }
}

function resolveCodedValueLabel (ds: any, fieldName: string, raw: any): string | null {
  try {
    const schema = ds?.getSchema?.()
    const f = schema?.fields?.[fieldName]
    const coded = f?.domain?.codedValues
    if (!coded || !Array.isArray(coded)) return null
    for (const cv of coded) {
      const code = cv?.code
      // confronto "loose" (numero/stringa)
      if (code == raw) return String(cv?.name ?? '')
      if (String(code) === String(raw)) return String(cv?.name ?? '')
    }
    return null
  } catch {
    return null
  }
}

function classifyTipoSoggettoRobusto (raw: any, labelFromDomain: any): 'PF' | 'PG' | null {
  const sLabel = norm(labelFromDomain)
  const sRaw = norm(raw)

  // Priorità: label del dominio (se presente)
  const s = sLabel || sRaw
  if (!s) return null

  if (s.includes('fisica') || s == 'pf' || s.startsWith('pf ')) return 'PF'
  if (s.includes('giurid') || s == 'pg' || s.startsWith('pg ')) return 'PG'

  // Codici numerici comuni: 1=PF, 2=PG
  if (sRaw == '1') return 'PF'
  if (sRaw == '2') return 'PG'

  return null
}


function filterAttrsToLayerFields (attrs: Record<string, any>, layer: any) {
  const fields = (layer?.fields || []) as Array<{ name: string }>
  if (!fields.length) return attrs
  const allow = new Set(fields.map(f => String(f.name)))
  const out: Record<string, any> = {}
  for (const k of Object.keys(attrs)) {
    if (allow.has(k)) out[k] = attrs[k]
  }
  return out
}

async function refreshRootAndDerived (ds: any) {
  if (!ds) return
  let root = ds
  try { while (root && root.belongToDataSource) root = root.belongToDataSource } catch {}

  const list: any[] = []
  if (root) list.push(root)

  try {
    const derived = root?.getAllDerivedDataSources ? root.getAllDerivedDataSources() : []
    if (derived && derived.length) list.push(...derived)
  } catch {}

  for (const d of list) {
    try {
      const q = d.getCurrentQueryParams ? d.getCurrentQueryParams() : null
      if (d.clearSourceRecords) d.clearSourceRecords()
      if (d.addVersion) d.addVersion()
      if (d.load) {
        if (q) await d.load(q)
        else await d.load()
      }
    } catch {}
  }
}

function msgStyle (kind: MsgKind, fontSize: number): React.CSSProperties {
  const base: React.CSSProperties = { fontSize, lineHeight: 1.35, whiteSpace: 'normal' }
  if (kind === 'ok') return { ...base, color: '#1a7f37' }
  if (kind === 'err') return { ...base, color: '#b42318' }
  return { ...base, color: '#4b5563' }
}

function getUdsKey (uds: any, idx: number) {
  return String(
    uds?.dataSourceId ??
    uds?.mainDataSourceId ??
    uds?.rootDataSourceId ??
    uds?.outputDataSourceId ??
    `ds_${idx}`
  )
}

function DataSourceSelectionBridge (props: {
  widgetId: string
  uds: any
  dsKey: string
  watchFields: string[]
  onUpdate: (dsKey: string, state: SelState) => void
}) {
  const { widgetId, uds, dsKey, watchFields, onUpdate } = props

  // onDataSourceCreated: fornisce il DS appena disponibile, prima di qualsiasi selezione
  const onDsCreated = React.useCallback((ds: any) => {
    if (!ds) return
    const idFieldName = ds?.getIdField ? ds.getIdField() : 'OBJECTID'
    onUpdate(dsKey, { ds, oid: null, idFieldName, data: null, sig: 'ds_ready' })
  }, [dsKey, onUpdate])

  return (
    <DataSourceComponent
      useDataSource={uds}
      widgetId={widgetId}
      onDataSourceCreated={onDsCreated}
    >
      {(ds: any) => (
        <SelectionWatcher
          ds={ds}
          dsKey={dsKey}
          watchFields={watchFields}
          onUpdate={onUpdate}
        />
      )}
    </DataSourceComponent>
  )
}

function SelectionWatcher (props: {
  ds: any
  dsKey: string
  watchFields: string[]
  onUpdate: (dsKey: string, state: SelState) => void
}) {
  const { ds, dsKey, watchFields, onUpdate } = props

  React.useEffect(() => {
    try { ds?.setListenSelection?.(true) } catch {}
  }, [ds])

  const selected = ds?.getSelectedRecords?.() || []
  const r0 = selected.length ? selected[0] : null
  // Nota: in ExB il record selezionato può avere un subset di campi.
// Per il filtro PF/PG dobbiamo avere SEMPRE la tipologia soggetto: la ricaviamo in modo robusto dallo schema/dominio.
let data: any = r0?.getData ? r0.getData() : null

const tipoField = findTipoSoggettoFieldName(ds)
let tipoRaw: any = null
let tipoLabel: any = null
let tipoKind: any = null
try {
  if (tipoField && r0?.getFieldValue) tipoRaw = r0.getFieldValue(tipoField)
} catch {}

try {
  if (tipoField && tipoRaw != null) tipoLabel = resolveCodedValueLabel(ds, tipoField, tipoRaw)
} catch {}

tipoKind = classifyTipoSoggettoRobusto(tipoRaw, tipoLabel)

if (tipoField) {
  data = {
    ...(data || {}),
    __tipo_soggetto_field: tipoField,
    __tipo_soggetto_raw: tipoRaw,
    __tipo_soggetto_label: tipoLabel,
    __tipo_soggetto_kind: tipoKind
  }
}

  const idFieldName = ds?.getIdField ? ds.getIdField() : 'OBJECTID'
  const oidRaw = pickOidFromData(data, idFieldName)
  const oid = oidRaw != null ? Number(oidRaw) : null

  const sigParts: string[] = []
  sigParts.push(String(oid ?? ''))
  for (const f of watchFields) sigParts.push(String(data?.[f] ?? ''))
  const sig = sigParts.join('|')

  React.useEffect(() => {
    onUpdate(dsKey, {
      ds,
      oid: (oid != null && Number.isFinite(oid)) ? oid : null,
      idFieldName,
      data: (oid != null && Number.isFinite(oid)) ? data : null,
      sig
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dsKey, ds, idFieldName, sig])

  return null
}

function DetailRow (props: { label: string; value: any; labelSize: number; valueSize: number }) {
  return (
    <div style={{ 
      display: 'grid', 
      gridTemplateColumns: '200px 1fr', 
      gap: 12, 
      alignItems: 'baseline' 
    }}>
      <div style={{ fontSize: props.labelSize, color: '#6b7280', textAlign: 'left' }}>
        {props.label}
      </div>
      <div style={{ fontSize: props.valueSize, fontWeight: 600, wordBreak: 'break-word' }}>
        {props.value != null && props.value !== '' ? String(props.value) : '—'}
      </div>
    </div>
  )
}

/**
 * Dropdown custom zebrato:
 * - rende il menu in portal su <body> (non viene tagliato dal widget)
 * - decide automaticamente se aprire sopra o sotto
 * - applica la zebra dalle impostazioni
 */
function ZebraDropdown (props: {
  value: string
  options: string[]
  placeholder?: string
  disabled?: boolean
  onChange: (v: string) => void
  evenBg: string
  oddBg: string
  borderColor: string
  borderWidth: number
  radius: number
  fontSize: number
  // error highlight
  isError?: boolean
}) {
  const [open, setOpen] = React.useState(false)
  const [pos, setPos] = React.useState<any>(null)
  const rootRef = React.useRef<HTMLDivElement>(null)
  const menuRef = React.useRef<HTMLDivElement>(null)

  const safeOptions = Array.isArray(props.options) ? props.options : []
  const currentLabel = props.value ? props.value : (props.placeholder || '— seleziona —')

  const bw = Math.max(0, Number(props.borderWidth) || 0)
  const bc = props.borderColor || 'rgba(0,0,0,0.10)'
  const rowBorder = `${bw}px solid ${bc}`

  const computePos = React.useCallback(() => {
    const el = rootRef.current
    if (!el) return
    const btn = el.querySelector('button') as HTMLButtonElement | null
    const rect = (btn || el).getBoundingClientRect()

    const margin = 8
    const maxMenu = 280
    const below = window.innerHeight - rect.bottom - margin
    const above = rect.top - margin

    const openUp = below < 180 && above > below
    const maxHeightRaw = Math.min(maxMenu, Math.max(140, (openUp ? above : below) - 12))

    setPos({
      left: rect.left,
      width: rect.width,
      openUp,
      top: rect.bottom + 6,
      bottom: window.innerHeight - rect.top + 6,
      maxHeight: maxHeightRaw
    })
  }, [])

  React.useEffect(() => {
    if (!open) return
    computePos()

    const onDown = (e: any) => {
      const root = rootRef.current
      const menu = menuRef.current
      if (!root || !menu) return
      const t = e.target as any
      if (!root.contains(t) && !menu.contains(t)) setOpen(false)
    }
    const onKey = (e: any) => { if (e?.key === 'Escape') setOpen(false) }
    const onResize = () => computePos()
    const onScroll = () => computePos()

    document.addEventListener('mousedown', onDown, true)
    document.addEventListener('keydown', onKey, true)
    window.addEventListener('resize', onResize, true)
    window.addEventListener('scroll', onScroll, true)
    return () => {
      document.removeEventListener('mousedown', onDown, true)
      document.removeEventListener('keydown', onKey, true)
      window.removeEventListener('resize', onResize, true)
      window.removeEventListener('scroll', onScroll, true)
    }
  }, [open, computePos])

  const menu = open && !props.disabled && pos
    ? createPortal(
      <div
        ref={menuRef}
        style={{
          position: 'fixed',
          left: pos.left,
          width: pos.width,
          top: pos.openUp ? 'auto' : pos.top,
          bottom: pos.openUp ? pos.bottom : 'auto',
          zIndex: 200000,
          border: rowBorder,
          borderRadius: Math.max(0, Number(props.radius) || 0),
          overflow: 'hidden',
          boxShadow: '0 10px 30px rgba(0,0,0,0.12)',
          background: '#ffffff',
          maxHeight: pos.maxHeight,
          overflowY: 'auto'
        }}
      >
        <div
          onClick={() => { props.onChange(''); setOpen(false) }}
          style={{
            padding: '8px 10px',
            cursor: 'pointer',
            fontSize: props.fontSize,
            backgroundColor: props.evenBg || '#ffffff',
            borderBottom: rowBorder,
            opacity: 0.9
          }}
          title='Svuota selezione'
        >
          — seleziona —
        </div>

        {safeOptions.map((opt: string, idx: number) => {
          const isEven = idx % 2 === 0
          const bg = isEven ? (props.evenBg || '#f6f7f9') : (props.oddBg || '#ffffff')
          const isSel = String(opt) === String(props.value || '')
          return (
            <div
              key={`${opt}-${idx}`}
              onClick={() => { props.onChange(String(opt)); setOpen(false) }}
              style={{
                padding: '8px 10px',
                cursor: 'pointer',
                fontSize: props.fontSize,
                backgroundColor: bg,
                borderBottom: (idx === safeOptions.length - 1) ? 'none' : rowBorder,
                fontWeight: isSel ? 700 : 400
              }}
            >
              {String(opt)}
            </div>
          )
        })}
      </div>,
      document.body
    )
    : null

  const border = props.isError ? '1px solid #b42318' : '1px solid rgba(0,0,0,0.20)'

  return (
    <div ref={rootRef} style={{ position: 'relative', width: '100%' }}>
      <button
        type='button'
        disabled={!!props.disabled}
        onClick={() => {
          if (props.disabled) return
          setOpen(v => {
            const next = !v
            if (next) computePos()
            return next
          })
        }}
        style={{
          width: '100%',
          padding: '8px 10px',
          borderRadius: 8,
          border,
          background: props.disabled ? '#f3f4f6' : '#ffffff',
          color: props.disabled ? '#9ca3af' : '#111827',
          cursor: props.disabled ? 'not-allowed' : 'pointer',
          textAlign: 'left',
          display: 'flex',
          alignItems: 'center',
          gap: 10
        }}
      >
        <span style={{ flex: 1, fontSize: props.fontSize }}>{currentLabel}</span>
        <span style={{ fontSize: props.fontSize, opacity: 0.75 }}>▾</span>
      </button>
      {menu}
    </div>
  )
}

// domini (numeri come da tua nota)
const PRESA_DA_PRENDERE = 1

// ─────────────────────────── OVERLAY EDITING INLINE ──────────────────────────
// Versione semplificata dell'overlay di editing che vive dentro il widget Azioni.
// Per la versione completa (con mappa e tutte le tab) usare il widget gii-editing-ti
// sulla pagina dedicata.

function filterAttrsForLayer(attrs: Record<string, any>, layer: any): Record<string, any> {
  const fields = (layer?.fields || []) as Array<{ name: string }>
  if (!fields.length) return attrs
  const allow = new Set(fields.map((f: any) => String(f.name)))
  const out: Record<string, any> = {}
  for (const k of Object.keys(attrs)) {
    if (allow.has(k)) out[k] = attrs[k]
  }
  return out
}

async function resolveLayerForEdit(ds: any): Promise<any | null> {
  if (!ds) return null
  try {
    const raw = (ds as any)?.getLayer?.() || (ds as any)?.getJSAPILayer?.() || (ds as any)?.getJsApiLayer?.() || (ds as any)?.layer || null
    const resolved = await Promise.resolve(raw)
    const layer = (resolved && (resolved.layer || resolved)) || null
    if (layer && typeof layer.applyEdits === 'function') return layer
  } catch { }
  try {
    const dm = DataSourceManager.getInstance()
    const cds = ds?.id ? dm.getDataSource(ds.id) : null
    if (cds) {
      const raw = (cds as any)?.getLayer?.() || (cds as any)?.layer || null
      const resolved = await Promise.resolve(raw)
      const layer = (resolved && (resolved.layer || resolved)) || null
      if (layer && typeof layer.applyEdits === 'function') return layer
    }
  } catch { }
  return null
}

async function refreshDs(ds: any): Promise<void> {
  if (!ds) return
  let root = ds
  try { while (root?.belongToDataSource) root = root.belongToDataSource } catch { }
  const list: any[] = root ? [root] : []
  try {
    const derived = root?.getAllDerivedDataSources?.() || []
    if (derived?.length) list.push(...derived)
  } catch { }
  for (const d of list) {
    try {
      const q = d.getCurrentQueryParams?.() || null
      if (d.clearSourceRecords) d.clearSourceRecords()
      if (d.addVersion) d.addVersion()
      if (d.load) { if (q) await d.load(q); else await d.load() }
    } catch { }
  }
}


async function trySelectOid (ds: any, oid: number): Promise<void> {
  if (!ds || oid == null) return
  const id = Number(oid)
  const methods: Array<[string, any]> = [
    ['selectRecordsByIds', [ [id] ]],
    ['selectRecordById', [ id ]],
    ['setSelectedRecordIds', [ [id] ]],
    ['setSelectedIds', [ [id] ]]
  ]
  for (const [m, args] of methods) {
    try {
      if (typeof (ds as any)[m] === 'function') {
        await (ds as any)[m](...args)
        return
      }
    } catch { /* ignore */ }
  }
  // fallback: SelectionManager (best-effort)
  try {
    const sm = (DataSourceManager as any).getInstance?.()?.getSelectionManager?.()
    if (sm?.selectRecordByIds && ds?.id) sm.selectRecordByIds(ds.id, [id])
  } catch { /* ignore */ }
}


function InlineEditOverlay(props: {
  oid: number
  data: any
  ds: any
  idFieldName: string
  cfg: any   // editConfig
  ui: any
  onClose: (saved: boolean) => void
}) {
  const { oid, data, ds, idFieldName, cfg, ui, onClose } = props

  // Alias e schema dal DS (caricati una volta sola)
  const [aliasMap, setAliasMap] = React.useState<Record<string, string>>({})
  const [layerFields, setLayerFields] = React.useState<Array<{ name: string; type: string; domain?: any }>>([])
  const [aliasReady, setAliasReady] = React.useState(false)

  React.useEffect(() => {
    let cancelled = false
    const load = async () => {
      // Schema dal DS
      try {
        const schema = ds?.getSchema?.()
        const fobj = schema?.fields || {}
        const am: Record<string, string> = {}
        for (const name of Object.keys(fobj)) {
          const f = fobj[name]
          am[name] = String(f?.alias || f?.label || f?.title || name)
        }
        if (!cancelled && Object.keys(am).length) setAliasMap(am)
      } catch { }
      // Layer JSAPI per tipi e domini
      try {
        const raw = ds?.getLayer?.() || ds?.getJSAPILayer?.() || ds?.layer || null
        const resolved = await Promise.resolve(raw)
        const layer = (resolved && (resolved.layer || resolved)) || null
        const fields = (layer?.fields || []) as any[]
        if (fields.length && !cancelled) {
          const am: Record<string, string> = {}
          const lf: typeof layerFields = []
          for (const f of fields) {
            if (!f?.name) continue
            am[f.name] = String(f?.alias || f.name)
            lf.push({ name: f.name, type: f.type || '', domain: f.domain || null })
          }
          setAliasMap(am)
          setLayerFields(lf)
        }
      } catch { }
      if (!cancelled) setAliasReady(true)
    }
    load()
    return () => { cancelled = true }
  }, [ds])

  // Draft editing
  const [draft, setDraft] = React.useState<Record<string, any>>({ ...data })
  const [saving, setSaving] = React.useState(false)
  const [saveMsg, setSaveMsg] = React.useState<{ kind: 'ok' | 'err'; text: string } | null>(null)
  const [confirmCancel, setConfirmCancel] = React.useState(false)
  const [activeTab, setActiveTab] = React.useState<'anagrafica' | 'violazione'>('anagrafica')

  const updateDraft = (field: string, value: any) => setDraft(prev => ({ ...prev, [field]: value }))

  const handleSave = async () => {
    setSaving(true); setMsg(null)
    try {
      const layer = isEditMode ? await resolveLayerForEdit(ds) : await getLayerForCreate()
      if (!layer?.applyEdits) throw new Error('Layer non raggiungibile (applyEdits non disponibile).')

      const giiRole: any = (window as any).__giiUserRole || {}
      const initialAttrs = initialDataRef.current || {}

      // Geometria richiesta/di default
      let geom: any | null = null
      if (p.clickedPointWgs84) {
        geom = p.clickedPointWgs84
      } else if (!isEditMode && reqPoint === 0) {
        if (hasOffice) geom = makeWgs84Point(officeLon, officeLat)
      }

      if (!isEditMode && !geom) {
        if (reqPoint === 1) {
          throw new Error('Localizzazione obbligatoria: fai click in mappa per impostare il punto.')
        }
        throw new Error('Geometria non impostata: configura le coordinate ufficio nel setting oppure fai click in mappa.')
      }

      // Calcola campi derivati (coerenti con Survey)
      const normaV1 = tipoAbuso === 'parziale' ? n3parziale : (tipoAbuso === 'totale' ? n3totale : '')
      const normaV2 = norma1516 === 'Art16' ? 'Art16' : (norma1516 === 'Art17' && art17tipo ? art17tipo : norma1516)
      const supDich16_17 = norma1516 === 'Art16' ? (draft.sup_dichiarata_art16 ?? null) : (art17tipo === 'Art17.1' ? (draft.sup_dichiarata_art17_1 ?? null) : (draft.sup_dichiarata_art17_2 ?? null))
      const supIrr16_17  = norma1516 === 'Art16' || art17tipo === 'Art17.2' ? (draft.sup_irrigata_art16_17_2 ?? null) : (art17tipo === 'Art17.1' ? (draft.sup_irrigata_art17_1 ?? null) : null)

      const vArtAttrs: Record<string, number | null> = {}
      for (const [art, field] of Object.entries(NORMA3_TO_VFIELD)) {
        vArtAttrs[field] = norma3Set.has(art) ? 1 : null
      }

      const attrs: Record<string, any> = {
        ...(isEditMode ? initialAttrs : {}),
        // sistema
        origine_pratica: isEditMode ? (initialAttrs.origine_pratica ?? 2) : 2,
        stato_TI: isEditMode ? (initialAttrs.stato_TI ?? null) : 1,
        utente_loggato: isEditMode ? (initialAttrs.utente_loggato ?? String(giiRole.username || giiRole.userId || '')) : String(giiRole.username || giiRole.userId || ''),
        area_cod: isEditMode ? (initialAttrs.area_cod ?? String(giiRole.area || '')) : String(giiRole.area || ''),
        settore_cod: isEditMode ? (initialAttrs.settore_cod ?? String(giiRole.settore || '')) : String(giiRole.settore || ''),
        // dati generali
        tecnico_rilevatore: g('tecnico_rilevatore') || initialAttrs.tecnico_rilevatore || null,
        ufficio_zona: g('ufficio_zona') || initialAttrs.ufficio_zona || null,
        data_rilevazione: toTs(g('data_rilevazione')),
        // trasgressore
        tipologia_soggetto: tipoSogg || null,
        nome: (tipoSogg === 'PF' ? g('nome') : null) || null,
        cognome: (tipoSogg === 'PF' ? g('cognome') : null) || null,
        ragione_sociale: (tipoSogg === 'PG' ? g('ragione_sociale') : null) || null,
        codice_fiscale: (tipoSogg === 'PF' ? g('codice_fiscale') : null) || null,
        piva: (tipoSogg === 'PG' ? g('piva') : null) || null,
        via: g('via') || null,
        civico: g('civico') || null,
        citta: g('citta') || null,
        cap: g('cap') || null,
        email: g('email') || null,
        pec: g('pec') || null,
        telefono: g('telefono') || null,
        cellulare: g('cellulare') || null,
        // violazione art.15
        tipo_abuso: tipoAbuso || null,
        norma15_parziale: (tipoAbuso === 'parziale' ? n3parziale : null) || null,
        norma15_totale: (tipoAbuso === 'totale' ? n3totale : null) || null,
        norma_violata1: normaV1 || null,
        sup_dichiarata_art15: showSup15 ? toInt(g('sup_dichiarata_art15')) : null,
        sup_irrigata_art15: showSup15 ? toInt(g('sup_irrigata_art15')) : null,
        // violazione art.16/17
        norma16_17: norma1516 || null,
        art17_tipo: (norma1516 === 'Art17' ? art17tipo : null) || null,
        norma_violata2: normaV2 || null,
        sup_dichiarata_art17_1: norma1516 === 'Art17' && art17tipo === 'Art17.1' ? toInt(g('sup_dichiarata_art17_1')) : null,
        sup_dichiarata_art16: norma1516 === 'Art16' ? toInt(g('sup_dichiarata_art16')) : null,
        sup_dichiarata_art17_2: norma1516 === 'Art17' && art17tipo === 'Art17.2' ? toInt(g('sup_dichiarata_art17_2')) : null,
        sup_irrigata_art16_17_2: (norma1516 === 'Art16' || art17tipo === 'Art17.2') ? toInt(g('sup_irrigata_art16_17_2')) : null,
        sup_irrigata_art17_1: art17tipo === 'Art17.1' ? toInt(g('sup_irrigata_art17_1')) : null,
        sup_dichiarata_art16_17: toInt(supDich16_17 as any),
        sup_irrigata_art16_17: toInt(supIrr16_17 as any),
        // altre violazioni
        norma_violata3: g('norma_violata3') || null,
        ...vArtAttrs,
        // descrizione
        descrizione_fatti: g('descrizione_fatti') || null,
        circostanze: g('circostanze') || null,
        presenza_trasgressore: g('presenza_trasgressore') || null,
        // localizzazione
        descrizione_luogo: g('descrizione_luogo') || null,
        // fine compilazione
        data_firma: toTs(g('data_firma')),
        // req_point (utile anche lato feature)
        req_point: reqPoint
      }

      const idFieldName = String(ds?.getIdField?.() || layer?.objectIdField || 'OBJECTID')
      if (isEditMode) attrs[idFieldName] = Number(p.oid)

      const cleanAttrs = filterAttrsForLayer(attrs, layer)

      if (isEditMode) {
        const beforeRaw: Record<string, any> = { ...initialAttrs, [idFieldName]: Number(p.oid) }
        const beforeAttrs = filterAttrsForLayer(beforeRaw, layer)
        const changedFields = Object.keys(cleanAttrs).filter(k => {
          if (k === idFieldName) return false
          const a = toLogValue(beforeAttrs[k])
          const b = toLogValue(cleanAttrs[k])
          return a !== b
        }).map(k => ({ campo: k, precedente: beforeAttrs[k], nuovo: cleanAttrs[k] }))

        if (!changedFields.length && !geom) {
          setSaving(false)
          setMsg({ kind: 'ok', text: 'Nessuna modifica da salvare.' })
          return
        }

        const res = await layer.applyEdits({ updateFeatures: [{ attributes: cleanAttrs, ...(geom ? { geometry: geom } : {}) }] })
        const upd = res?.updateFeatureResults?.[0] || res?.updateResults?.[0] || null
        const err = upd?.error
        const ok = !err && (upd?.success === true || upd?.objectId != null || upd?.success == null)
        if (!ok) throw new Error(err ? `${err.code ?? ''}: ${err.message ?? ''}` : JSON.stringify(res))

        await refreshDs(ds)
        try { window.dispatchEvent(new CustomEvent('gii-force-refresh-selection')) } catch {}
        writeDynamicSelection({ oid: Number(p.oid), layerUrl: String(readDynamicSelection().layerUrl || cfg.motherLayerUrl || ''), idFieldName, data: { ...initialAttrs, ...cleanAttrs } })

        let logWarn = ''
        if (changedFields.length) {
          try {
            await writeFieldChangeLogs({
              parentGlobalId: initialAttrs.GlobalID ?? initialAttrs.globalid ?? initialAttrs.globalId ?? null,
              parentObjectId: Number(p.oid),
              ruolo: 'TI',
              area: giiRole.area || initialAttrs.area_cod || null,
              settore: giiRole.settore || initialAttrs.settore_cod || null,
              fase: 'TI',
              changes: changedFields
            })
          } catch (logErr: any) {
            logWarn = ` (log eventi: ${String(logErr?.message || logErr)})`
          }
        }

        initialDataRef.current = { ...initialAttrs, ...cleanAttrs }
        setMsg({ kind: 'ok', text: `Pratica modificata.${logWarn}` })
        setSaving(false)
        p.onSaved(Number(p.oid))
        return
      }

      const res = await layer.applyEdits({ addFeatures: [{ attributes: cleanAttrs, geometry: geom }] })
      const added = res?.addFeatureResults?.[0] || res?.addResults?.[0] || null
      const err = added?.error
      const ok = !err && (added?.objectId != null || added?.success === true || added?.success == null)
      if (!ok) throw new Error(err ? `${err.code ?? ''}: ${err.message ?? ''}` : JSON.stringify(res))

      const newOid = Number(added.objectId)
      await refreshDs(ds)
      await trySelectOid(ds, newOid)

      setMsg({ kind: 'ok', text: 'Pratica creata.' })
      setSaving(false)
      setTimeout(() => {
        setDraft({})
        initialDataRef.current = {}
        setMsg(null)
        p.onClearPoint()
        p.onSaved(newOid)
      }, 600)
    } catch (e: any) {
      setSaving(false)
      setMsg({ kind: 'err', text: `Errore: ${e?.message || String(e)}` })
    }
  }

  const [npTab, setNpTab] = React.useState<'anagrafica' | 'violazione' | 'allegati'>('anagrafica')
  const showDatiGen = p.showDatiGenerali

  const NP_TABS = [
    { id: 'anagrafica', label: 'Anagrafica' },
    { id: 'violazione', label: 'Violazione' },
    { id: 'allegati', label: 'Allegati' }
  ] as const

  const btnBase: React.CSSProperties = {
    padding: '7px 16px', borderRadius: 8, border: 'none',
    fontWeight: 700, fontSize: 13, cursor: saving ? 'not-allowed' : 'pointer'
  }

  const tabBtn = (id: string, label: string) => (
    <button key={id} type='button' onClick={() => setNpTab(id as any)} style={{
      padding: '6px 14px', borderRadius: 10, border: `1px solid ${npTab === id ? '#2f6fed' : 'rgba(0,0,0,0.12)'}`,
      background: npTab === id ? '#eaf2ff' : 'rgba(0,0,0,0.02)',
      color: npTab === id ? '#1d4ed8' : '#374151',
      fontWeight: 700, fontSize: 12, cursor: 'pointer', whiteSpace: 'nowrap'
    }}>{label}</button>
  )

  const geomStatus = React.useMemo(() => {
    if (p.clickedPointWgs84) return { kind: 'ok' as const, text: 'Punto impostato da click in mappa.' }
    if (reqPoint === 0 && hasOffice) return { kind: 'info' as const, text: 'Nessun click: userò il punto ufficio (default).' }
    if (reqPoint === 0 && !hasOffice) return { kind: 'err' as const, text: 'Nessun click e punto ufficio non configurato: fai click in mappa o imposta Lon/Lat ufficio nel setting.' }
    return { kind: 'err' as const, text: 'Localizzazione obbligatoria: fai click in mappa.' }
  }, [p.clickedPointWgs84, reqPoint, hasOffice])

  const praticaCode = isEditMode
    ? `${((initialDataRef.current?.origine_pratica === 2 || initialDataRef.current?.origine_pratica === '2') ? 'TI' : 'TR')}-${Number(p.oid ?? 0)}`
    : ''

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0 }}>

      {/* ── Toolbar ── */}
      <div style={{ flex: '0 0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        flexWrap: 'wrap', gap: 8, padding: '8px 0', borderBottom: '1px solid rgba(0,0,0,0.08)' }}>
        {isEditMode ? (
          <span style={{ fontWeight: 700, fontSize: 14 }}>✏️ Modifica pratica (TI){praticaCode ? <span style={{ color: '#2f6fed' }}> {praticaCode}</span> : null}</span>
        ) : (
          <span style={{ fontWeight: 700, fontSize: 14 }}>✚ Nuova pratica (TI)</span>
        )}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {msg && <span style={{ fontSize: 12, color: msg.kind === 'ok' ? '#1a7f37' : '#b42318' }}>{msg.text}</span>}
          <button type='button' disabled={saving} onClick={handleSave}
            style={{ ...btnBase, background: saving ? '#e5e7eb' : '#1a7f37', color: saving ? '#9ca3af' : '#fff' }}>
            {saving ? 'Salvataggio…' : '💾 Salva'}
          </button>
          <button type='button' disabled={saving} onClick={() => { setDraft({}); p.onClearPoint(); }}
            style={{ ...btnBase, background: '#fff', border: '1px solid rgba(0,0,0,0.18)', color: '#374151' }}>
            ↺ Pulisci
          </button>
        </div>
      </div>

      {/* ── Tab bar ── */}
      <div style={{ flex: '0 0 auto', display: 'flex', gap: 6, padding: '8px 0', flexWrap: 'wrap',
        borderBottom: '1px solid rgba(0,0,0,0.08)' }}>
        {NP_TABS.map(t => tabBtn(t.id, t.label))}
      </div>

      {/* ── Contenuto tab (scrollabile) ── */}
      <div style={{ flex: '1 1 auto', minHeight: 0, overflowY: 'auto', padding: '12px 2px' }}>

        {/* ANAGRAFICA (Dati generali + Trasgressore) */}
        {npTab === 'anagrafica' && (
          <div>
            {showDatiGen && (
              <div style={{ marginBottom: 14 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                  <span style={{ fontSize: 13, color: '#6b7280' }}>Dati generali (automatici)</span>
                </div>
                <div style={S.row3}>
                  <NpField label='Tecnico istruttore'>
                    <NpText value={g('tecnico_rilevatore')} onChange={() => {}} disabled/>
                  </NpField>
                  <NpField label='Ufficio di Zona'>
                    <NpText value={g('ufficio_zona')} onChange={() => {}} disabled/>
                  </NpField>
                  <NpField label='Data rilevazione'>
                    <NpText value={g('data_rilevazione')} onChange={() => {}} disabled/>
                  </NpField>
                </div>
              </div>
            )}

            <div style={{ ...S.hdr, marginTop: 6 }}>Trasgressore</div>

            <div style={{ ...S.row2, marginBottom: 12 }}>
              <NpField label='Tipologia soggetto'>
                <NpSel value={tipoSogg} onChange={v => set('tipologia_soggetto', v)} options={CHOICES.tipo_soggetto} disabled={saving}/>
              </NpField>
              <div/>
            </div>

            {tipoSogg === 'PF' && (
              <div style={S.row3}>
                <NpField label='Nome'><NpText value={g('nome')} onChange={v => set('nome', v)} disabled={saving}/></NpField>
                <NpField label='Cognome'><NpText value={g('cognome')} onChange={v => set('cognome', v)} disabled={saving}/></NpField>
                <NpField label='Codice fiscale'><NpText value={g('codice_fiscale')} onChange={v => set('codice_fiscale', v)} disabled={saving}/></NpField>
              </div>
            )}
            {tipoSogg === 'PG' && (
              <div style={S.row2}>
                <NpField label='Ragione sociale'><NpText value={g('ragione_sociale')} onChange={v => set('ragione_sociale', v)} disabled={saving}/></NpField>
                <NpField label='P. IVA'><NpText value={g('piva')} onChange={v => set('piva', v)} disabled={saving}/></NpField>
              </div>
            )}

            <div style={S.row3}>
              <NpField label='Via'><NpText value={g('via')} onChange={v => set('via', v)} disabled={saving}/></NpField>
              <NpField label='N. civico'><NpText value={g('civico')} onChange={v => set('civico', v)} disabled={saving}/></NpField>
              <NpField label='Città'><NpText value={g('citta')} onChange={v => set('citta', v)} disabled={saving}/></NpField>
            </div>
            <div style={S.row3}>
              <NpField label='CAP'><NpText value={g('cap')} onChange={v => set('cap', v)} disabled={saving}/></NpField>
              <NpField label='Telefono'><NpText value={g('telefono')} onChange={v => set('telefono', v)} disabled={saving}/></NpField>
              <NpField label='Cellulare'><NpText value={g('cellulare')} onChange={v => set('cellulare', v)} disabled={saving}/></NpField>
            </div>
            <div style={S.row2}>
              <NpField label='E-mail'><NpText value={g('email')} onChange={v => set('email', v)} disabled={saving}/></NpField>
              <NpField label='PEC'><NpText value={g('pec')} onChange={v => set('pec', v)} disabled={saving}/></NpField>
            </div>
          </div>
        )}

        {/* VIOLAZIONE (include descrizione/localizzazione/fine) */}
        {npTab === 'violazione' && (
          <div>
            <div style={{ padding: 10, borderRadius: 10, border: '1px solid rgba(0,0,0,0.10)', background: 'rgba(0,0,0,0.02)', marginBottom: 12 }}>
              <div style={{ fontWeight: 800, fontSize: 12, color: '#374151', marginBottom: 6 }}>
                Localizzazione (req_point = {reqPoint})
              </div>
              <div style={{ fontSize: 12, color: geomStatus.kind === 'ok' ? '#1a7f37' : (geomStatus.kind === 'err' ? '#b42318' : '#6b7280') }}>
                {geomStatus.text}
              </div>
              {p.clickedPointWgs84 && (
                <div style={{ marginTop: 6, display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 11, color: '#6b7280' }}>
                    Lon: {Number(p.clickedPointWgs84.x).toFixed(6)} — Lat: {Number(p.clickedPointWgs84.y).toFixed(6)}
                  </span>
                  <button type='button' onClick={p.onClearPoint} style={{
                    padding: '4px 10px', borderRadius: 10, border: '1px solid rgba(0,0,0,0.14)', background: '#fff',
                    fontSize: 11, fontWeight: 700, cursor: 'pointer'
                  }}>Rimuovi punto</button>
                </div>
              )}
            </div>

            <div style={S.hdr}>Art. 15 — Prelievo abusivo</div>
            <div style={S.row2}>
              <NpField label='Tipo di abuso'>
                <NpSel value={tipoAbuso} onChange={v => { set('tipo_abuso', v); set('norma15_parziale', ''); set('norma15_totale', '') }}
                  options={CHOICES.tipo_abuso} disabled={saving}/>
              </NpField>
              {tipoAbuso === 'parziale' && (
                <NpField label='Seleziona violazione'>
                  <NpSel value={n3parziale} onChange={v => set('norma15_parziale', v)} options={CHOICES.art15_parziale} disabled={saving}/>
                </NpField>
              )}
              {tipoAbuso === 'totale' && (
                <NpField label='Seleziona violazione'>
                  <NpSel value={n3totale} onChange={v => set('norma15_totale', v)} options={CHOICES.art15_totale} disabled={saving}/>
                </NpField>
              )}
            </div>
            {showSup15 && (
              <div style={S.row2}>
                <NpField label='Superficie dichiarata (ha)'><NpInt value={g('sup_dichiarata_art15')} onChange={v => set('sup_dichiarata_art15', v)} disabled={saving}/></NpField>
                <NpField label='Superficie irrigata (ha)'><NpInt value={g('sup_irrigata_art15')} onChange={v => set('sup_irrigata_art15', v)} disabled={saving}/></NpField>
              </div>
            )}

            <div style={S.hdr}>Artt. 16 e 17 — Inosservanza termini</div>
            <NpField label='Tipo di inosservanza'>
              <NpSel value={norma1516} onChange={v => { set('norma16_17', v); set('art17_tipo', '') }} options={CHOICES.art16_17} disabled={saving}/>
            </NpField>
            {norma1516 === 'Art17' && (
              <NpField label='Seleziona violazione Art. 17'>
                <NpSel value={art17tipo} onChange={v => set('art17_tipo', v)} options={CHOICES.art17_tipo} disabled={saving}/>
              </NpField>
            )}
            {norma1516 === 'Art16' && (
              <div style={S.row2}>
                <NpField label='Superficie dichiarata (ha)'><NpInt value={g('sup_dichiarata_art16')} onChange={v => set('sup_dichiarata_art16', v)} disabled={saving}/></NpField>
                <NpField label='Superficie irrigata (ha)'><NpInt value={g('sup_irrigata_art16_17_2')} onChange={v => set('sup_irrigata_art16_17_2', v)} disabled={saving}/></NpField>
              </div>
            )}
            {norma1516 === 'Art17' && art17tipo === 'Art17.1' && (
              <div style={S.row2}>
                <NpField label='Superficie dichiarata (ha)'><NpInt value={g('sup_dichiarata_art17_1')} onChange={v => set('sup_dichiarata_art17_1', v)} disabled={saving}/></NpField>
                <NpField label='Superficie variata (ha)'><NpInt value={g('sup_irrigata_art17_1')} onChange={v => set('sup_irrigata_art17_1', v)} disabled={saving}/></NpField>
              </div>
            )}
            {norma1516 === 'Art17' && art17tipo === 'Art17.2' && (
              <div style={S.row2}>
                <NpField label='Superficie dichiarata (ha)'><NpInt value={g('sup_dichiarata_art17_2')} onChange={v => set('sup_dichiarata_art17_2', v)} disabled={saving}/></NpField>
                <NpField label='Superficie irrigata (ha)'><NpInt value={g('sup_irrigata_art16_17_2')} onChange={v => set('sup_irrigata_art16_17_2', v)} disabled={saving}/></NpField>
              </div>
            )}

            <div style={S.hdr}>Altre violazioni</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
              {CHOICES.norma3.map(o => (
                <label key={o.v} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, fontSize: 12,
                  color: '#374151', cursor: saving ? 'not-allowed' : 'pointer', padding: '4px 0' }}>
                  <input type='checkbox' checked={norma3Set.has(o.v)} onChange={() => !saving && toggleNorma3(o.v)} style={{ marginTop: 2, flexShrink: 0 }}/>
                  {o.l}
                </label>
              ))}
            </div>

            <div style={S.hdr}>Descrizione</div>
            <NpField label='Descrizione dettagliata della violazione'>
              <NpText value={g('descrizione_fatti')} onChange={v => set('descrizione_fatti', v)} multiline disabled={saving}/>
            </NpField>
            <NpField label='Circostanze rilevanti'>
              <NpText value={g('circostanze')} onChange={v => set('circostanze', v)} multiline disabled={saving}/>
            </NpField>
            <NpField label='Il trasgressore era presente?'>
              <NpSel value={g('presenza_trasgressore')} onChange={v => set('presenza_trasgressore', v)} options={CHOICES.presenza} disabled={saving}/>
            </NpField>

            <div style={S.hdr}>Descrizione del luogo</div>
            <NpField label='Descrizione del luogo'>
              <NpText value={g('descrizione_luogo')} onChange={v => set('descrizione_luogo', v)} multiline disabled={saving}/>
            </NpField>

            <div style={S.hdr}>Fine compilazione</div>
            <NpField label='Data e ora di compilazione'>
              <NpDate value={g('data_firma')} onChange={v => set('data_firma', v)} withTime disabled={saving}/>
            </NpField>
          </div>
        )}

        {/* ALLEGATI (in CREATE: solo placeholder) */}
        {npTab === 'allegati' && (
          <div style={{ padding: 12, borderRadius: 10, border: '1px dashed rgba(0,0,0,0.18)', background: 'rgba(0,0,0,0.01)' }}>
            <div style={{ fontWeight: 800, fontSize: 13, marginBottom: 6 }}>Allegati</div>
            <div style={{ fontSize: 12, color: '#6b7280', lineHeight: 1.5 }}>
              Gli allegati si gestiscono <b>dopo il salvataggio</b> della pratica (serve l&apos;OBJECTID).
              Dopo aver creato la pratica, comparirà nell&apos;Elenco: selezionala e usa la tab <b>Allegati</b> in modalità modifica.
            </div>
          </div>
        )}

      </div>
    </div>
  )
}


function DetailTabsPanel (props: {
  active: { key: string; state: SelState } | null
  anyDs: any
  showDatiGenerali: boolean
  roleCode: string
  buttonText: string
  buttonColors: ButtonColors
  ui: any
  tabFields: TabFields
  tabs: TabConfig[]
  editConfig: any
  motherLayerUrl?: string
}) {
  const { active, ui } = props

  // Migra e normalizza tabs
  const tabs = React.useMemo(() => {
    return migrateTabs(props.tabFields, props.tabs)
  }, [props.tabs, props.tabFields])

  const selectionKey = active?.state?.oid != null ? `${active.key}:${active.state.oid}` : null
  const ds = active?.state?.ds
  const data = active?.state?.data || null
  const oid = active?.state?.oid ?? null
  const hasSel = oid != null && Number.isFinite(oid)

  // Codice pratica per il titolo
  const praticaCode = React.useMemo(() => {
    if (!hasSel || !data) return ''
    const op = data.origine_pratica ?? data.Origine_pratica ?? data.ORIGINE_PRATICA
    let prefix = 'TR'
    if (op === 2 || op === '2' || String(op).toUpperCase() === 'TI') prefix = 'TI'
    else if (op === 1 || op === '1' || String(op).toUpperCase() === 'TR') prefix = 'TR'
    return `${prefix}-${oid}`
  }, [hasSel, data, oid])

  const [tab, setTab] = React.useState<string>(tabs[0]?.id || 'anagrafica')


  // Allegati (attachments) — caricati solo quando la tab "Allegati" è attiva
  const selectedOid = (hasSel && oid != null) ? Number(oid) : null
  const [attachmentsForOid, setAttachmentsForOid] = React.useState<number | null>(null)
  const [attachments, setAttachments] = React.useState<Array<{ id: number; name?: string; size?: number; contentType?: string; url?: string }>>([])
  const [attachmentsLoading, setAttachmentsLoading] = React.useState<boolean>(false)
  const [attachmentsError, setAttachmentsError] = React.useState<string | null>(null)

  const formatBytes = React.useCallback((n?: number) => {
    if (n == null || isNaN(Number(n))) return ''
    const num = Number(n)
    if (num < 1024) return `${num} B`
    const kb = num / 1024
    if (kb < 1024) return `${kb.toFixed(1)} KB`
    const mb = kb / 1024
    if (mb < 1024) return `${mb.toFixed(1)} MB`
    const gb = mb / 1024
    return `${gb.toFixed(1)} GB`
  }, [])

  const loadAttachments = React.useCallback(async () => {
    if (!selectedOid) return
    try {
      setAttachmentsLoading(true)
      setAttachmentsError(null)

      const dsAny: any = ds as any
      const layer = await resolveFeatureLayerForAttachments(dsAny)

      if (!layer) {
        setAttachments([])
        setAttachmentsForOid(selectedOid)
        setAttachmentsError('Non riesco a risalire al FeatureLayer per leggere gli allegati (datasource/vista non espone il layer JS API).')
        return
      }

      const res: any = await layer.queryAttachments({
        objectIds: [selectedOid],
        returnMetadata: true,
        returnUrl: true
      })

      const pullInfos = (obj: any): any[] => {
        if (!obj) return []
        if (Array.isArray(obj)) return obj
        if (Array.isArray(obj.attachmentInfos)) return obj.attachmentInfos
        if (Array.isArray(obj.attachments)) return obj.attachments
        return []
      }

      let infos: any[] = []
      if (Array.isArray(res)) {
        for (const g of res) {
          if (!g) continue
          const pid = (g.parentObjectId != null) ? g.parentObjectId : (g.objectId != null ? g.objectId : null)
          if (pid === selectedOid) {
            infos = pullInfos(g)
            break
          }
        }
      } else if (res && typeof res === 'object') {
        if (Array.isArray(res.attachmentGroups)) {
          for (const g of res.attachmentGroups) {
            const pid = (g && g.parentObjectId != null) ? g.parentObjectId : (g && g.objectId != null ? g.objectId : null)
            if (pid === selectedOid) {
              infos = pullInfos(g)
              break
            }
          }
        } else if ((res as any)[selectedOid]) {
          infos = pullInfos((res as any)[selectedOid])
        } else if ((res as any)[String(selectedOid)]) {
          infos = pullInfos((res as any)[String(selectedOid)])
        } else if ((res as any).attachmentInfos) {
          infos = pullInfos(res)
        }
      }

      const clean = (infos || []).map((a: any) => ({
        id: Number(a.id),
        name: a.name,
        size: a.size,
        contentType: a.contentType,
        url: a.url
      })).filter((a: any) => a && !isNaN(a.id))

      setAttachments(clean)
      setAttachmentsForOid(selectedOid)
    } catch (e: any) {
      setAttachments([])
      setAttachmentsForOid(selectedOid)
      setAttachmentsError(e?.message || String(e))
    } finally {
      setAttachmentsLoading(false)
    }
  }, [ds, selectedOid])

  React.useEffect(() => {
    if (tab === 'allegati' && selectedOid != null && attachmentsForOid !== selectedOid) {
      loadAttachments()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, selectedOid, attachmentsForOid])

  // RIMOSSO: Non resettare la tab quando cambia selezione
  // React.useEffect(() => {
  //   // reset tab quando cambia selezione (UX più prevedibile)
  //   setTab(tabs[0]?.id || 'anagrafica')
  // }, [selectionKey, tabs])

  // alias map dai campi layer (se disponibile)
  const [aliasMap, setAliasMap] = React.useState<Record<string, string>>({})
  const [aliasesReady, setAliasesReady] = React.useState<boolean>(false)

  React.useEffect(() => {
    let cancelled = false
    setAliasesReady(false)

    // 1) Prova subito dallo schema del datasource (di solito è pronto prima del JSAPI layer)
    try {
      const schema = ds?.getSchema?.()
      const fobj = schema?.fields || {}
      const mapFromSchema: Record<string, string> = {}
      for (const name of Object.keys(fobj)) {
        const f = fobj[name]
        const alias = String(f?.alias || f?.label || f?.title || name)
        mapFromSchema[name] = alias
      }
      if (!cancelled && Object.keys(mapFromSchema).length) {
        setAliasMap(mapFromSchema)
        setAliasesReady(true)
      }
    } catch {}

    // 2) In parallelo: prova dal layer JSAPI (aggiorna/raffina)
    const loadAliases = async () => {
      if (!ds) { if (!cancelled) { setAliasMap({}); setAliasesReady(true) } return }
      try {
        const raw =
          ds?.getLayer?.() ||
          ds?.getJSAPILayer?.() ||
          ds?.layer ||
          ds?.createJSAPILayerByDataSource?.() ||
          null

        const resolved = await Promise.resolve(raw as any)
        const layer = unwrapJsapiLayer(resolved)
        const fields = (layer?.fields || []) as any[]
        const map: Record<string, string> = {}
        for (const f of fields) {
          const name = String(f?.name || '')
          if (!name) continue
          map[name] = String(f?.alias || f?.label || f?.title || name)
        }
        if (!cancelled) {
          if (Object.keys(map).length) setAliasMap(map)
          setAliasesReady(true)
        }
      } catch {
        if (!cancelled) { setAliasesReady(true) }
      }
    }

    loadAliases()
    return () => { cancelled = true }
  }, [ds])

  const toLabel = React.useCallback((fieldName: string) => {
    const a = aliasMap?.[fieldName]
    // Evita il “flash” del nome campo: se gli alias non sono pronti, non mostrare il nome tecnico.
    if (!aliasesReady) return ''
    return a ? `${a}` : fieldName
  }, [aliasMap, aliasesReady])

// --- Condizionamento campi anagrafica per tipo_soggetto (PF/PG)
  const classifyTipoSoggetto = React.useCallback((raw: any, labelFromDomain?: any): 'PF' | 'PG' | null => {
    return classifyTipoSoggettoRobusto(raw, labelFromDomain)
  }, [])

  
const isPfOnlyField = React.useCallback((fieldName: string) => {
  const nameKey = normKey(fieldName)
  const aliasKey = normKey(aliasMap?.[fieldName] || '')
  const combined = `${nameKey} ${aliasKey}`.trim()

  // Evita falsi positivi tipo "denominazione" (contiene "nome" come substring)
  const isNome = hasToken(combined, 'nome') || combined.startsWith('nome ')
  const isCognome = hasToken(combined, 'cognome') || combined.startsWith('cognome ')
  const isCf =
    hasToken(combined, 'cf') ||
    hasToken(combined, 'c f') ||
    hasToken(combined, 'c f ') ||
    hasToken(combined, 'codice fiscale') ||
    (combined.includes('cod') && combined.includes('fisc'))

  return Boolean(isNome || isCognome || isCf)
}, [aliasMap])

const isPgOnlyField = React.useCallback((fieldName: string) => {
  const nameKey = normKey(fieldName)
  const aliasKey = normKey(aliasMap?.[fieldName] || '')
  const combined = `${nameKey} ${aliasKey}`.trim()

  const isRagSoc =
    hasToken(combined, 'ragione sociale') ||
    hasToken(combined, 'denominazione') ||
    (combined.includes('ragione') && combined.includes('social'))

  const isPiva =
    hasToken(combined, 'partita iva') ||
    hasToken(combined, 'p iva') ||
    hasToken(combined, 'piva') ||
    (combined.includes('partita') && combined.includes('iva'))

  return Boolean(isRagSoc || isPiva)
}, [aliasMap])

  const makeRows = React.useCallback((fields: string[], kind: string, hideEmpty: boolean) => {
    const rawList = (fields && fields.length) ? fields : []  // Se nessun campo configurato, mostra lista vuota (usare il setting per configurare)
    const tipoRaw = (data && (data as any).__tipo_soggetto_raw != null) ? (data as any).__tipo_soggetto_raw : ((data && (data as any).tipo_soggetto != null) ? (data as any).tipo_soggetto : null)
    const tipoLabel = (data && (data as any).__tipo_soggetto_label != null) ? (data as any).__tipo_soggetto_label : null
    const sogg = (kind === 'ANAGRAFICA') ? classifyTipoSoggetto(tipoRaw, tipoLabel) : null
    const list = (kind === 'ANAGRAFICA' && sogg)
      ? rawList.filter(fn => {
          if (!fn) return false
          if (sogg === 'PF' && isPgOnlyField(fn)) return false
          if (sogg === 'PG' && isPfOnlyField(fn)) return false
          return true
        })
      : rawList
    const rows: Array<{ label: string; value: any }> = []
    for (const f of list) {
      if (!f) continue
      const vv = data ? (data as any)[f] : null
      if (hideEmpty && isEmptyValue(vv)) continue
      rows.push({ label: toLabel(f), value: vv })
    }
    return rows
  }, [data, toLabel, classifyTipoSoggetto, isPfOnlyField, isPgOnlyField])
// Iter: sempre blocchi DT/DA + extra selezionati
  const presaDT = data ? data.presa_in_carico_DT : null
  const dtPresaDT = data ? data.dt_presa_in_carico_DT : null
  const statoDT = data ? data.stato_DT : null
  const dtStatoDT = data ? data.dt_stato_DT : null
  const esitoDT = data ? data.esito_DT : null
  const dtEsitoDT = data ? data.dt_esito_DT : null
  const noteDT = data ? data.note_DT : null

  const presaDA = data ? data.presa_in_carico_DA : null
  const dtPresaDA = data ? data.dt_presa_in_carico_DA : null
  const statoDA = data ? data.stato_DA : null
  const dtStatoDA = data ? data.dt_stato_DA : null
  const esitoDA = data ? data.esito_DA : null
  const dtEsitoDA = data ? data.dt_esito_DA : null
  const noteDA = data ? data.note_DA : null

  const TabsBar = (
    <div style={{ 
      display: 'flex', 
      flexWrap: 'wrap', 
      gap: 8, 
      padding: '8px 12px',
      alignItems: 'center',
      borderBottom: '1px solid rgba(0,0,0,0.08)',
      background: 'var(--bs-body-bg, #fff)',
      marginTop: -ui.panelPadding,
      marginLeft: -ui.panelPadding,
      marginRight: -ui.panelPadding,
      width: `calc(100% + ${ui.panelPadding * 2}px)`,
      borderTopLeftRadius: ui.panelBorderRadius,
      borderTopRightRadius: ui.panelBorderRadius
    }}>
      {hasSel && tabs.map((t) => (
        <TabButton 
          key={t.id}
          active={tab === t.id} 
          label={t.label} 
          onClick={() => setTab(t.id)} 
        />
      ))}
    </div>
  )

  const outerStyle: React.CSSProperties = {
  width: '100%',
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  minHeight: 0,
  boxSizing: 'border-box'
}

const frameStyle: React.CSSProperties = {
  width: '100%',
  height: '100%',
  flex: '1 1 auto',
  display: 'flex',
  flexDirection: 'column',
  minHeight: 0,
  boxSizing: 'border-box',
  background: ui.panelBg,
  border: `${ui.panelBorderWidth}px solid ${ui.panelBorderColor}`,
  borderRadius: ui.panelBorderRadius,
  padding: ui.panelPadding
}

const tabsStyle: React.CSSProperties = {
  flex: '0 0 auto'
}

const contentStyle: React.CSSProperties = {
  flex: '1 1 auto',
  minHeight: 0,
  overflowY: 'auto'
}

let content: React.ReactNode = null

if (!hasSel) {
  // In questo pannello (modalità UPDATE/legacy) una selezione è necessaria.
  // La creazione senza selezione viene gestita nel runtime principale quando enableCreateWithoutSelection è ON.
  content = (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', minHeight:200, fontSize:13, color:'rgba(0,0,0,0.45)' }}>
      Seleziona una pratica dall&apos;Elenco.
    </div>
  )
} else {
  const activeTab = tabs.find(t => t.id === tab)
  
  if (activeTab?.id === 'azioni') {
    content = (
      <ActionsPanel
        active={active}
        roleCode={props.roleCode}
        buttonText={props.buttonText}
        buttonColors={props.buttonColors}
        ui={props.ui}
        editConfig={props.editConfig}
        motherLayerUrl={props.motherLayerUrl}
      />
    )
  } else if (activeTab?.isIterTab) {
    // Tab Iter con campi DT/DA fissi + extra
    const iterRows: Array<{ label: string; value: any }> = []
    iterRows.push({ label: 'DT - Presa in carico', value: presaDT })
    iterRows.push({ label: 'DT - Data presa in carico', value: formatDateSafe(dtPresaDT) })
    iterRows.push({ label: 'DT - Stato', value: statoDT })
    iterRows.push({ label: 'DT - Data stato', value: formatDateSafe(dtStatoDT) })
    iterRows.push({ label: 'DT - Esito', value: esitoDT })
    iterRows.push({ label: 'DT - Data esito', value: formatDateSafe(dtEsitoDT) })
    iterRows.push({ label: 'DT - Note', value: noteDT })

    iterRows.push({ label: 'DA - Presa in carico', value: presaDA })
    iterRows.push({ label: 'DA - Data presa in carico', value: formatDateSafe(dtPresaDA) })
    iterRows.push({ label: 'DA - Stato', value: statoDA })
    iterRows.push({ label: 'DA - Data stato', value: formatDateSafe(dtStatoDA) })
    iterRows.push({ label: 'DA - Esito', value: esitoDA })
    iterRows.push({ label: 'DA - Data esito', value: formatDateSafe(dtEsitoDA) })
    iterRows.push({ label: 'DA - Note', value: noteDA })

    // Aggiungi campi extra configurati
    const iterExtraRows = aliasesReady ? makeRows(activeTab.fields, activeTab.id.toUpperCase(), Boolean((activeTab as any).hideEmpty)) : []
    iterExtraRows.forEach(r => iterRows.push(r))
    
    content = <ReadOnlyPanel title={activeTab.label} ui={ui} rows={iterRows} />
  } else if (activeTab) {
    // Tab normale con campi configurabili
    const rows = aliasesReady ? makeRows(activeTab.fields, activeTab.id.toUpperCase(), Boolean((activeTab as any).hideEmpty)) : []

    if (activeTab.id === 'allegati') {
      // Pannello Allegati: elenco attachments (se presenti) + (opzionale) attributi della tab
      const dsAny: any = ds as any
      const layer = unwrapJsapiLayer(
        (dsAny && (typeof dsAny.getLayer === 'function') ? dsAny.getLayer() : null) ||
        (dsAny && (typeof dsAny.getJsApiLayer === 'function') ? dsAny.getJsApiLayer() : null) ||
        (dsAny && dsAny.layer) ||
        dsAny
      ) as any
      const layerUrl = layer && layer.url ? String(layer.url) : ''

      const getOpenUrl = (att: any): string | null => {
        if (att && att.url) return String(att.url)
        if (layerUrl && selectedOid != null && att && att.id != null) return `${layerUrl}/${selectedOid}/attachments/${att.id}`
        return null
      }

      content = (
        <div style={{ marginTop: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <div style={{ fontWeight: 700, fontSize: 13 }}>Allegati</div>
            <button
              type="button"
              onClick={() => loadAttachments()}
              disabled={!hasSel || attachmentsLoading}
              onMouseEnter={(e) => {
                if (!(!hasSel || attachmentsLoading)) {
                  e.currentTarget.style.background = '#eaf2ff'
                  e.currentTarget.style.borderColor = '#2f6fed'
                  e.currentTarget.style.color = '#1d4ed8'
                }
              }}
              onMouseLeave={(e) => {
                if (!(!hasSel || attachmentsLoading)) {
                  e.currentTarget.style.background = '#fff'
                  e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)'
                  e.currentTarget.style.color = '#111827'
                }
              }}
              style={{
                padding: '6px 10px',
                borderRadius: 10,
                border: '1px solid rgba(0,0,0,0.12)',
                background: '#fff',
                color: '#111827',
                cursor: (!hasSel || attachmentsLoading) ? 'not-allowed' : 'pointer',
                fontSize: 12,
                fontWeight: 600,
                transition: 'all 0.15s ease'
              }}
            >
              Aggiorna
            </button>
          </div>

          {!hasSel && (
            <div style={{ opacity: 0.75, fontSize: 12 }}>Selezionare un rapporto per vedere gli allegati.</div>
          )}

          {hasSel && attachmentsLoading && (
            <div style={{ opacity: 0.75, fontSize: 12 }}>Caricamento allegati…</div>
          )}

          {hasSel && !attachmentsLoading && attachmentsError && (
            <div style={{ color: '#b00020', fontSize: 12 }}>{attachmentsError}</div>
          )}

          {hasSel && !attachmentsLoading && !attachmentsError && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {(attachments && attachments.length) ? (
                attachments.map((a) => {
                  const url = getOpenUrl(a)
                  const meta = [a.contentType, formatBytes(a.size)].filter(Boolean).join(' • ')
                  return (
                    <div
                      key={a.id}
                      style={{
                        border: '1px solid rgba(0,0,0,0.08)',
                        borderRadius: 12,
                        padding: '8px 10px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: 10
                      }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontWeight: 600, fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {a.name || `Allegato #${a.id}`}
                        </div>
                        {meta ? <div style={{ opacity: 0.7, fontSize: 11 }}>{meta}</div> : null}
                      </div>
                      {url ? (
                        <a
                          href={url}
                          target="_blank"
                          rel="noreferrer"
                          onMouseEnter={(e) => {
                            e.currentTarget.style.background = '#eaf2ff'
                            e.currentTarget.style.borderColor = '#2f6fed'
                            e.currentTarget.style.color = '#1d4ed8'
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.background = '#fff'
                            e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)'
                            e.currentTarget.style.color = '#111827'
                          }}
                          style={{
                            padding: '6px 10px',
                            borderRadius: 10,
                            border: '1px solid rgba(0,0,0,0.12)',
                            background: '#fff',
                            color: '#111827',
                            textDecoration: 'none',
                            fontSize: 12,
                            fontWeight: 600,
                            whiteSpace: 'nowrap',
                            transition: 'all 0.15s ease'
                          }}
                        >
                          Apri
                        </a>
                      ) : (
                        <span style={{ opacity: 0.6, fontSize: 12, whiteSpace: 'nowrap' }}>URL non disponibile</span>
                      )}
                    </div>
                  )
                })
              ) : (
                <div style={{ opacity: 0.75, fontSize: 12 }}>Nessun allegato.</div>
              )}
            </div>
          )}

          {rows && rows.length > 0 && (
            <div style={{ marginTop: 12 }}>
              <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 6 }}>Attributi</div>
              <ReadOnlyPanel
                title={activeTab.label}
                rows={rows}
                emptyText={hasSel ? 'Nessun campo configurato per questa tab.' : 'Selezionare un rapporto.'}
              />
            </div>
          )}
        </div>
      )
    } else {
      content = (
        <ReadOnlyPanel
          title={activeTab.label}
          rows={rows}
          emptyText={hasSel ? 'Nessun campo configurato per questa tab.' : 'Selezionare un rapporto.'}
        />
      )
    }
  }
}

return (
  <div style={outerStyle}>
    {/* Titolo pratica - sopra l'area bianca */}
    <div style={{
      height: ui.detailTitleHeight ?? 28,
      paddingBottom: ui.detailTitlePaddingBottom ?? 10,
      paddingLeft: ui.detailTitlePaddingLeft ?? 0,
      display: 'flex',
      alignItems: 'center',
      boxSizing: 'border-box',
      flex: '0 0 auto',
      background: (ui as any).detailTitleBg && (ui as any).detailTitleBg !== 'transparent' ? (ui as any).detailTitleBg : undefined
    }}>
      <span style={{
        fontSize: ui.detailTitleFontSize ?? 14,
        fontWeight: ui.detailTitleFontWeight ?? 600,
        color: hasSel && praticaCode
          ? (ui.detailTitleColor ?? 'rgba(0,0,0,0.85)')
          : 'rgba(0,0,0,0.40)'
      }}>
        {String(ui.detailTitlePrefix ?? 'Dettaglio rapporto n.')} {hasSel && praticaCode ? praticaCode : '–'}
      </span>
    </div>
    <div style={frameStyle}>
      <div style={tabsStyle}>{TabsBar}</div>
      <div style={contentStyle}>{content}</div>
    </div>
  </div>
)

}



type DynamicSelectionInfo = {
  oid: number | null
  layerUrl: string
  idFieldName: string
  data?: any | null
}

function makeRecordProxy (attrs: any, idFieldName: string) {
  const oid = attrs?.[idFieldName] ?? attrs?.OBJECTID ?? attrs?.ObjectId ?? attrs?.objectid ?? attrs?.objectId ?? null
  return {
    getData: () => attrs || {},
    getId: () => String(oid ?? ''),
    id: oid
  }
}

function getServiceNameFromUrl (url: string): string {
  try {
    const part = String(url || '').split('/rest/services/')[1] || ''
    return (part.split('/FeatureServer')[0] || '').trim()
  } catch {
    return ''
  }
}

function readDynamicSelection (): DynamicSelectionInfo {
  try {
    const w: any = window as any
    const sel: any = w.__giiSelection || {}
    const rawOid = sel?.oid ?? sessionStorage.getItem('GII_SELECTED_OID')
    const oidNum = rawOid != null && rawOid !== '' ? Number(rawOid) : NaN
    const layerUrl = String(sel?.layerUrl || sessionStorage.getItem('GII_SELECTED_LAYER_URL') || '').trim()
    const idFieldName = String(sel?.idFieldName || sessionStorage.getItem('GII_SELECTED_IDFIELD') || 'OBJECTID').trim() || 'OBJECTID'
    return {
      oid: Number.isFinite(oidNum) ? oidNum : null,
      layerUrl,
      idFieldName,
      data: sel?.data || null
    }
  } catch {
    return { oid: null, layerUrl: '', idFieldName: 'OBJECTID', data: null }
  }
}

function writeDynamicSelection (sel: { oid?: number | null, layerUrl?: string, idFieldName?: string, data?: any | null }) {
  try {
    const prev: any = (window as any).__giiSelection || {}
    const next: any = {
      ...prev,
      ...sel,
      ts: Date.now()
    }
    ;(window as any).__giiSelection = next
    if (next.oid != null && Number.isFinite(Number(next.oid))) sessionStorage.setItem('GII_SELECTED_OID', String(Number(next.oid)))
    else sessionStorage.removeItem('GII_SELECTED_OID')
    if (next.layerUrl) sessionStorage.setItem('GII_SELECTED_LAYER_URL', String(next.layerUrl))
    else sessionStorage.removeItem('GII_SELECTED_LAYER_URL')
    if (next.idFieldName) sessionStorage.setItem('GII_SELECTED_IDFIELD', String(next.idFieldName))
    else sessionStorage.removeItem('GII_SELECTED_IDFIELD')
    window.dispatchEvent(new CustomEvent('gii-selection-changed'))
  } catch {}
}

async function buildDynamicDsProxy (layerUrl: string, label?: string): Promise<any | null> {
  const url = String(layerUrl || '').trim()
  if (!url) return null
  try {
    const FeatureLayer = await loadEsriModule<any>('esri/layers/FeatureLayer')
    const fl = new FeatureLayer({ url, outFields: ['*'] })
    if (typeof fl?.load === 'function') await fl.load().catch(() => {})
    const idFieldName = String(fl?.objectIdField || 'OBJECTID')
    const schemaFields: Record<string, any> = {}
    ;((fl?.fields || []) as any[]).forEach((f: any) => {
      if (!f?.name) return
      schemaFields[String(f.name)] = {
        alias: String(f.alias || f.name),
        label: String(f.alias || f.name),
        title: String(f.alias || f.name),
        type: String(f.type || ''),
        domain: f.domain || null
      }
    })
    const proxy: any = {
      id: `gii-dynamic-${encodeURIComponent(url).slice(-48)}`,
      layer: fl,
      async getLayer () { return fl },
      async getJSAPILayer () { return fl },
      async getJsApiLayer () { return fl },
      getDataSourceJson () { return { url } },
      dataSourceJson: { url },
      getLabel () { return String(label || getServiceNameFromUrl(url) || 'GII view dinamica') },
      getIdField () { return idFieldName },
      getSchema () { return { idField: idFieldName, fields: schemaFields } },
      async query (q: any) {
        const qq: any = {
          where: String(q?.where || '1=1'),
          outFields: Array.isArray(q?.outFields) && q.outFields.length ? q.outFields : ['*'],
          returnGeometry: !!q?.returnGeometry
        }
        if (Number.isFinite(Number(q?.num))) qq.num = Number(q.num)
        else if (Number.isFinite(Number(q?.pageSize))) qq.num = Number(q.pageSize)
        const res: any = await fl.queryFeatures(qq)
        const feats: any[] = Array.isArray(res?.features) ? res.features : []
        return { records: feats.map((ft: any) => makeRecordProxy(ft?.attributes || {}, idFieldName)) }
      },
      async selectRecordsByIds (ids: any[]) {
        const oid = Array.isArray(ids) && ids.length ? Number(ids[0]) : null
        writeDynamicSelection({ oid, layerUrl: url, idFieldName })
      },
      async selectRecordById (id: any) {
        const oid = id != null ? Number(id) : null
        writeDynamicSelection({ oid, layerUrl: url, idFieldName })
      },
      async setSelectedRecordIds (ids: any[]) {
        const oid = Array.isArray(ids) && ids.length ? Number(ids[0]) : null
        writeDynamicSelection({ oid, layerUrl: url, idFieldName })
      },
      async setSelectedIds (ids: any[]) {
        const oid = Array.isArray(ids) && ids.length ? Number(ids[0]) : null
        writeDynamicSelection({ oid, layerUrl: url, idFieldName })
      },
      clearSelection () {
        const cur = readDynamicSelection()
        if (cur.layerUrl === url) writeDynamicSelection({ oid: null, layerUrl: url, idFieldName, data: null })
      }
    }
    return proxy
  } catch {
    return null
  }
}

function useDynamicActiveSelection (queryFields: string[], label?: string) {
  const [active, setActive] = React.useState<{ key: string; state: SelState } | null>(null)
  const reqRef = React.useRef(0)

  React.useEffect(() => {
    const refresh = () => {
      const req = ++reqRef.current
      const sel = readDynamicSelection()
      if (sel.oid == null || !sel.layerUrl) {
        setActive(null)
        return
      }
      ;(async () => {
        const ds = await buildDynamicDsProxy(sel.layerUrl, label)
        if (!ds) {
          if (req === reqRef.current) setActive(null)
          return
        }
        const idFieldName = String(sel.idFieldName || ds.getIdField?.() || 'OBJECTID')
        let data = sel.data || null
        try {
          if (!data || Number(data?.[idFieldName] ?? data?.OBJECTID ?? null) !== Number(sel.oid)) {
            const res: any = await ds.query({ where: `${idFieldName}=${Number(sel.oid)}`, outFields: queryFields, returnGeometry: false })
            const rec0: any = res?.records?.[0] || null
            data = rec0?.getData?.() || null
          }
        } catch {
          data = null
        }
        if (req !== reqRef.current) return
        if (!data) {
          setActive(null)
          return
        }
        writeDynamicSelection({ oid: Number(sel.oid), layerUrl: sel.layerUrl, idFieldName, data })
        setActive({
          key: sel.layerUrl,
          state: {
            ds,
            oid: Number(sel.oid),
            idFieldName,
            data,
            sig: `${sel.layerUrl}:${Number(sel.oid)}:${Date.now()}`
          }
        })
      })().catch(() => {
        if (req === reqRef.current) setActive(null)
      })
    }
    refresh()
    const h = () => refresh()
    window.addEventListener('gii-selection-changed', h as any)
    window.addEventListener('gii-force-refresh-selection', h as any)
    return () => {
      window.removeEventListener('gii-selection-changed', h as any)
      window.removeEventListener('gii-force-refresh-selection', h as any)
    }
  }, [label, queryFields.join('|')])

  return active
}

export default function Widget (props: AllWidgetProps<IMConfig>) {
  const cfgMutable: any = (props.config && (props.config as any).asMutable)
    ? (props.config as any).asMutable({ deep: true })
    : (props.config as any || {})
  const cfg: any = { ...defaultConfig, ...cfgMutable }

  const [detectedRole, setDetectedRole] = React.useState<string>('')
  React.useEffect(() => {
    const readRole = () => {
      try {
        const r = (window as any).__giiUserRole?.ruoloLabel
        setDetectedRole(r && r !== 'ADMIN' ? String(r).toUpperCase() : '')
      } catch { }
    }
    readRole()
    window.addEventListener('gii:userLoaded', readRole)
    return () => window.removeEventListener('gii:userLoaded', readRole)
  }, [])

  const showDatiGenerali = cfg.showDatiGenerali === true
  const roleCode = detectedRole || String(cfg.roleCode || 'DT').toUpperCase()
  const buttonText = String(cfg.buttonText || 'Prendi in carico')
  const buttonColors: ButtonColors = {
    take: normalizeHexColor(cfg.takeColor, defaultConfig.takeColor),
    integrazione: normalizeHexColor(cfg.integrazioneColor, defaultConfig.integrazioneColor),
    approva: normalizeHexColor(cfg.approvaColor, defaultConfig.approvaColor),
    respingi: normalizeHexColor(cfg.respingiColor, defaultConfig.respingiColor),
    trasmetti: normalizeHexColor(cfg.trasmettiColor, defaultConfig.trasmettiColor)
  }

  const ui = {
    panelBg: String((cfg as any).maskBg ?? cfg.panelBg ?? (defaultConfig as any).maskBg ?? defaultConfig.panelBg),
    panelBorderColor: String((cfg as any).maskBorderColor ?? cfg.panelBorderColor ?? (defaultConfig as any).maskBorderColor ?? defaultConfig.panelBorderColor),
    panelBorderWidth: Number.isFinite(Number((cfg as any).maskBorderWidth ?? cfg.panelBorderWidth)) ? Number((cfg as any).maskBorderWidth ?? cfg.panelBorderWidth) : ((defaultConfig as any).maskBorderWidth ?? defaultConfig.panelBorderWidth),
    panelBorderRadius: Number.isFinite(Number((cfg as any).maskBorderRadius ?? cfg.panelBorderRadius)) ? Number((cfg as any).maskBorderRadius ?? cfg.panelBorderRadius) : ((defaultConfig as any).maskBorderRadius ?? defaultConfig.panelBorderRadius),
    panelPadding: Number.isFinite(Number((cfg as any).maskInnerPadding ?? cfg.panelPadding)) ? Number((cfg as any).maskInnerPadding ?? cfg.panelPadding) : ((defaultConfig as any).maskInnerPadding ?? defaultConfig.panelPadding),
    dividerColor: String(cfg.dividerColor ?? defaultConfig.dividerColor),
    titleFontSize: Number.isFinite(Number(cfg.titleFontSize)) ? Number(cfg.titleFontSize) : defaultConfig.titleFontSize,
    statusFontSize: Number.isFinite(Number(cfg.statusFontSize)) ? Number(cfg.statusFontSize) : defaultConfig.statusFontSize,
    msgFontSize: Number.isFinite(Number(cfg.msgFontSize)) ? Number(cfg.msgFontSize) : defaultConfig.msgFontSize,
    rejectReasons: Array.isArray(cfg.rejectReasons) ? cfg.rejectReasons.map((x: any) => String(x)) : defaultConfig.rejectReasons,
    reasonsZebraOddBg: String(cfg.reasonsZebraOddBg ?? defaultConfig.reasonsZebraOddBg),
    reasonsZebraEvenBg: String(cfg.reasonsZebraEvenBg ?? defaultConfig.reasonsZebraEvenBg),
    reasonsRowBorderColor: String(cfg.reasonsRowBorderColor ?? defaultConfig.reasonsRowBorderColor),
    reasonsRowBorderWidth: Number.isFinite(Number(cfg.reasonsRowBorderWidth)) ? Number(cfg.reasonsRowBorderWidth) : defaultConfig.reasonsRowBorderWidth,
    reasonsRowRadius: Number.isFinite(Number(cfg.reasonsRowRadius)) ? Number(cfg.reasonsRowRadius) : defaultConfig.reasonsRowRadius,
    detailTitlePrefix: String(cfg.detailTitlePrefix ?? defaultConfig.detailTitlePrefix),
    detailTitleHeight: Number.isFinite(Number(cfg.detailTitleHeight)) ? Number(cfg.detailTitleHeight) : defaultConfig.detailTitleHeight,
    detailTitlePaddingBottom: Number.isFinite(Number(cfg.detailTitlePaddingBottom)) ? Number(cfg.detailTitlePaddingBottom) : defaultConfig.detailTitlePaddingBottom,
    detailTitlePaddingLeft: Number.isFinite(Number(cfg.detailTitlePaddingLeft)) ? Number(cfg.detailTitlePaddingLeft) : defaultConfig.detailTitlePaddingLeft,
    detailTitleFontSize: Number.isFinite(Number(cfg.detailTitleFontSize)) ? Number(cfg.detailTitleFontSize) : defaultConfig.detailTitleFontSize,
    detailTitleFontWeight: Number.isFinite(Number(cfg.detailTitleFontWeight)) ? Number(cfg.detailTitleFontWeight) : defaultConfig.detailTitleFontWeight,
    detailTitleColor: String(cfg.detailTitleColor ?? defaultConfig.detailTitleColor),
    detailTitleBg: String(cfg.detailTitleBg ?? defaultConfig.detailTitleBg ?? 'transparent'),
    btnBorderRadius: Number.isFinite(Number(cfg.btnBorderRadius)) ? Number(cfg.btnBorderRadius) : defaultConfig.btnBorderRadius ?? 8,
    btnFontSize: Number.isFinite(Number(cfg.btnFontSize)) ? Number(cfg.btnFontSize) : defaultConfig.btnFontSize ?? 13,
    btnFontWeight: Number.isFinite(Number(cfg.btnFontWeight)) ? Number(cfg.btnFontWeight) : defaultConfig.btnFontWeight ?? 600,
    btnPaddingX: Number.isFinite(Number(cfg.btnPaddingX)) ? Number(cfg.btnPaddingX) : defaultConfig.btnPaddingX ?? 16,
    btnPaddingY: Number.isFinite(Number(cfg.btnPaddingY)) ? Number(cfg.btnPaddingY) : defaultConfig.btnPaddingY ?? 8
  }

  const tabFields: TabFields = {
    anagrafica: normalizeFieldList((cfg as any).anagraficaFields),
    violazione: normalizeFieldList((cfg as any).violazioneFields),
    allegati: normalizeFieldList((cfg as any).allegatiFields),
    iterExtra: normalizeFieldList((cfg as any).iterExtraFields)
  }
  const migratedTabs = migrateTabs(tabFields, cfg.tabs || [])
  const editConfig = {
    show: cfg.showEditButtons !== false,
    overlayColor: normalizeHexColor(cfg.editOverlayColor, '#7c3aed'),
    pageColor: normalizeHexColor(cfg.editPageColor, '#5b21b6'),
    pageId: String(cfg.editPageId || 'editing-ti'),
    fieldStatoTI: String(cfg.fieldStatoTI || 'stato_TI'),
    fieldPresaTI: String(cfg.fieldPresaTI || 'presa_in_carico_TI'),
    minStato: Number.isFinite(Number(cfg.editMinStato)) ? Number(cfg.editMinStato) : 2,
    maxStato: Number.isFinite(Number(cfg.editMaxStato)) ? Number(cfg.editMaxStato) : 2,
    presaRequiredVal: Number.isFinite(Number(cfg.editPresaRequiredVal)) ? Number(cfg.editPresaRequiredVal) : 2
  }

  const watchFields = [
    'presa_in_carico_DT', 'dt_presa_in_carico_DT', 'stato_DT', 'dt_stato_DT', 'esito_DT', 'dt_esito_DT', 'note_DT',
    'presa_in_carico_DA', 'dt_presa_in_carico_DA', 'stato_DA', 'dt_stato_DA', 'esito_DA', 'dt_esito_DA', 'note_DA'
  ]

  const activeGate = useDynamicActiveSelection(['*'], 'GII view dinamica')

  const mapWidgetId = Array.isArray(cfg.useMapWidgetIds) ? cfg.useMapWidgetIds[0] : null
  const [jimuMapView, setJimuMapView] = React.useState<JimuMapView | null>(null)
  const [clickedPointWgs84, setClickedPointWgs84] = React.useState<any | null>(null)
  React.useEffect(() => {
    const view: any = (jimuMapView as any)?.view
    if (!view || typeof view.on !== 'function') return
    const h = view.on('click', (e: any) => {
      ;(async () => {
        const pt = await toWgs84Point(e?.mapPoint)
        if (pt) setClickedPointWgs84(pt)
      })().catch(() => {})
    })
    return () => { try { h?.remove?.() } catch {} }
  }, [jimuMapView])

  const [createDs, setCreateDs] = React.useState<any | null>(null)
  React.useEffect(() => {
    let alive = true
    const dynamicUrl = String(cfg.motherLayerUrl || '').trim() || String(readDynamicSelection().layerUrl || '').trim()
    const legacyUds: any = Array.isArray(props.useDataSources) && props.useDataSources.length ? (props.useDataSources as any)[0] : null
    const legacyDsId = legacyUds?.dataSourceId
    if (!dynamicUrl && !legacyDsId) {
      setCreateDs(null)
      return
    }
    ;(async () => {
      let ds: any = null
      if (dynamicUrl) ds = await buildDynamicDsProxy(dynamicUrl, 'GII layer madre')
      if (!ds && legacyDsId) {
        try {
          ds = DataSourceManager.getInstance().getDataSource(legacyDsId)
        } catch {}
      }
      if (alive) setCreateDs(ds || null)
    })().catch(() => { if (alive) setCreateDs(null) })
    return () => { alive = false }
  }, [cfg.motherLayerUrl, activeGate?.key, JSON.stringify(props.useDataSources || [])])

  const createOnlyMode = cfg.enableCreateWithoutSelection !== false
  const anyDs = createOnlyMode ? createDs : (activeGate?.state?.ds || createDs)

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0, boxSizing: 'border-box', padding: Number.isFinite(Number((cfg as any).maskOuterOffset ?? 0)) ? Number((cfg as any).maskOuterOffset) : 0 }}>
      {mapWidgetId && (
        <div style={{ display: 'none' }}>
          <JimuMapViewComponent
            useMapWidgetId={mapWidgetId}
            onActiveViewChange={(jmv: JimuMapView) => { setJimuMapView(jmv) }}
          />
        </div>
      )}

      {createOnlyMode ? (
        anyDs ? (
          <NuovaPraticaForm
            mode='create'
            ds={anyDs}
            cfg={cfg}
            showDatiGenerali={showDatiGenerali}
            clickedPointWgs84={clickedPointWgs84}
            onClearPoint={() => setClickedPointWgs84(null)}
            onSaved={(newOid: number) => {
              const layerUrl = String(cfg.motherLayerUrl || readDynamicSelection().layerUrl || anyDs?.getDataSourceJson?.()?.url || anyDs?.dataSourceJson?.url || '')
              writeDynamicSelection({ oid: newOid, layerUrl, idFieldName: anyDs?.getIdField?.() || 'OBJECTID' })
            }}
          />
        ) : (
          <div style={{ padding: 12 }}>Datasource dinamica non pronta: configura il layer madre.</div>
        )
      ) : (
        activeGate?.state?.ds && activeGate?.state?.oid != null && activeGate?.state?.data ? (
          <NuovaPraticaForm
            mode='edit'
            ds={activeGate.state.ds}
            cfg={cfg}
            oid={activeGate.state.oid}
            initialData={activeGate.state.data}
            showDatiGenerali={showDatiGenerali}
            clickedPointWgs84={clickedPointWgs84}
            onClearPoint={() => setClickedPointWgs84(null)}
            onSaved={() => {}}
          />
        ) : (
          <div style={{ padding: 12, color: 'rgba(0,0,0,0.55)' }}>Selezionare una riga.</div>
        )
      )}
    </div>
  )
}
