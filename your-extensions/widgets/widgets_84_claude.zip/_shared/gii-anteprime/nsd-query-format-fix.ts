// Fix mirato per un bug noto di ArcGIS Online: la query in formato pbf (protocol
// buffer, preferito di default dalla ArcGIS JS API quando il servizio lo supporta)
// puo' restituire 400 dopo che sul layer sorgente sono stati aggiunti o alterati
// campi (qui: riferimento_attrezzatura_id allargato a 256 caratteri, matricola_snapshot
// e cauzione_decurtata aggiunti per la funzionalita' Art.30), anche quando i metadati
// del layer (f=json, usati da FeatureLayer.load()) riportano correttamente i nuovi
// campi come esistenti. Verificato: la stessa query con f=json invece di f=pbf
// funziona senza errori.
//
// Soluzione documentata dalla community Esri per questo esatto scenario: intercettare
// la risposta della chiamata di servizio (quella che popola layer.capabilities) e
// forzare supportedQueryFormats a 'JSON', cosi' la ArcGIS JS API non tenta piu' pbf
// per le query successive su questo layer.
//
// L'interceptor di esri/config e' un registro globale a livello di pagina browser:
// una sola registrazione (idempotente via flag su window, dato che ogni widget ExB
// bundla questo file come copia indipendente) basta per proteggere tutti i widget
// che interrogano questa vista nella stessa sessione.

function loadEsriModule<T = any> (path: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const req = (window as any).require
    if (!req) { reject(new Error('AMD require non disponibile')); return }
    req([path], (mod: T) => resolve(mod), (err: any) => reject(err))
  })
}

const NSD_PBF_FIX_FLAG = '__giiNsdJsonOnlyQueryFormatInstalled'
const NSD_URL_PATTERN = /GII_VIEW_EB_NOTA_SPESE_DETTAGLIO\/FeatureServer/i

export async function ensureNsdJsonOnlyQueryFormat (): Promise<void> {
  const w = window as any
  if (w[NSD_PBF_FIX_FLAG]) return
  w[NSD_PBF_FIX_FLAG] = true
  try {
    const esriConfig = await loadEsriModule<any>('esri/config')
    // IMPORTANTE: unshift, non push. ExB registra già propri interceptor (es. per i
    // token); se il nostro va in coda con push(), quelli lo precedono e la risposta
    // del describe-call viene già processata prima che il nostro after() la veda,
    // rendendo il fix inefficace pur senza errori. Verificato su thread community
    // Esri specifico per Experience Builder.
    esriConfig.request.interceptors.splice(0, 0, {
      urls: NSD_URL_PATTERN,
      after: (response: any) => {
        if (response?.data?.supportedQueryFormats) {
          response.data.supportedQueryFormats = 'JSON'
        }
      }
    })
  } catch {
    // Se il caricamento del modulo esri/config fallisce, consenti un nuovo tentativo
    // alla prossima chiamata invece di restare bloccati con il fix mai installato.
    w[NSD_PBF_FIX_FLAG] = false
  }
}
