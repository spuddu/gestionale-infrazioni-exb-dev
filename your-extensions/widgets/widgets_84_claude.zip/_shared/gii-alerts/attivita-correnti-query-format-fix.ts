// Stesso bug, stessa causa, stessa soluzione di _shared/gii-anteprime/nsd-query-format-fix.ts
// (vedi quel file per la spiegazione completa). Qui il layer coinvolto è
// GII_ATTIVITA_CORRENTI (tabella base) e le sue viste per area
// GII_VIEW_ATTIVITA_CORRENTI_AMM / _AGR / _TEC: la query in formato pbf
// (default della ArcGIS JS API) restituisce 400, mentre f=json funziona
// correttamente, anche se i metadati del layer riportano i campi come validi.
//
// Sintomo osservato: dopo un'azione che scrive/elimina un'attività corrente
// (es. presa in carico), la richiesta di query fallisce silenziosamente in
// console con 400, la scrittura non va a buon fine, e la campanella allarmi
// resta in uno stato incoerente (appare/scompare) finché qualcos'altro non
// la stabilizza.

function loadEsriModule<T = any> (path: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const req = (window as any).require
    if (!req) { reject(new Error('AMD require non disponibile')); return }
    req([path], (mod: T) => resolve(mod), (err: any) => reject(err))
  })
}

const ATTIVITA_CORRENTI_PBF_FIX_FLAG = '__giiAttivitaCorrentiJsonOnlyQueryFormatInstalled'
// Copre sia la tabella base (GII_ATTIVITA_CORRENTI) sia le viste per area
// (GII_VIEW_ATTIVITA_CORRENTI_AMM / _AGR / _TEC).
const ATTIVITA_CORRENTI_URL_PATTERN = /GII_(VIEW_)?ATTIVITA_CORRENTI(_AMM|_AGR|_TEC)?\/FeatureServer/i

export async function ensureAttivitaCorrentiJsonOnlyQueryFormat (): Promise<void> {
  const w = window as any
  if (w[ATTIVITA_CORRENTI_PBF_FIX_FLAG]) return
  w[ATTIVITA_CORRENTI_PBF_FIX_FLAG] = true
  try {
    const esriConfig = await loadEsriModule<any>('esri/config')
    // Vedi nsd-query-format-fix.ts per la spiegazione: unshift, non push.
    esriConfig.request.interceptors.splice(0, 0, {
      urls: ATTIVITA_CORRENTI_URL_PATTERN,
      after: (response: any) => {
        if (response?.data?.supportedQueryFormats) {
          response.data.supportedQueryFormats = 'JSON'
        }
      }
    })
  } catch {
    w[ATTIVITA_CORRENTI_PBF_FIX_FLAG] = false
  }
}
