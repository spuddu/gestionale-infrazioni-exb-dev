/** @jsx jsx */
/** @jsxFrag React.Fragment */
import { React, jsx, Immutable, DataSourceTypes, DataSourceManager } from 'jimu-core'
import type { AllWidgetSettingProps } from 'jimu-for-builder'
import { DataSourceSelector } from 'jimu-ui/advanced/data-source-selector'
import { IMConfig, defaultConfig, DEFAULT_COLUMNS } from '../config'
import type { ColumnDef } from '../config'

type Props = AllWidgetSettingProps<IMConfig>
type FieldOpt = { name: string; alias: string; type?: string }

const P = {
  wrap:  { padding:'0 12px 32px', fontSize:13, background:'#1a1f2e', minHeight:'100%', color:'#e5e7eb' } as React.CSSProperties,
  sec:   { fontSize:11, fontWeight:700, color:'#93c5fd', textTransform:'uppercase' as const, letterSpacing:1.2, borderBottom:'1px solid rgba(255,255,255,0.10)', paddingBottom:6, marginBottom:14, marginTop:22, cursor:'pointer', display:'flex', justifyContent:'space-between', alignItems:'center' } as React.CSSProperties,
  lbl:   { fontSize:11.5, fontWeight:600, color:'#d1d5db', display:'block', marginBottom:4, marginTop:10 } as React.CSSProperties,
  hint:  { fontSize:10.5, color:'#a0aec0', marginTop:3, lineHeight:1.4 } as React.CSSProperties,
  row2:  { display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 } as React.CSSProperties,
  row3:  { display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6 } as React.CSSProperties,
  inp:   { width:'100%', padding:'5px 8px', fontSize:12, border:'1px solid rgba(255,255,255,0.15)', borderRadius:6, outline:'none', boxSizing:'border-box' as const, background:'rgba(255,255,255,0.07)', color:'#e5e7eb' } as React.CSSProperties,
  grp:   { fontSize:11, fontWeight:700, color:'#93c5fd', marginTop:14, marginBottom:6, paddingBottom:4, borderBottom:'1px solid rgba(255,255,255,0.07)' } as React.CSSProperties,
}

const SELECT_OPTION_STYLE = { backgroundColor:'#ffffff', color:'#111827' } as React.CSSProperties
const SELECT_GROUP_STYLE = { backgroundColor:'#ffffff', color:'#111827' } as React.CSSProperties

const parseNum = (v:any, fb:number) => { const n=Number(v); return Number.isFinite(n)?n:fb }
function asJs<T=any>(v:any):T { return v?.asMutable?v.asMutable({deep:true}):v }
const toImmutable = Immutable as unknown as <T>(value: T) => any

function Inp(p: { value:string|number; onChange:(v:string)=>void; placeholder?:string }) {
  return <input type='text' value={p.value} onChange={e=>p.onChange(e.target.value)} placeholder={p.placeholder} style={P.inp}/>
}
function NumInp(p: { value:number; onChange:(v:number)=>void; min?:number; max?:number; step?:number; unit?:string }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:5 }}>
      <input type='number' value={p.value} min={p.min} max={p.max} step={p.step||1}
        onChange={e=>p.onChange(Number(e.target.value))} style={{ ...P.inp, width:68 }}/>
      {p.unit && <span style={{ fontSize:11, color:'#a0aec0', flexShrink:0 }}>{p.unit}</span>}
    </div>
  )
}
function ColInp(p: { value:string; onChange:(v:string)=>void }) {
  const hexVal = /^#[0-9a-fA-F]{3,8}$/.test(p.value) ? p.value : '#000000'
  return (
    <div style={{ display:'flex', alignItems:'center', gap:6 }}>
      <input type='color' value={hexVal} onChange={e=>p.onChange(e.target.value)}
        style={{ width:30, height:26, padding:2, border:'1px solid rgba(255,255,255,0.15)', borderRadius:5, cursor:'pointer', background:'transparent', flexShrink:0 }}/>
      <input type='text' value={p.value} onChange={e=>p.onChange(e.target.value)}
        placeholder='#rrggbb o rgba(...)' style={{ ...P.inp, flex:1, fontSize:11 }}/>
    </div>
  )
}
function Check(p: { value:boolean; onChange:(v:boolean)=>void; label:string }) {
  return (
    <label style={{ display:'flex', alignItems:'center', gap:8, fontSize:12, color:'#d1d5db', cursor:'pointer', marginTop:8 }}>
      <input type='checkbox' checked={p.value} onChange={e=>p.onChange(e.target.checked)}/>{p.label}
    </label>
  )
}
function Sel(p: { value:string; onChange:(v:string)=>void; options:Array<{value:string;label:string}> }) {
  return (
    <select value={p.value} onChange={e=>p.onChange(e.target.value)} style={{ ...P.inp, cursor:'pointer' }}>
      {p.options.map(o=><option key={o.value} value={o.value} style={SELECT_OPTION_STYLE}>{o.label}</option>)}
    </select>
  )
}

const VIRTUAL_FIELDS: FieldOpt[] = [
  { name:'__numero_rilevazione__', alias:'⚙ N. rilevazione (calcolato)', type:'virtual' },
  { name:'__numero_pratica__', alias:'⚙ N. rapporto (calcolato)', type:'virtual' },
  { name:'__tipo_pratica__', alias:'⚙ Tipo pratica (calcolato)', type:'virtual' },
  { name:'__numero_atto_accertamento_display__', alias:'⚙ N. atto (calcolato)', type:'virtual' },
  { name:'__stato_sint__', alias:'⚙ Stato pratica / Il mio stato (calcolato)', type:'virtual' },
  { name:'__fase_istruttoria__', alias:'⚙ Fase istruttoria (calcolato)', type:'virtual' },
  { name:'__ultimo_agg__', alias:'⚙ Ultimo aggiornamento sintetico (calcolato)', type:'virtual' },
  { name:'__causale__',    alias:'⚙ Oggetto / Stato (da LOG)', type:'virtual' },
  { name:'__mittente__',   alias:'⚙ Mittente (da LOG)', type:'virtual' },
  { name:'__prossima__',   alias:'⚙ Destinatario (calcolato)', type:'virtual' },
  { name:'__data_msg__',   alias:'⚙ Ultimo aggiornamento / Data messaggio (da LOG)', type:'virtual' },
]

const FALLBACK_LAYER_FIELDS: FieldOpt[] = [
  { name:'objectid', alias:'ObjectID', type:'esriFieldTypeOID' },
  { name:'data_rilevazione', alias:'Data rilevazione', type:'esriFieldTypeDate' },
  { name:'ufficio_zona', alias:'Ufficio origine', type:'esriFieldTypeString' },
  { name:'numero_rapporto_tecnico', alias:'Numero rapporto tecnico', type:'esriFieldTypeString' },
  { name:'data_rapporto_tecnico', alias:'Data rapporto tecnico', type:'esriFieldTypeDate' },
  { name:'numero_atto_accertamento', alias:'Numero atto', type:'esriFieldTypeString' },
  { name:'data_atto_accertamento', alias:'Data atto', type:'esriFieldTypeDate' },
  { name:'origine_pratica', alias:'Origine pratica', type:'esriFieldTypeInteger' },
  { name:'area_cod', alias:'Area origine', type:'esriFieldTypeString' },
  { name:'settore_cod', alias:'Settore origine', type:'esriFieldTypeString' },
  { name:'tecnico_rilevatore', alias:'Tecnico rilevatore', type:'esriFieldTypeString' },
  { name:'utente_loggato', alias:'Utente loggato', type:'esriFieldTypeString' }
]

function dedupeFieldOptions (fields: FieldOpt[]): FieldOpt[] {
  const seen = new Set<string>()
  const out: FieldOpt[] = []
  for (const f of fields || []) {
    const name = String(f?.name || '').trim()
    if (!name) continue
    const key = name.toLowerCase()
    if (seen.has(key)) continue
    seen.add(key)
    out.push({ name, alias: String(f?.alias || name), type: f?.type ? String(f.type) : undefined })
  }
  return out
}

function labelForConfiguredField (fieldName: string, columns: ColumnDef[]): string {
  const hit = (columns || []).find(c => String(c?.field || '').trim().toLowerCase() === fieldName.toLowerCase())
  return String(hit?.label || fieldName)
}

function mergeLayerFieldOptions (schemaFields: FieldOpt[], cfg: any, columns: ColumnDef[]): FieldOpt[] {
  const configuredFieldNames: FieldOpt[] = [
    cfg?.fieldPratica,
    cfg?.fieldDataRilevazione,
    cfg?.fieldUfficio,
    cfg?.orderByField,
    ...(columns || []).map(c => c?.field)
  ]
    .map(v => String(v || '').trim())
    .filter(v => v && !v.startsWith('__'))
    .map((name): FieldOpt => ({ name, alias: labelForConfiguredField(name, columns), type: undefined }))

  return dedupeFieldOptions([
    ...FALLBACK_LAYER_FIELDS,
    ...configuredFieldNames,
    ...(schemaFields || [])
  ]).sort((a, b) => (a.alias || a.name).localeCompare(b.alias || b.name, 'it', { sensitivity: 'base' }))
}

const BADGE_OGGETTO_KEYS = [
  'oggettoBadgeEnabled',
  'oggettoBadgeWidth',
  'oggettoBadgeContentOffset',
  'oggettoBadgeOpacity',
  'oggettoBadgeColorNuovaRilevazione',
  'oggettoBadgeColorAssegnazione',
  'oggettoBadgeColorTrasmissione',
  'oggettoBadgeColorIntegrazione',
  'oggettoBadgeColorApprovazione',
  'oggettoBadgeColorApprovazioneTecnica',
  'oggettoBadgeColorApprovazioneAmministrativa',
  'oggettoBadgeColorNotifica',
  'oggettoBadgeColorRespingimento',
  'oggettoBadgeColorNeutro'
] as const
function FieldSel(p: { value:string; fields:FieldOpt[]; onChange:(v:string)=>void; placeholder?:string; virtual?:boolean }) {
  if(!p.fields.length) return <Inp value={p.value} onChange={p.onChange} placeholder={p.placeholder||'nome campo'}/>
  return (
    <select style={P.inp} value={p.value} onChange={e=>p.onChange(e.target.value)}>
      <option value='' style={SELECT_OPTION_STYLE}>— seleziona —</option>
      {p.virtual && <optgroup label='Calcolati' style={SELECT_GROUP_STYLE}>{VIRTUAL_FIELDS.map(f=><option key={f.name} value={f.name} style={SELECT_OPTION_STYLE}>{f.alias}</option>)}</optgroup>}
      <optgroup label='Layer' style={SELECT_GROUP_STYLE}>{p.fields.map(f=><option key={f.name} value={f.name} style={SELECT_OPTION_STYLE}>{f.alias} ({f.name})</option>)}</optgroup>
    </select>
  )
}

function Acc(p: { id:string; label:string; open:boolean; onToggle:()=>void }) {
  return (
    <div style={P.sec} onClick={p.onToggle}>
      <span>{p.label}</span>
      <span style={{ fontSize:10, color:'#a0aec0' }}>{p.open?'▲':'▼'}</span>
    </div>
  )
}


function normalizeColumnLabel (label: any, field?: any): string {
  const s = String(label || '').trim()
  const f = String(field || '').trim().toLowerCase()
  if (f === '__numero_rilevazione__') return 'N. rilevazione'
  if (f === '__numero_pratica__') return 'N. rapporto'
  if (f === '__tipo_pratica__') return 'N. rilevazione'
  if (/^tipo\s+pratica$/i.test(s)) return 'N. rilevazione'
  if (/^n\.?\s*(rapporto|pratica)$/i.test(s) || /^numero$/i.test(s)) return 'N. rapporto'
  if (/^stato\s+rapporto$/i.test(s)) return 'Stato pratica'
  return s
}

function normalizeColumnForSave (col: any): any {
  if (!col || typeof col !== 'object') return col
  let field = String(col.field || '').trim()
  if (field.toLowerCase() === '__tipo_pratica__') field = '__numero_rilevazione__'
  return { ...col, field, label: normalizeColumnLabel(col.label, field) }
}

function normalizeColumnsForSave (columns: any[]): any[] {
  return (Array.isArray(columns) ? columns : []).map(normalizeColumnForSave)
}

function columnsHaveLegacyLabels (columns: any[]): boolean {
  if (!Array.isArray(columns)) return false
  return columns.some((col: any) => {
    if (!col || typeof col !== 'object') return false
    const normalized = normalizeColumnForSave(col)
    return String(normalized?.label || '') !== String(col.label || '').trim() ||
      String(normalized?.field || '') !== String(col.field || '').trim()
  })
}

function ColumnManager(p: { columns:ColumnDef[]; allFields:FieldOpt[]; onChange:(c:ColumnDef[])=>void }) {
  const cols = Array.isArray(p.columns) ? p.columns : []
  const [dragFrom, setDragFrom] = React.useState<number|null>(null)
  const [dragOver, setDragOver] = React.useState<number|null>(null)
  const upd = (i:number, patch:Partial<ColumnDef>) => p.onChange(cols.map((c,j)=>j===i?{...c,...patch}:c))
  const rem = (i:number) => p.onChange(cols.filter((_,j)=>j!==i))
  const add = () => p.onChange([...cols,{id:`col_${Date.now()}`,label:'Nuova colonna',field:'',width:150}])
  const move = (from:number, to:number) => {
    if(from===to||to<0||to>=cols.length) return
    const a=[...cols];const [m]=a.splice(from,1);a.splice(to,0,m);p.onChange(a)
  }
  const cb:React.CSSProperties = { padding:'10px 12px', borderRadius:8, border:'1px solid rgba(255,255,255,0.10)', background:'rgba(255,255,255,0.04)', marginBottom:8 }
  const ch:React.CSSProperties = { ...cb, borderColor:'#93c5fd', background:'rgba(59,130,246,0.10)' }
  const fi:React.CSSProperties = { ...P.inp, fontSize:12 }
  const btn:React.CSSProperties = { border:'1px solid rgba(255,255,255,0.12)', background:'rgba(255,255,255,0.06)', borderRadius:5, cursor:'pointer', fontSize:11, padding:'3px 6px', color:'#d1d5db' }
  const rb:React.CSSProperties  = { ...btn, borderColor:'rgba(252,165,165,0.3)', background:'rgba(239,68,68,0.10)', color:'#fca5a5' }
  return (
    <div style={{width:'100%'}}>
      {cols.map((col,idx)=>(
        <div key={col.id} draggable
          onDragStart={()=>setDragFrom(idx)} onDragOver={e=>{e.preventDefault();setDragOver(idx)}}
          onDrop={()=>{if(dragFrom!==null&&dragFrom!==idx)move(dragFrom,idx);setDragFrom(null);setDragOver(null)}}
          onDragEnd={()=>{setDragFrom(null);setDragOver(null)}}
          style={{...(dragOver===idx?ch:cb),opacity:dragFrom===idx?0.45:1}}>
          <div style={{display:'flex',alignItems:'center',gap:5,marginBottom:8}}>
            <span style={{cursor:'grab',fontSize:14,color:'rgba(255,255,255,0.35)',userSelect:'none'}}>☰</span>
            <span style={{flex:1,fontSize:11,fontWeight:700,color:'#93c5fd'}}>Col. {idx+1}</span>
            <button type='button' style={btn} disabled={idx===0} onClick={()=>move(idx,idx-1)}>▲</button>
            <button type='button' style={btn} disabled={idx===cols.length-1} onClick={()=>move(idx,idx+1)}>▼</button>
            <button type='button' style={rb} onClick={()=>rem(idx)}>✕</button>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 64px',gap:6,marginBottom:6}}>
            <div>
              <div style={{fontSize:10,color:'#a0aec0',marginBottom:3}}>Intestazione</div>
              <input type='text' style={fi} value={col.label} onChange={e=>upd(idx,{label:e.target.value})} placeholder='Intestazione'/>
            </div>
            <div>
              <div style={{fontSize:10,color:'#a0aec0',marginBottom:3}}>Largh.</div>
              <input type='number' style={{...fi,textAlign:'center'}} value={col.width} min={40} step={10} onChange={e=>upd(idx,{width:parseNum(e.target.value,120)})}/>
            </div>
          </div>
          <div style={{fontSize:10,color:'#a0aec0',marginBottom:3}}>Campo</div>
          <select style={fi} value={col.field} onChange={e=>upd(idx,{field:e.target.value})}>
            <option value='' style={SELECT_OPTION_STYLE}>— seleziona —</option>
            <optgroup label='Calcolati' style={SELECT_GROUP_STYLE}>{VIRTUAL_FIELDS.map(f=><option key={f.name} value={f.name} style={SELECT_OPTION_STYLE}>{f.alias}</option>)}</optgroup>
            <optgroup label='Layer' style={SELECT_GROUP_STYLE}>{(p.allFields||[]).map(f=><option key={f.name} value={f.name} style={SELECT_OPTION_STYLE}>{f.alias} ({f.name})</option>)}</optgroup>
          </select>
        </div>
      ))}
      <div style={{display:'flex',gap:6,marginTop:4}}>
        <button type='button' onClick={add}
          style={{flex:1,padding:'6px',borderRadius:8,border:'1px dashed rgba(147,197,253,0.4)',background:'rgba(59,130,246,0.08)',color:'#93c5fd',cursor:'pointer',fontSize:12,fontWeight:600}}>
          ＋ Aggiungi
        </button>
        <button type='button' onClick={()=>p.onChange(DEFAULT_COLUMNS.map(c=>({...c})))}
          style={{padding:'6px 10px',borderRadius:8,border:'1px solid rgba(255,255,255,0.12)',background:'rgba(255,255,255,0.05)',color:'#d1d5db',cursor:'pointer',fontSize:11}}>
          Reset
        </button>
      </div>
      {!cols.length && <div style={{...P.hint,marginTop:8}}>Nessuna colonna. Premi Reset.</div>}
    </div>
  )
}

export default function Setting(props: Props) {
  const cfgImm: any = props.config ?? defaultConfig
  const cfg: any = { ...asJs(defaultConfig), ...asJs(cfgImm) }
  const [openSec, setOpenSec] = React.useState<string>('dati')
  const toggle = (id:string) => setOpenSec(s=>s===id?'':id)
  const isOpen = (id:string) => openSec===id

  const toConfig = (patch: Record<string, any>) => {
    // Materializza l'oggetto di config prima di riscriverlo.
    // In alcuni casi ExB non serializza le nuove chiavi se si fa solo .set()
    // su una config storica che non le conteneva ancora.
    const current = asJs<Record<string, any>>(cfgImm) || {}
    return toImmutable({ ...current, ...patch }) as any
  }

  const update = (key:string, value:any) => {
    props.onSettingChange({ id:props.id, config:toConfig({ [key]: value }) })
  }

  const updateBadgeOggetto = (key:string, value:any) => {
    const patch: Record<string, any> = {}
    BADGE_OGGETTO_KEYS.forEach(k => { patch[k] = (cfg as any)[k] })
    patch[key] = value
    props.onSettingChange({ id:props.id, config:toConfig(patch) })
  }

  const dsTypes = toImmutable([DataSourceTypes.FeatureLayer]) as any
  const onDsChange = (useDataSources:any) => {
    const udsJs:any[]=asJs(useDataSources ?? toImmutable([]))
    const prevTabs:any[]=asJs(cfgImm.filterTabs ?? toImmutable([]))
    const dsm=DataSourceManager.getInstance()
    const nextTabs=udsJs.map(u=>{
      const dsId=String(u?.dataSourceId||'')
      const prev=prevTabs.find(t=>String(t?.dataSourceId||'')===dsId)
      if(prev) return prev
      let label='';try{const ds:any=dsm.getDataSource(dsId);label=String(ds?.getLabel?.()||'')}catch{}
      label=label&&label.trim()?label.trim():'Filtro'
      return {dataSourceId:dsId,label}
    })
    const c = cfgImm.set ? cfgImm : toImmutable(cfgImm)
    props.onSettingChange({id:props.id,useDataSources,config:c.set('filterTabs',nextTabs)})
  }

  const useDsImm:any = props.useDataSources ?? toImmutable([])
  const useDsJs:any[]=asJs(useDsImm)
  const primaryDsId=String(useDsJs?.[0]?.dataSourceId||'')
  const [fields,setFields]=React.useState<FieldOpt[]>([])

  React.useEffect(()=>{
    let cancelled=false
    const load=async()=>{
      if(!primaryDsId){if(!cancelled)setFields([]);return}
      try{
        const ds:any=DataSourceManager.getInstance().getDataSource(primaryDsId)
        const fobj=ds?.getSchema?.()?.fields||{}
        const opts:FieldOpt[]=Object.keys(fobj).map(name=>{const f=fobj[name]||{};return{name,alias:String(f.alias||name),type:String(f.type||'')}})
          .sort((a,b)=>(a.alias||a.name).localeCompare(b.alias||b.name,'it',{sensitivity:'base'}))
        if(!cancelled)setFields(opts)
      }catch{if(!cancelled)setFields([])}
    }
    load();return ()=>{cancelled=true}
  },[primaryDsId])

  const legacyDsJs:any[] = asJs(props.useDataSources ?? toImmutable([])) || []
  React.useEffect(()=>{
    if ((legacyDsJs?.length||0) > 0 || (props as any).useDataSourcesEnabled) {
      props.onSettingChange({ id: props.id, useDataSources: [] as any, useDataSourcesEnabled: false as any })
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  React.useEffect(() => {
    const raw = asJs<Record<string, any>>(cfgImm) || {}
    const patch: Record<string, any> = {}

    const rawColumns = asJs<any[]>(raw.columns) || []
    if (columnsHaveLegacyLabels(rawColumns)) {
      patch.columns = normalizeColumnsForSave(rawColumns)
    }

    const missing = BADGE_OGGETTO_KEYS.filter(k => raw[k] === undefined)
    if (missing.length) {
      BADGE_OGGETTO_KEYS.forEach(k => { patch[k] = (cfg as any)[k] })
    }

    if (!Object.keys(patch).length) return
    props.onSettingChange({ id: props.id, config: toConfig(patch) })
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const cfgJs:any=cfg
  const columns=(()=>{
    const raw=cfgJs?.columns;const cols:any[]=asJs(raw)
    if(Array.isArray(cols)&&cols.length>0) return cols.map((c:any)=>{
      const n = normalizeColumnForSave(c)
      return {id:String(n.id||`col_${Math.random().toString(36).slice(2,8)}`),label:String(n.label||''),field:String(n.field||''),width:parseNum(n.width,150)}
    })
    return DEFAULT_COLUMNS.map(c=>({...c}))
  })()
  const columnFieldOptions = mergeLayerFieldOptions(fields, cfgJs, columns)

  return (
    <div style={P.wrap}>

      <Acc id='dati' label='📊 Fonte dati' open={isOpen('dati')} onToggle={()=>toggle('dati')}/>
      {isOpen('dati') && <div>
        <div style={{...P.hint, marginTop: 8}}>
          La datasource del widget è ora risolta automaticamente a runtime in base a ruolo, area e settore dell’utente.
        </div>
        <div style={{...P.hint, marginTop: 8}}>
          Questo pannello non dichiara più Data Views / useDataSources per evitare il banner credenziali di Experience Builder.
        </div>
      </div>}

      <Acc id='colonne' label='📋 Colonne' open={isOpen('colonne')} onToggle={()=>toggle('colonne')}/>
      {isOpen('colonne') && <div>
        <div style={{...P.hint,marginBottom:10}}>Aggiungi, rimuovi e riordina. Trascina ☰ o usa ▲▼.</div>
        <ColumnManager columns={columns} allFields={columnFieldOptions} onChange={newCols=>update('columns',normalizeColumnsForSave(newCols))}/>
      </div>}

      <Acc id='query' label='🔍 Query e ordinamento' open={isOpen('query')} onToggle={()=>toggle('query')}/>
      {isOpen('query') && <div>
        <label style={P.lbl}>Where clause</label>
        <Inp value={cfg.whereClause||''} onChange={v=>update('whereClause',v)} placeholder='1=1'/>
        <div style={P.row2}>
          <div><label style={P.lbl}>Page size</label><NumInp value={cfg.pageSize} onChange={n=>update('pageSize',n)} min={1}/></div>
          <div><label style={P.lbl}>Direzione</label><Sel value={String(cfg.orderByDir||'DESC')} onChange={v=>update('orderByDir',v)} options={[{value:'DESC',label:'DESC'},{value:'ASC',label:'ASC'}]}/></div>
        </div>
        <label style={P.lbl}>Ordina per</label>
        <FieldSel value={cfg.orderByField} fields={columnFieldOptions} onChange={v=>update('orderByField',v)} placeholder='objectid'/>
        <Check value={cfg.showHeader!==false} onChange={v=>update('showHeader',v)} label='Mostra intestazioni colonne'/>
      </div>}

      <Acc id='righe' label='🎨 Stile righe' open={isOpen('righe')} onToggle={()=>toggle('righe')}/>
      {isOpen('righe') && <div>
        <div style={P.row3}>
          <div><label style={P.lbl}>Gap</label><NumInp value={cfg.rowGap} onChange={n=>update('rowGap',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Pad. X</label><NumInp value={cfg.rowPaddingX} onChange={n=>update('rowPaddingX',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Pad. Y</label><NumInp value={cfg.rowPaddingY} onChange={n=>update('rowPaddingY',n)} min={0} unit='px'/></div>
        </div>
        <div style={P.row3}>
          <div><label style={P.lbl}>Min H</label><NumInp value={cfg.rowMinHeight} onChange={n=>update('rowMinHeight',n)} min={24} unit='px'/></div>
          <div><label style={P.lbl}>Radius</label><NumInp value={cfg.rowRadius} onChange={n=>update('rowRadius',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Bordo</label><NumInp value={cfg.rowBorderWidth} onChange={n=>update('rowBorderWidth',n)} min={0} unit='px'/></div>
        </div>
        <label style={P.lbl}>Colore bordo riga</label>
        <ColInp value={String(cfg.rowBorderColor||'')} onChange={v=>update('rowBorderColor',v)}/>
        <div style={P.grp}>Colori</div>
        <div style={P.row2}>
          <div><label style={P.lbl}>Zebra pari</label><ColInp value={String(cfg.zebraEvenBg||'')} onChange={v=>update('zebraEvenBg',v)}/></div>
          <div><label style={P.lbl}>Zebra dispari</label><ColInp value={String(cfg.zebraOddBg||'')} onChange={v=>update('zebraOddBg',v)}/></div>
        </div>
        <div style={P.row2}>
          <div><label style={P.lbl}>Hover</label><ColInp value={String(cfg.hoverBg||'')} onChange={v=>update('hoverBg',v)}/></div>
          <div><label style={P.lbl}>Selezionata</label><ColInp value={String(cfg.selectedBg||'')} onChange={v=>update('selectedBg',v)}/></div>
        </div>
        <label style={P.lbl}>Bordo selezionata</label>
        <div style={P.row2}>
          <div><ColInp value={String(cfg.selectedBorderColor||'')} onChange={v=>update('selectedBorderColor',v)}/></div>
          <div><label style={P.lbl}>Spessore</label><NumInp value={cfg.selectedBorderWidth} onChange={n=>update('selectedBorderWidth',n)} min={0} unit='px'/></div>
        </div>
      </div>}

      <Acc id='badgeOggetto' label='▌ Badge oggetto' open={isOpen('badgeOggetto')} onToggle={()=>toggle('badgeOggetto')}/>
      {isOpen('badgeOggetto') && <div>
        <Check value={cfg.oggettoBadgeEnabled !== false} onChange={v=>updateBadgeOggetto('oggettoBadgeEnabled',v)} label='Mostra badge colorato in testa alla riga'/>
        <div style={P.row3}>
          <div><label style={P.lbl}>Larghezza</label><NumInp value={cfg.oggettoBadgeWidth} onChange={n=>updateBadgeOggetto('oggettoBadgeWidth',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Rientro testo</label><NumInp value={cfg.oggettoBadgeContentOffset} onChange={n=>updateBadgeOggetto('oggettoBadgeContentOffset',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Opacità</label><NumInp value={cfg.oggettoBadgeOpacity} onChange={n=>updateBadgeOggetto('oggettoBadgeOpacity',n)} min={0} max={1} step={0.05}/></div>
        </div>
        <div style={P.hint}>Il rientro testo viene applicato anche all’intestazione della prima colonna, così celle e header restano allineati.</div>
        <div style={P.grp}>Colori per oggetto</div>
        {([
          { name:'Nuova rilevazione', field:'oggettoBadgeColorNuovaRilevazione' },
          { name:'Assegnazione istruttoria', field:'oggettoBadgeColorAssegnazione' },
          { name:'Trasmissione istruttoria', field:'oggettoBadgeColorTrasmissione' },
          { name:'Richiesta / trasmissione integrazione', field:'oggettoBadgeColorIntegrazione' },
          { name:'Approvazione istruttoria tecnica', field:'oggettoBadgeColorApprovazioneTecnica' },
          { name:'Approvazione sanzione / istruttoria amministrativa', field:'oggettoBadgeColorApprovazioneAmministrativa' },
          { name:'Notifica / chiusura procedimento sanzionatorio', field:'oggettoBadgeColorNotifica' },
          { name:'Respingimento', field:'oggettoBadgeColorRespingimento' },
          { name:'Neutro / non classificato', field:'oggettoBadgeColorNeutro' }
        ] as const).map(({ name, field }) => (
          <div key={field} style={{ marginBottom:10 }}>
            <div style={{ fontSize:11, fontWeight:600, color:'#d1d5db', marginBottom:5, display:'flex', alignItems:'center', gap:8 }}>
              <span style={{ display:'inline-block', width:16, height:12, borderRadius:3, background:String((cfg as any)[field] || '#d0d0d0'), border:'1px solid rgba(255,255,255,0.25)' }}/>
              {name}
            </div>
            <ColInp value={String((cfg as any)[field] || '')} onChange={v=>updateBadgeOggetto(field,v)}/>
          </div>
        ))}
      </div>}

      <Acc id='chip' label='🔴 Chip stato' open={isOpen('chip')} onToggle={()=>toggle('chip')}/>
      {isOpen('chip') && <div>

        <div style={P.grp}>Forma</div>
        <div style={P.row3}>
          <div><label style={P.lbl}>Radius</label><NumInp value={cfg.statoChipRadius} onChange={n=>update('statoChipRadius',n)} min={0}/></div>
          <div><label style={P.lbl}>Pad. X</label><NumInp value={cfg.statoChipPadX} onChange={n=>update('statoChipPadX',n)} min={0}/></div>
          <div><label style={P.lbl}>Pad. Y</label><NumInp value={cfg.statoChipPadY} onChange={n=>update('statoChipPadY',n)} min={0}/></div>
        </div>
        <div style={P.row3}>
          <div><label style={P.lbl}>Bordo</label><NumInp value={cfg.statoChipBorderW} onChange={n=>update('statoChipBorderW',n)} min={0}/></div>
          <div><label style={P.lbl}>Font sz</label><NumInp value={cfg.statoChipFontSize} onChange={n=>update('statoChipFontSize',n)} min={8}/></div>
          <div><label style={P.lbl}>Font w</label><NumInp value={cfg.statoChipFontWeight} onChange={n=>update('statoChipFontWeight',n)} min={100} step={100}/></div>
        </div>
        <div style={P.row2}>
          <div>
            <label style={P.lbl}>Transform</label>
            <Sel value={String(cfg.statoChipTextTransform||'none')} onChange={v=>update('statoChipTextTransform',v)}
              options={[{value:'none',label:'none'},{value:'uppercase',label:'UPPERCASE'},{value:'lowercase',label:'lowercase'},{value:'capitalize',label:'Capitalize'}]}/>
          </div>
          <div><label style={P.lbl}>Letter spacing</label><NumInp value={cfg.statoChipLetterSpacing} onChange={n=>update('statoChipLetterSpacing',n)} step={0.1}/></div>
        </div>

        <div style={P.grp}>Colori</div>
        {([
          { name:'Giallo — Da prendere in carico',   bg:'chipBgGiallo',    text:'chipTextGiallo',    border:'chipBorderGiallo'    },
          { name:'Azzurro — Trasmesso',             bg:'chipBgAzzurro',   text:'chipTextAzzurro',   border:'chipBorderAzzurro'   },
          { name:'Celeste — In carico',              bg:'chipBgCeleste',   text:'chipTextCeleste',   border:'chipBorderCeleste'   },
          { name:'Verde — Pratica approvata',        bg:'chipBgVerde',     text:'chipTextVerde',     border:'chipBorderVerde'     },
          { name:'Arancione — In attesa di …',        bg:'chipBgArancione', text:'chipTextArancione', border:'chipBorderArancione' },
          { name:'Rosso — Respinto / Eliminato',      bg:'chipBgRosso',     text:'chipTextRosso',     border:'chipBorderRosso'     },
          { name:'Viola — Sanzione approvata',       bg:'chipBgViola',     text:'chipTextViola',     border:'chipBorderViola'     },
          { name:'Neutro — In corso di istruttoria',  bg:'chipBgNeutro',    text:'chipTextNeutro',    border:'chipBorderNeutro'    },
        ] as const).map(({ name, bg, text, border }) => (
          <div key={bg} style={{ marginBottom:12 }}>
            <div style={{ fontSize:11, fontWeight:600, color:'#d1d5db', marginBottom:5, display:'flex', alignItems:'center', gap:8 }}>
              <span style={{
                display:'inline-block', width:12, height:12, borderRadius:3, flexShrink:0,
                background: String((cfg as any)[bg] || '#ccc'),
                border: `1px solid ${String((cfg as any)[border] || '#999')}`
              }}/>
              {name}
            </div>
            <div style={P.row3}>
              <div><div style={{ fontSize:10, color:'#a0aec0', marginBottom:3 }}>Sfondo</div><ColInp value={String((cfg as any)[bg]||'')} onChange={v=>update(bg,v)}/></div>
              <div><div style={{ fontSize:10, color:'#a0aec0', marginBottom:3 }}>Testo</div><ColInp value={String((cfg as any)[text]||'')} onChange={v=>update(text,v)}/></div>
              <div><div style={{ fontSize:10, color:'#a0aec0', marginBottom:3 }}>Bordo</div><ColInp value={String((cfg as any)[border]||'')} onChange={v=>update(border,v)}/></div>
            </div>
          </div>
        ))}
      </div>}

      <Acc id='titolo' label='📝 Titolo elenco' open={isOpen('titolo')} onToggle={()=>toggle('titolo')}/>
      {isOpen('titolo') && <div>
        <label style={P.lbl}>Testo</label>
        <Inp value={String(cfg.listTitleText||'')} onChange={v=>update('listTitleText',v)} placeholder='Elenco pratiche'/>
        <div style={P.row3}>
          <div><label style={P.lbl}>Altezza</label><NumInp value={cfg.listTitleHeight} onChange={n=>update('listTitleHeight',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Font sz</label><NumInp value={cfg.listTitleFontSize} onChange={n=>update('listTitleFontSize',n)} min={10} unit='px'/></div>
          <div><label style={P.lbl}>Font w</label><NumInp value={cfg.listTitleFontWeight} onChange={n=>update('listTitleFontWeight',n)} min={100} step={100}/></div>
        </div>
        <div style={P.row2}>
          <div><label style={P.lbl}>Pad. bottom</label><NumInp value={cfg.listTitlePaddingBottom} onChange={n=>update('listTitlePaddingBottom',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Pad. left</label><NumInp value={cfg.listTitlePaddingLeft} onChange={n=>update('listTitlePaddingLeft',n)} min={0} unit='px'/></div>
        </div>
        <label style={P.lbl}>Colore testo</label>
        <ColInp value={String(cfg.listTitleColor||'rgba(0,0,0,0.85)')} onChange={v=>update('listTitleColor',v)}/>
      </div>}

      <Acc id='maschera' label='🖼 Maschera (bordo pannello)' open={isOpen('maschera')} onToggle={()=>toggle('maschera')}/>
      {isOpen('maschera') && <div>
        <div style={P.row2}>
          <div><label style={P.lbl}>Outer offset</label><NumInp value={cfg.maskOuterOffset} onChange={n=>update('maskOuterOffset',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Inner padding</label><NumInp value={cfg.maskInnerPadding} onChange={n=>update('maskInnerPadding',n)} min={0} unit='px'/></div>
        </div>
        <div style={P.row2}>
          <div><label style={P.lbl}>Border width</label><NumInp value={cfg.maskBorderWidth} onChange={n=>update('maskBorderWidth',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Border radius</label><NumInp value={cfg.maskRadius} onChange={n=>update('maskRadius',n)} min={0} unit='px'/></div>
        </div>
        <label style={P.lbl}>Background</label>
        <ColInp value={String(cfg.maskBg||'')} onChange={v=>update('maskBg',v)}/>
        <label style={P.lbl}>Colore bordo</label>
        <ColInp value={String(cfg.maskBorderColor||'')} onChange={v=>update('maskBorderColor',v)}/>
      </div>}

      <Acc id='layout' label='📐 Layout colonne' open={isOpen('layout')} onToggle={()=>toggle('layout')}/>
      {isOpen('layout') && <div>
        <div style={P.row2}>
          <div><label style={P.lbl}>Gap colonne</label><NumInp value={cfg.gap} onChange={n=>update('gap',n)} min={0} unit='px'/></div>
          <div><label style={P.lbl}>Pad. prima col.</label><NumInp value={cfg.paddingLeftFirstCol} onChange={n=>update('paddingLeftFirstCol',n)} min={0} unit='px'/></div>
        </div>
      </div>}

      <Acc id='msg' label='💬 Messaggi' open={isOpen('msg')} onToggle={()=>toggle('msg')}/>
      {isOpen('msg') && <div>
        <label style={P.lbl}>Nessun risultato</label>
        <Inp value={String(cfg.emptyMessage||'')} onChange={v=>update('emptyMessage',v)}/>
        <label style={P.lbl}>Errore: nessun datasource</label>
        <Inp value={String(cfg.errorNoDs||'')} onChange={v=>update('errorNoDs',v)}/>
      </div>}

      <div style={{marginTop:28,borderTop:'1px solid rgba(255,255,255,0.10)',paddingTop:16}}>
        <button type='button'
          onClick={()=>{if(window.confirm('Ripristinare tutti i valori predefiniti?'))props.onSettingChange({id:props.id,config:defaultConfig as any})}}
          style={{padding:'6px 14px',borderRadius:7,border:'1px solid rgba(252,165,165,0.4)',background:'rgba(239,68,68,0.10)',color:'#fca5a5',fontSize:12,cursor:'pointer',fontWeight:600}}>
          ↺ Ripristina predefiniti
        </button>
      </div>
    </div>
  )
}
