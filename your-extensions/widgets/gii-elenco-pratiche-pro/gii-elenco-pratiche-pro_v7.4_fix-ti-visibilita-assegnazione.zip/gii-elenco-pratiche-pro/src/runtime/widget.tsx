/** @jsx jsx */
/** @jsxFrag React.Fragment */
import {
  React,
  jsx,
  css,
  DataSourceComponent,
  DataSourceStatus,
  type DataRecord,
  type DataSource,
  DataSourceManager,
  SessionManager,
  Immutable
} from 'jimu-core'

import { Button, Loading } from 'jimu-ui'
import type { AllWidgetProps } from 'jimu-core'
import type { IMConfig, ColumnDef } from '../config'
import { defaultConfig, DEFAULT_COLUMNS } from '../config'

type Props = AllWidgetProps<IMConfig>

function getCodPraticaDisplay(rec: DataRecord): string {
  const a: any = rec?.getData?.() || {}
  const oid =
    a?.OBJECTID ?? a?.ObjectId ?? a?.objectid ?? a?.objectId
  // 1=TR, 2=TI (se presente). Se non presente, fallback su datasource id.
  let prefix = 'TR'
  const op = a?.origine_pratica
  if (op === 2 || op === '2') prefix = 'TI'
  else if (op === 1 || op === '1') prefix = 'TR'
  else {
    const dsId = String((rec as any)?.dataSource?.id || '').toLowerCase()
    if (dsId.includes('gii_pratiche') || dsId.includes('schema') || dsId.includes('ti')) prefix = 'TI'
  }
  return oid != null ? `${prefix}-${oid}` : `${prefix}-?`
}

type SortDir = 'ASC' | 'DESC'
type SortItem = { field: string, dir: SortDir }

// Campi virtuali (ordinamento su campi calcolati)
const V_STATO = '__stato_sint__'
const V_ULTIMO = '__ultimo_agg__'
const V_PROSSIMA = '__prossima__'

function num (v: any, fallback: number): number {
  const n = Number(v)
  return Number.isFinite(n) ? n : fallback
}
function txt (v: any): string {
  if (v === null || v === undefined) return ''
  return String(v)
}
function asJs<T = any> (v: any): T {
  return v?.asMutable ? v.asMutable({ deep: true }) : v
}

function parseToMs (v: any): number | null {
  if (v === null || v === undefined || v === '') return null
  if (typeof v === 'number' && Number.isFinite(v)) return v
  if (v instanceof Date) return Number.isNaN(v.getTime()) ? null : v.getTime()
  const s = String(v)
  const t = Date.parse(s)
  return Number.isNaN(t) ? null : t
}

function formatDateIt (v: any): string {
  if (v === null || v === undefined || v === '') return ''
  let d: Date | null = null
  if (typeof v === 'number') d = new Date(v)
  else if (typeof v === 'string') {
    const t = Date.parse(v)
    if (!Number.isNaN(t)) d = new Date(t)
  } else if (v instanceof Date) d = v
  if (!d || Number.isNaN(d.getTime())) return txt(v)
  return new Intl.DateTimeFormat('it-IT', {
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit'
  }).format(d)
}

function getDsLabel (useDs: any, fallback: string): string {
  try {
    const ds = DataSourceManager.getInstance().getDataSource(useDs?.dataSourceId)
    const label = ds?.getLabel?.()
    return (label && String(label).trim()) ? String(label) : fallback
  } catch {
    return fallback
  }
}

function trySelectRecord (ds: any, record: DataRecord, recordId: string) {
  try { ds.selectRecordsByIds?.([recordId]) } catch {}
  try { ds.selectRecordById?.(recordId) } catch {}
  try { ds.setSelectedRecords?.([record]) } catch {}
}

function tryClearSelection (ds: any) {
  try { ds.selectRecordsByIds?.([]) } catch {}
  try { ds.clearSelection?.() } catch {}
  try { ds.setSelectedRecords?.([]) } catch {}
}

function notifySelectionCleared () {
  try {
    sessionStorage.removeItem('GII_SELECTED_OID')
    window.dispatchEvent(new CustomEvent('gii-selection-changed'))
  } catch {}
}

function compareValues (a: any, b: any): number {
  const aNull = (a === null || a === undefined || a === '')
  const bNull = (b === null || b === undefined || b === '')
  if (aNull && bNull) return 0
  if (aNull) return 1
  if (bNull) return -1

  if (typeof a === 'number' && typeof b === 'number') return a - b

  const aStr = String(a)
  const bStr = String(b)

  // date?
  const aDate = Date.parse(aStr)
  const bDate = Date.parse(bStr)
  if (!Number.isNaN(aDate) && !Number.isNaN(bDate)) return aDate - bDate

  return aStr.localeCompare(bStr, 'it', { numeric: true, sensitivity: 'base' })
}

function sortSig (s: SortItem[]): string {
  return (s || []).map(x => `${x.field}:${x.dir}`).join('|')
}

function migrateColumns (cfg: any): ColumnDef[] {
  const raw = cfg?.columns
  const cols: any[] = asJs(raw)
  if (Array.isArray(cols) && cols.length > 0) {
    return cols.map((c: any) => ({
      id: String(c.id || ''),
      label: String(c.label || ''),
      field: String(c.field || ''),
      width: num(c.width, 150)
    }))
  }
  return DEFAULT_COLUMNS.map(c => ({ ...c }))
}

/**
 * Componente figlio di DataSourceComponent — raccoglie i record e li segnala al parent.
 * Usa useEffect con signature stabile per evitare loop infiniti.
 */
function RecordTracker (p: {
  ds: DataSource
  dsId: string
  info: any
  onUpdate: (dsId: string, recs: DataRecord[], ds: DataSource, loading: boolean) => void
}) {
  const recs: DataRecord[] = (p.ds?.getRecords?.() ?? []) as DataRecord[]
  const status = p.info?.status ?? p.ds?.getStatus?.() ?? DataSourceStatus.NotReady
  const isLoading = status === DataSourceStatus.Loading

  // Signature completa: status + conteggio + JSON di tutti i valori del primo record.
  // Cattura il lazy-loading dei campi (quando i valori passano da undefined a valorizzati).
  let dataSig = ''
  if (recs.length > 0) {
    try { dataSig = JSON.stringify(recs[0].getData?.() || {}) }
    catch { dataSig = String(recs.length) }
  }
  const sig = `${status}:${recs.length}:${dataSig}`

  const prevSig = React.useRef('')
  React.useEffect(() => {
    if (sig !== prevSig.current) {
      prevSig.current = sig
      p.onUpdate(p.dsId, recs, p.ds, isLoading)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig])

  return null
}

const GII_PORTAL    = 'https://cbsm-hub.maps.arcgis.com'


// Best-effort: prova a capire se l'utente è amministratore AGOL (org_admin),
// anche quando l'Header non valorizza isAdmin.
function inferIsOrgAdminFromSession (): boolean {
  try {
    const sm = SessionManager.getInstance()
    const session: any = sm?.getMainSession?.() || sm?.getSessionByUrl?.(GII_PORTAL)
    const role =
      session?.user?.role ??
      session?.userInfo?.role ??
      session?.portalUser?.role ??
      session?.portal?.user?.role ??
      session?.portal?.userInfo?.role ??
      session?.portalSelf?.user?.role ??
      session?.portalSelf?.user?.userRole ??
      session?.userRole

    if (role) {
      const r = String(role).toLowerCase()
      if (r.includes('admin')) return true
    }

    const priv =
      session?.user?.privileges ??
      session?.userInfo?.privileges ??
      session?.portalUser?.privileges ??
      session?.portal?.user?.privileges ??
      session?.portal?.userInfo?.privileges

    if (Array.isArray(priv)) {
      const p = priv.map(x => String(x).toLowerCase())
      if (p.some(x => x.includes('portal:admin') || x.includes('portal:administrator') || x.includes('orgadmin') || x.includes('administrator'))) {
        return true
      }
    }

    if (session?.isAdmin === true) return true
  } catch {}
  return false
}

function computeDsMetaSig (useDsList: any[]): string {
  try {
    return (useDsList || []).map((u: any) => {
      const dsId = String(u?.dataSourceId || '')
      const ds = DataSourceManager.getInstance().getDataSource(dsId)
      const label = String(ds?.getLabel?.() || '')
      const j: any = ds?.getDataSourceJson?.() || (ds as any)?.dataSourceJson
      const url = String(j?.url || '')
      return `${dsId}|${label}|${url}`
    }).join('||')
  } catch {
    return ''
  }
}

function getServiceKeyFromDataSourceId (dsId: string): string {
  try {
    const ds = DataSourceManager.getInstance().getDataSource(dsId)
    const j: any = ds?.getDataSourceJson?.() || (ds as any)?.dataSourceJson
    const url = String(j?.url || '')
    const part = url.split('/rest/services/')[1] || ''
    const name = (part.split('/FeatureServer')[0] || '').trim()
    if (name) return name.toUpperCase()
    const lbl = String(ds?.getLabel?.() || '').trim()
    return lbl ? lbl.toUpperCase() : dsId
  } catch {
    return dsId
  }
}

function getRecordUniqKey (rec: DataRecord, dsId: string, svcCache: Map<string, string>): string {
  const svc = svcCache.get(dsId) || (svcCache.set(dsId, getServiceKeyFromDataSourceId(dsId)), svcCache.get(dsId)!)
  const d: any = rec?.getData?.() || {}
  const gid = d?.GlobalID ?? d?.globalid ?? d?.globalId ?? d?.GLOBALID ?? null
  if (gid !== null && gid !== undefined && String(gid).trim() !== '') return `GID|${String(gid).trim()}`
  const oid = d?.OBJECTID ?? d?.ObjectId ?? d?.objectid ?? d?.objectId ?? null
  if (oid !== null && oid !== undefined && String(oid).trim() !== '') return `${svc}|OID|${String(oid).trim()}`
  const rid = (rec as any)?.getId?.() || (rec as any)?.id || ''
  return `${svc}|RID|${String(rid)}`
}

// Mappa codice ruolo numerico → label (dal widget gestione utenti)
const RUOLO_LABEL: Record<number, string> = {
  1: 'TR', 2: 'TI', 3: 'RZ', 4: 'RI', 5: 'DT', 6: 'DA', 7: 'ADMIN'
}

// Gerarchia priorità per utenti con gruppi multipli (es. admin)
const RUOLO_PRIORITY: Record<number, number> = {
  6: 100, // DA  (massima priorità)
  5: 90,  // DT
  4: 80,  // RI
  3: 70,  // RZ
  2: 60,  // TI
  1: 10   // TR
}

// ── Mappa ruolo/area/settore → dataSourceId consentito ─────────────────────
// Codici domini (numerici):
//   AREA: AMM=1, AGR=2, TEC=3
//   SETTORE: CR=1,GI=2,D1=3,D2=4,D3=5,D4=6,D5=7,D6=8,CS=9
//   RUOLO: TR=1,TI=2,RZ=3,RI=4,DT=5,DA=6
function getAllowedDataSourceIds(
  user: { ruolo: number|null, area: number|null, settore: number|null, isAdmin: boolean } | null,
  useDsList: any[]
): string[] | null {
  if (!user) return null

  // Helper: label (titolo) del datasource, normalizzato
  const getLabel = (useDs: any): string => {
    try {
      const ds = DataSourceManager.getInstance().getDataSource(String(useDs?.dataSourceId || ''))
      const label = ds?.getLabel?.()
      return String(label || '')
    } catch { return '' }
  }
  const norm = (s: string) => String(s || '').toUpperCase()

  const AREA_CODE: Record<number, string> = { 1:'AMM', 2:'AGR', 3:'TEC' }
  const SETTORE_CODE: Record<number, string> = { 1:'CR', 2:'GI', 3:'D1', 4:'D2', 5:'D3', 6:'D4', 7:'D5', 8:'D6', 9:'CS' }

  const areaCode = (user.area != null ? AREA_CODE[user.area] : '') || ''
  const settoreCode = (user.settore != null ? SETTORE_CODE[user.settore] : '') || ''
  const ruolo = user.ruolo

  const roots = (arr: any[]) => Array.from(new Set(arr.map(u => String(u?.rootDataSourceId || u?.dataSourceId || '')).filter(Boolean)))

  // Admin: preferisci la vista EB_ADMIN (se presente), altrimenti non filtrare
  if (user.isAdmin) {
    const adminMatches = useDsList.filter(u => {
      const L = norm(getLabel(u))
      return L.includes('GII_VIEW_EB_ADMIN') || L.includes('VIEW_EB_ADMIN') || L.includes('_EB_ADMIN') || L.includes('EB_ADMIN')
    })
    const r = roots(adminMatches)
    return r.length ? r : null
  }

  const isEB = (L: string) => L.includes('GII_VIEW_EB_') || L.includes('VIEW_EB_') || L.includes('_EB_')

  // Match "strict" (settore per AGR per TR/TI/RZ, e "tutte" per RI/DT/DA)
  const matchesStrict = useDsList.filter(u => {
    const L = norm(getLabel(u))
    if (!isEB(L)) return false
    if (L.includes('EB_ADMIN')) return false
    if (areaCode && !L.includes(`EB_${areaCode}`)) return false

    if (ruolo != null && ruolo >= 1 && ruolo <= 3) {
      if (areaCode === 'AGR') return settoreCode ? L.includes(`_${settoreCode}`) : true
      return true
    }

    if (ruolo != null && ruolo >= 4 && ruolo <= 6) {
      if (areaCode === 'AGR') return (L.includes('TUTTE') || L.includes('TUTTI') || (!L.includes('_D1') && !L.includes('_D2') && !L.includes('_D3') && !L.includes('_D4') && !L.includes('_D5') && !L.includes('_D6')))
      return true
    }
    return true
  })

  // Loose fallback: qualunque vista EB della stessa area (escluso ADMIN)
  const matchesLoose = matchesStrict.length ? matchesStrict : useDsList.filter(u => {
    const L = norm(getLabel(u))
    if (!isEB(L)) return false
    if (L.includes('EB_ADMIN')) return false
    return areaCode ? L.includes(`EB_${areaCode}`) : true
  })

  const ids = roots(matchesLoose)
  // Se non riusciamo a determinare alcuna vista coerente (label non ancora pronta / nomi non standard),
  // NON filtriamo: lasciamo che sia la condivisione AGOL a fare da guardia.
  return ids.length ? ids : null
}

// ── Selezione DS “singolo” (evita duplicati e mismatch) ───────────────────
// Sceglie UNA vista tra quelle collegate, basandosi sul nome servizio nella URL
// (più stabile del label e degli id interni dataSource_XX).
function pickBestUseDataSourceId(
  user: { ruolo: number | null, ruoloLabel?: string, area: number | null, settore: number | null, gruppo?: string, isAdmin: boolean } | null,
  useDsList: any[]
): string | null {
  if (!user || !Array.isArray(useDsList) || useDsList.length === 0) return null

  const up = (s: any) => String(s || '').toUpperCase()
  const AREA_CODE: Record<number, string> = { 1: 'AMM', 2: 'AGR', 3: 'TEC' }
  const SETTORE_CODE: Record<number, string> = { 1: 'CR', 2: 'GI', 3: 'D1', 4: 'D2', 5: 'D3', 6: 'D4', 7: 'D5', 8: 'D6', 9: 'CS' }

  const areaCode = (user.area != null ? AREA_CODE[user.area] : '') || ''
  const settoreCode = (user.settore != null ? SETTORE_CODE[user.settore] : '') || ''
  const ruolo = user.ruolo
  const ruoloLabel = up((user as any)?.ruoloLabel)
  const gruppo = up((user as any)?.gruppo)

  const getServiceName = (useDs: any): string => {
    try {
      const ds = DataSourceManager.getInstance().getDataSource(String(useDs?.dataSourceId || ''))
      const j: any = (ds as any)?.getDataSourceJson?.() || (ds as any)?.dataSourceJson
      const url = String(j?.url || '')
      const part = url.split('/rest/services/')[1] || ''
      const name = part.split('/FeatureServer')[0] || ''
      return up(name)
    } catch {
      return ''
    }
  }

  // Fallback su label del DataSource (utile in preview/prime render quando la URL non è ancora pronta)
  const getLabelUp = (useDs: any): string => up(getDsLabel(useDs, ''))

  const items = useDsList.map(u => ({ dsId: String(u?.dataSourceId || ''), name: getServiceName(u) }))
  const findBy = (pred: (n: string) => boolean) => {
    const hit = items.find(x => x.dsId && x.name && pred(x.name))
    return hit?.dsId || null
  }

  // “Admin applicativo”: org_admin oppure ruolo DA/DT/RI oppure gruppo contiene ADMIN.
  const isAppAdmin = user.isAdmin || ruolo === 7 || ruoloLabel === 'ADMIN' || ruoloLabel === 'DA' || ruoloLabel === 'DT' || ruoloLabel === 'RI' || gruppo.includes('ADMIN')
  if (isAppAdmin) {
    const dsAdmin = findBy(n => n.includes('EB_ADMIN') || n.includes('GII_VIEW_EB_ADMIN') || n.includes('VIEW_EB_ADMIN'))
    if (dsAdmin) return dsAdmin

    // Fallback: se il serviceName non è ancora disponibile (preview/prime render),
    // prova a riconoscere la vista ADMIN dal *label* del DataSource.
    const hitByLabel = useDsList.find(u => {
      const L = getLabelUp(u)
      return L.includes('EB_ADMIN') || L.includes('GII_VIEW_EB_ADMIN') || L.includes('VIEW_EB_ADMIN') || L.includes('_EB_ADMIN')
    })
    if (hitByLabel?.dataSourceId) return String(hitByLabel.dataSourceId)
  }

  // area+settore
  if (areaCode) {
    if (settoreCode) {
      const dsAreaSett = findBy(n => n.includes(`EB_${areaCode}_${settoreCode}`) || n.includes(`_${areaCode}_${settoreCode}`))
      if (dsAreaSett) return dsAreaSett
    }
    // viste "TUTTE" per ruoli superiori
    if (ruolo != null && ruolo >= 4 && ruolo <= 6) {
      const dsTutte = findBy(n => n.includes(`EB_${areaCode}_TUTTE`) || n.includes(`EB_${areaCode}_TUTTI`))
      if (dsTutte) return dsTutte
    }
    const dsArea = findBy(n => n.includes(`EB_${areaCode}`) || n.includes(`_${areaCode}`))
    if (dsArea) return dsArea
  }

  // fallback admin view
  if (isAppAdmin) {
    const dsAdminFallback = findBy(n => n.includes('EB_ADMIN') || n.includes('GII_VIEW_EB_ADMIN') || n.includes('VIEW_EB_ADMIN'))
    if (dsAdminFallback) return dsAdminFallback

    const hitByLabel = useDsList.find(u => {
      const L = getLabelUp(u)
      return L.includes('EB_ADMIN') || L.includes('GII_VIEW_EB_ADMIN') || L.includes('VIEW_EB_ADMIN') || L.includes('_EB_ADMIN')
    })
    if (hitByLabel?.dataSourceId) return String(hitByLabel.dataSourceId)
  }

  // Se non troviamo match affidabili, evitiamo di forzare un singolo DS “a caso”.
  // Lasciamo al widget la gestione multi-DS (tabs) o i filtri allowedDsIds.
  return items.length === 1 ? (items[0]?.dsId || null) : null
}

interface GiiUserInfo {
  username: string
  ruolo: number | null       // codice numerico (1-6)
  ruoloLabel: string         // 'TR','TI','RZ','RI','DT','DA'
  area: number | null
  settore: number | null
  ufficio: number | null
  gruppo: string
  isAdmin: boolean           // org_admin AGOL
}

// Legge il profilo utente caricato dall'Header (unica fonte).
function readGiiUserFromHeader(): GiiUserInfo | null {
  const cached: any = (window as any).__giiUserRole
  if (!cached?.username) return null

  const ruolo = cached.ruolo != null ? Number(cached.ruolo) : null
  const gruppo = String(cached.gruppo || '')
  const inferredAdmin = inferIsOrgAdminFromSession()
  const inferredAppAdmin = gruppo.toUpperCase().includes('ADMIN')
  const isWorkflowAdmin = (ruolo === 7) || (String(cached.ruoloLabel || '').toUpperCase() === 'ADMIN') || !!cached.isWorkflowAdmin
  const isAdmin = !!cached.isAdmin || inferredAdmin || inferredAppAdmin || isWorkflowAdmin

  let ruoloLabel = String(
    cached.ruoloLabel ||
    (ruolo != null ? (RUOLO_LABEL[ruolo] ?? '') : (isAdmin ? 'ADMIN' : ''))
  )

  // Non forziamo più 'AMM': il ruolo workflow resta quello reale.
  // Se è un admin (org_admin o workflow admin) senza ruolo esplicito, mostriamo 'ADMIN'.
  if ((!ruoloLabel || !ruoloLabel.trim()) && isAdmin) ruoloLabel = 'ADMIN'

  return {
    username: String(cached.username),
    ruolo,
    ruoloLabel,
    area: cached.area != null ? Number(cached.area) : null,
    settore: cached.settore != null ? Number(cached.settore) : null,
    ufficio: cached.ufficio != null ? Number(cached.ufficio) : null,
    gruppo,
    isAdmin
  }
}

// Verifica rapida: esiste un utente autenticato (senza chiamate di rete)
function isSignedInNow(): boolean {
  try {
    const sm = SessionManager.getInstance()
    const session: any = sm?.getMainSession?.() || sm?.getSessionByUrl?.(GII_PORTAL)
    const u = session?.username || session?.userId || ''
    return !!u
  } catch { return false }
}

// Determina il campo stato del ruolo corrente
function getStatoFieldForRuolo(ruoloLabel: string): string {
  const r = ruoloLabel.toUpperCase()
  if (r === 'TR') return 'stato_TR'
  if (r === 'TI') return 'stato_TI'
  if (r === 'RZ') return 'stato_RZ'
  if (r === 'RI') return 'stato_RI'
  if (r === 'DT') return 'stato_DT'
  if (r === 'DA') return 'stato_DA'
  return 'stato_DT' // fallback
}

// Priorità ordinamento: In attesa mia (0,1,3) prima, poi In lavorazione (2), poi altri
function getPriorityForStato(statoVal: number | null): number {
  if (statoVal === 0 || statoVal === 1 || statoVal === 3) return 0  // In attesa mia → in cima
  if (statoVal === 2) return 1                                       // In lavorazione
  if (statoVal === 4) return 2                                       // Trasmesso
  if (statoVal === 5) return 3                                       // Respinto
  return 4                                                            // null / altri
}

export default function Widget (props: Props) {
  const cfg: any = (props.config ?? defaultConfig) as any

  const useDsImm: any = props.useDataSources ?? Immutable([])
  const useDsJs: any[] = asJs(useDsImm)

  // ── Rilevamento ruolo utente loggato ──────────────────────────────────────
  const [giiUser, setGiiUser] = React.useState<GiiUserInfo | null>(null)
  const [userLoading, setUserLoading] = React.useState(true)
  // notLogged: true quando non c'è utente autenticato → overlay bloccante
  const [notLogged, setNotLogged] = React.useState(false)

  // Firma metadata datasource (label/url) per ricalcolare bestDsId quando ExB popola i datasource
  const [dsMetaSig, setDsMetaSig] = React.useState('')


  // --- Selection bridge boot reset ---
  // La selezione NON deve persistere tra refresh/riapertura pagina.
  // Facciamo il reset UNA sola volta per page-load qui nell'Elenco (source of truth),
  // cosi Azioni non mostra mai il record precedente quando l'Elenco non ha selezione.
  React.useEffect(() => {
    try {
      const w: any = window as any
      if (w.__giiSelBootCleared) return
      w.__giiSelBootCleared = true
    } catch {}
    notifySelectionCleared()
  }, [])

// ── Bootstrap contesto utente (solo dall'Header) ─────────────────────────
React.useEffect(() => {
  let cancelled = false

  const apply = () => {
    if (cancelled) return

    const u = readGiiUserFromHeader()
    if (u) {
      setGiiUser(u)
      setNotLogged(false)
      setUserLoading(false)
      return
    }

    // Nessun profilo dall'Header:
    // - non autenticato → overlay "Accesso richiesto"
    // - autenticato ma profilo non ancora pronto → resta in loading
    if (!isSignedInNow()) {
      setGiiUser(null)
      setNotLogged(true)
      setUserLoading(false)
    } else {
      setGiiUser(null)
      setNotLogged(false)
      setUserLoading(true)
    }
  }

  apply()
  window.addEventListener('gii:userLoaded', apply)
  return () => {
    cancelled = true
    window.removeEventListener('gii:userLoaded', apply)
  }
}, [])

// DataSource consentiti per l'utente corrente
  const allowedDsIds: string[] | null = React.useMemo(
    () => giiUser ? getAllowedDataSourceIds(giiUser, useDsJs) : null,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [giiUser?.username, giiUser?.ruolo, giiUser?.area, giiUser?.settore, giiUser?.isAdmin, useDsJs.length]
  )

  // DS “migliore” (singolo) per evitare duplicazioni e mismatch tra viste
  const bestDsId: string | null = React.useMemo(
    () => giiUser ? pickBestUseDataSourceId(giiUser as any, useDsJs) : null,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [giiUser?.username, giiUser?.ruolo, giiUser?.area, giiUser?.settore, giiUser?.isAdmin, (giiUser as any)?.gruppo, useDsJs.length, dsMetaSig]
  )

  // useDsJs filtrato: solo i datasource consentiti per il ruolo dell'utente
  const filteredUseDsJs: any[] = React.useMemo(() => {
    if (!giiUser || userLoading || notLogged) return useDsJs // non ancora loggato: passa tutti (ma overlay copre)

    // Se troviamo un DS migliore, usa SOLO quello.
    if (bestDsId) {
      const hit = useDsJs.find((u: any) => String(u?.dataSourceId || '') === bestDsId)
      return hit ? [hit] : useDsJs
    }

    if (allowedDsIds === null) return useDsJs // admin: tutti
    return useDsJs.filter((u: any) => {
      // allowedDsIds contiene i rootDataSourceId (es. "dataSource_39")
      // mentre useDataSources usa dataSourceId (es. "dataSource_39-0").
      // Confrontiamo quindi il rootDataSourceId per non filtrare via TUTTI i DS online.
      const rootId = String(u?.rootDataSourceId || '')
      return allowedDsIds.includes(rootId)
    })
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [giiUser, userLoading, notLogged, bestDsId, allowedDsIds, useDsJs.length])

  // Campo stato del ruolo corrente
  const statoRuoloField = giiUser?.isAdmin
    ? null
    : giiUser?.ruoloLabel
      ? getStatoFieldForRuolo(giiUser.ruoloLabel)
      : null

  // ── Tab ruolo: Tutte / In attesa mia / In attesa di altri ────────────────────
  const ROLE_TABS = [
    { id: 'tutte',        label: 'Tutte le pratiche' },
    { id: 'attesa_mia',   label: 'In attesa mia' },
    { id: 'attesa_altri', label: 'In attesa di altri' },
  ]
  const [activeRoleTab, setActiveRoleTab] = React.useState<string>('tutte')

  // Funzione filtro per tab ruolo
  const passesRoleTab = React.useCallback((r: DataRecord, tabId: string): boolean => {
    if (!statoRuoloField || tabId === 'tutte') return true
    const role = String(giiUser?.ruoloLabel || '').toUpperCase()

    const d = r.getData?.() || {}
    const val = d[statoRuoloField]
    const n = val != null ? Number(val) : null

    // Default: come prima
    const isAttesaMiaDefault = (n === 0 || n === 1 || n === 3)
    const isAttesaAltriDefault = (n === 2 || n === 4)

    // Caso TI: n===2 ("presa in carico") e' *mia* se assegnata al TI loggato.
    // Fallback robusto: se manca lo username assegnato, prova anche con ti_assegnato_nome.
    if (role === 'TI' && n === 2) {
      const tiUser = String(d['ti_assegnato_username'] ?? d['ti_assegnato_user'] ?? d['ti_assegnato'] ?? '').trim()
      const tiName = String(d['ti_assegnato_nome'] ?? d['ti_assegnato_name'] ?? '').trim()

      const meUser = String(giiUser?.username || '').trim()
      const meName = String((giiUser as any)?.fullName ?? (giiUser as any)?.nome ?? (giiUser as any)?.displayName ?? '').trim()

      const eq = (a: string, b: string) => !!a && !!b && a.toLowerCase() === b.toLowerCase()
      const isMine = eq(tiUser, meUser) || eq(tiName, meUser) || (meName ? eq(tiName, meName) : false)

      if (tabId === 'attesa_mia') return isMine
      if (tabId === 'attesa_altri') return !isMine
    }

    if (role === 'RZ') {
      const tiInfo = getTiIstruttoriaInfo(d)
      if (tiInfo.isInTiIstruttoria) {
        if (tabId === 'attesa_mia') return false
        if (tabId === 'attesa_altri') return true
      }
    }

    if (tabId === 'attesa_mia') return isAttesaMiaDefault
    if (tabId === 'attesa_altri') return isAttesaAltriDefault
    return true
  }, [statoRuoloField, giiUser?.ruoloLabel, giiUser?.username])



  const equalsUser = React.useCallback((a: any, b: any): boolean => {
    const sa = String(a ?? '').trim().toLowerCase()
    const sb = String(b ?? '').trim().toLowerCase()
    return !!sa && !!sb && sa == sb
  }, [])

  const isRecordVisibleForCurrentUser = React.useCallback((r: DataRecord): boolean => {
    if (giiUser?.isAdmin) return true
    const role = String(giiUser?.ruoloLabel || '').toUpperCase()
    if (!role) return true

    const d: any = r.getData?.() || {}

    if (role === 'TI') {
      const meUser = String(giiUser?.username || '').trim()
      const meName = String((giiUser as any)?.fullName ?? (giiUser as any)?.nome ?? (giiUser as any)?.displayName ?? '').trim()
      const opRaw = d['origine_pratica']
      const opNum = opRaw !== null && opRaw !== undefined && opRaw !== '' ? Number(opRaw) : null

      const tiUser = String(d['ti_assegnato_username'] ?? d['ti_assegnato_user'] ?? d['ti_assegnato'] ?? '').trim()
      const tiName = String(d['ti_assegnato_nome'] ?? d['ti_assegnato_name'] ?? '').trim()
      const assignedToMe = equalsUser(tiUser, meUser) || equalsUser(tiName, meUser) || (meName ? equalsUser(tiName, meName) : false)

      const creatorVals = [
        d['created_user'], d['Creator'], d['creator'], d['username'], d['user_name'],
        d['utente'], d['utente_ins'], d['created_by'], d['submitter'], d['owner']
      ]
      const createdByMe = creatorVals.some(v => equalsUser(v, meUser) || (meName ? equalsUser(v, meName) : false))

      const hasTiWorkflow = hasRuoloData(d, 'TI')

      // Origine TR: i TI non devono vedere la pratica finché RZ non assegna.
      // E dopo l'assegnazione la vede solo il TI assegnatario.
      if (opNum === 1) {
        if (!tiUser && !tiName && !hasTiWorkflow) return false
        if (tiUser || tiName) return assignedToMe
        return false
      }

      // Origine TI: la vede il TI originatore; se poi viene esplicitamente assegnata,
      // prevale comunque l'assegnazione nominativa.
      if (opNum === 2) {
        if (tiUser || tiName) return assignedToMe
        if (createdByMe) return true
        return hasTiWorkflow
      }
    }

    return true
  }, [giiUser, equalsUser])

  const filterByRoleTab = React.useCallback((recs: DataRecord[]): DataRecord[] => {
    if (!statoRuoloField || activeRoleTab === 'tutte') return recs
    return recs.filter(r => passesRoleTab(r, activeRoleTab))
  }, [statoRuoloField, activeRoleTab, passesRoleTab])

// Ordinamento priorità ruolo: in attesa mia sempre in cima
  const sortByRolePriority = React.useCallback((recs: DataRecord[]): DataRecord[] => {
    if (!statoRuoloField) return recs
    return [...recs].sort((ra, rb) => {
      const da = ra.getData?.() || {}
      const db = rb.getData?.() || {}
      const pa = getPriorityForStato(da[statoRuoloField] != null ? Number(da[statoRuoloField]) : null)
      const pb = getPriorityForStato(db[statoRuoloField] != null ? Number(db[statoRuoloField]) : null)
      return pa - pb
    })
  }, [statoRuoloField])

  // ── Tab groups: data view con la stessa etichetta vengono fuse nello stesso tab ──
  const tabGroups = React.useMemo(() => {
    const filterTabsJs: any[] = asJs(cfg.filterTabs) || []
    const groups: { label: string; dsIndices: number[] }[] = []
    const labelMap = new Map<string, number>()

    filteredUseDsJs.forEach((u: any, i: number) => {
      const dsId = String(u?.dataSourceId || '')
      const entry = filterTabsJs.find((t: any) => String(t?.dataSourceId || '') === dsId)
      const label = String(entry?.label || getDsLabel(u, `Filtro ${i + 1}`))

      if (labelMap.has(label)) {
        groups[labelMap.get(label)!].dsIndices.push(i)
      } else {
        labelMap.set(label, groups.length)
        groups.push({ label, dsIndices: [i] })
      }
    })
    return groups
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filteredUseDsJs.length, cfg.filterTabs])

  const hasTabs = tabGroups.length > 1
  const [activeTab, setActiveTab] = React.useState<number>(0)
  const [localSelectedByDs, setLocalSelectedByDs] = React.useState<Record<string, string>>({})

  // ── Raccolta record da TUTTI i datasource ──
  const dsDataRef = React.useRef<Record<string, { recs: DataRecord[], ds: DataSource | null, loading: boolean }>>({})
const prevUserRef = React.useRef<string>('')
  const prevDsMetaSigRef = React.useRef<string>('')

// Se cambia l'utente (switch account / logout) pulisce cache record + selezione locale
React.useEffect(() => {
  const cur = giiUser?.username || ''
  const prev = prevUserRef.current
  if (cur === prev) return
  prevUserRef.current = cur
  dsDataRef.current = {}
  setLocalSelectedByDs({})
  notifySelectionCleared()
}, [giiUser?.username])

  const [dsDataVer, setDsDataVer] = React.useState(0)

  const handleDsUpdate = React.useCallback((dsId: string, recs: DataRecord[], ds: DataSource, loading: boolean) => {
    dsDataRef.current[dsId] = { recs, ds, loading }
    setDsDataVer(v => v + 1)
  }, [])

  // ── Ri-leggi i record dopo un breve ritardo per catturare dati lazy-loaded ──
  // Si riattiva quando cambia giiUser (post-login) o il numero di DS
  React.useEffect(() => {
    const timers = [300, 800, 2000, 4000]
    // Aggiorna signature datasource (label/url) per scegliere DS migliore ed evitare duplicati
    try {
      const sig0 = computeDsMetaSig(useDsJs)
      if (sig0 && sig0 !== prevDsMetaSigRef.current) {
        prevDsMetaSigRef.current = sig0
        setDsMetaSig(sig0)
      }
    } catch {}
    const ids = timers.map(ms => setTimeout(() => {
      let changed = false
      Object.entries(dsDataRef.current).forEach(([dsId, entry]) => {
        if (entry.ds) {
          const freshRecs = (entry.ds.getRecords?.() ?? []) as DataRecord[]
          if (freshRecs.length > 0) {
            dsDataRef.current[dsId] = { ...entry, recs: freshRecs, loading: false }
            changed = true
          }
        }
      })
      // Aggiorna anche la signature dei datasource (label/url) se cambia nel tempo
      try {
        const sig = computeDsMetaSig(useDsJs)
        if (sig && sig !== prevDsMetaSigRef.current) {
          prevDsMetaSigRef.current = sig
          setDsMetaSig(sig)
        }
      } catch {}

      if (changed) setDsDataVer(v => v + 1)
    }, ms))
    return () => ids.forEach(id => clearTimeout(id))
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [useDsJs.length, giiUser?.username])



  // Sort: array (multi sort con Shift+Click)
  const defaultSort: SortItem[] = React.useMemo(() => {
    const f = txt(cfg.orderByField || 'objectid')
    const d = (txt(cfg.orderByDir || 'DESC').toUpperCase() === 'ASC' ? 'ASC' : 'DESC') as SortDir
    return [{ field: f, dir: d }]
  }, [cfg.orderByField, cfg.orderByDir])

  const [sortState, setSortState] = React.useState<SortItem[]>(defaultSort)

  // Se cambia il sort default da settings, riallineo SOLO se l'utente non ha un custom sort
  React.useEffect(() => {
    const isCustom = sortSig(sortState) !== sortSig(defaultSort)
    if (!isCustom) setSortState(defaultSort)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sortSig(defaultSort)])

  // ── Record fusi per il tab attivo ──
  const clampedTab = Math.min(activeTab, Math.max(0, tabGroups.length - 1))
  const activeGroup = tabGroups[clampedTab] || tabGroups[0]

  const udsAny = (props.useDataSources as any) as any[] | undefined

  const whereClause = txt(cfg.whereClause || '1=1')
  const pageSize = num(cfg.pageSize, 200)

  // Query: usa "1=0" prima del login (nessun dato senza credenziali).
  // Quando notLogged/userLoading cambia a false, ExB ri-fetcha con la query reale.
  const isReady = !notLogged && !userLoading && !!giiUser?.username
  const dsQuery: any = React.useMemo(() => ({
    where: isReady ? whereClause : '1=0',
    pageSize
  }), [isReady, whereClause, pageSize])

  // Campi base
  const fieldPratica = txt(cfg.fieldPratica || 'objectid')
  const fieldDataRil = txt(cfg.fieldDataRilevazione || 'data_rilevazione')
  const fieldUfficio = txt(cfg.fieldUfficio || 'ufficio_zona')

  // Nota: i campi DT/DA sono ora acceduti direttamente tramite nome convenzionale
  // (es. `stato_DT`, `presa_in_carico_DA`, ...) dentro computeSintetico/computeUltimoAggMs.

  const presaDaPrendere = num(cfg.presaDaPrendereVal, 1)
  const presaPresa = num(cfg.presaPresaVal, 2)

  const statoDaPrendere = num(cfg.statoDaPrendereVal, 1)
  const statoPresa = num(cfg.statoPresaVal, 2)
  const statoIntegrazione = num(cfg.statoIntegrazioneVal, 3)
  const statoApprovata = num(cfg.statoApprovataVal, 4)
  const statoRespinta = num(cfg.statoRespintaVal, 5)

  const esitoIntegrazione = num(cfg.esitoIntegrazioneVal, 1)
  const esitoApprovata = num(cfg.esitoApprovataVal, 2)
  const esitoRespinta = num(cfg.esitoRespintaVal, 3)

  const labelStato = (v: any): string => {
    const n = Number(v)
    if (!Number.isFinite(n)) return txt(v)
    if (n === statoDaPrendere) return txt(cfg.labelStatoDaPrendere || 'Da prendere')
    if (n === statoPresa) return txt(cfg.labelStatoPresa || 'Presa in carico')
    if (n === statoIntegrazione) return txt(cfg.labelStatoIntegrazione || 'Integrazione richiesta')
    if (n === statoApprovata) return txt(cfg.labelStatoApprovata || 'Approvata')
    if (n === statoRespinta) return txt(cfg.labelStatoRespinta || 'Respinta')
    return String(n)
  }

  const labelEsito = (v: any): string => {
    const n = Number(v)
    if (!Number.isFinite(n)) return txt(v)
    if (n === esitoIntegrazione) return txt(cfg.labelEsitoIntegrazione || 'Integrazione richiesta')
    if (n === esitoApprovata) return txt(cfg.labelEsitoApprovata || 'Approvata')
    if (n === esitoRespinta) return txt(cfg.labelEsitoRespinta || 'Respinta')
    return String(n)
  }

  // ── Chip colors — 5 stati workflow ────────────────────────────────────────
  // statoForChip: 1=DaPrendere, 2=InLavorazione, 3=Integrazione, 4=Approvata, 5=Respinta, null=neutro
  const getChipStyle = (statoNum: number | null) => {
    if (statoNum === statoDaPrendere) {
      // arancio – in attesa di qualcuno
      return {
        background: txt(cfg.statoBgDaPrendere || '#fff7e6'),
        color: txt(cfg.statoTextDaPrendere || '#7a4b00'),
        borderColor: txt(cfg.statoBorderDaPrendere || '#ffd18a')
      }
    }
    if (statoNum === statoPresa) {
      // verde chiaro – in lavorazione
      return {
        background: txt(cfg.statoBgPresa || '#eaf7ef'),
        color: txt(cfg.statoTextPresa || '#1f6b3a'),
        borderColor: txt(cfg.statoBorderPresa || '#9ad2ae')
      }
    }
    if (statoNum === statoIntegrazione) {
      // ambra – integrazione richiesta
      return {
        background: txt(cfg.statoBgIntegrazione || '#fffbeb'),
        color: txt(cfg.statoTextIntegrazione || '#92400e'),
        borderColor: txt(cfg.statoBorderIntegrazione || '#fbbf24')
      }
    }
    if (statoNum === statoApprovata) {
      // verde scuro – approvata/chiusa positivamente
      return {
        background: txt(cfg.statoBgApprovata || '#dcfce7'),
        color: txt(cfg.statoTextApprovata || '#14532d'),
        borderColor: txt(cfg.statoBorderApprovata || '#4ade80')
      }
    }
    if (statoNum === statoRespinta) {
      // rosso – respinta
      return {
        background: txt(cfg.statoBgRespinta || '#fee2e2'),
        color: txt(cfg.statoTextRespinta || '#7f1d1d'),
        borderColor: txt(cfg.statoBorderRespinta || '#f87171')
      }
    }
    // neutro – stato sconosciuto / nuova pratica
    return {
      background: txt(cfg.statoBgAltro || '#f2f2f2'),
      color: txt(cfg.statoTextAltro || '#333333'),
      borderColor: txt(cfg.statoBorderAltro || '#d0d0d0')
    }
  }

  // converte esito (1..3) in "stato visuale" per chip (3/4/5)
  const statoNumFromEsito = (esito: number): number => {
    if (esito === esitoIntegrazione) return statoIntegrazione
    if (esito === esitoApprovata) return statoApprovata
    if (esito === esitoRespinta) return statoRespinta
    return statoApprovata
  }

  // Verifica se un ruolo ha dati valorizzati (presa/stato/esito con campo generico)
  const hasRuoloData = (d: any, role: string): boolean => {
    const p = d[`presa_in_carico_${role}`]
    const s = d[`stato_${role}`]
    const e = d[`esito_${role}`]
    return (p !== null && p !== undefined && p !== '')
      || (s !== null && s !== undefined && s !== '')
      || (e !== null && e !== undefined && e !== '')
  }

  const getTiIstruttoriaInfo = (d: any) => {
    const tiUser = String(d['ti_assegnato_username'] ?? d['ti_assegnato_user'] ?? d['ti_assegnato'] ?? '').trim()
    const higherTouched = hasRuoloData(d, 'RI') || hasRuoloData(d, 'DT') || hasRuoloData(d, 'DA')

    const statoTiRaw = d['stato_TI'] ?? d['stato_ti']
    const presaTiRaw = d['presa_in_carico_TI'] ?? d['presa_in_carico_ti']
    const esitoTiRaw = d['esito_TI'] ?? d['esito_ti']

    const statoTiNum = statoTiRaw !== null && statoTiRaw !== undefined && statoTiRaw !== '' ? Number(statoTiRaw) : null
    const presaTiNum = presaTiRaw !== null && presaTiRaw !== undefined && presaTiRaw !== '' ? Number(presaTiRaw) : null
    const esitoTiNum = esitoTiRaw !== null && esitoTiRaw !== undefined && esitoTiRaw !== '' ? Number(esitoTiRaw) : null

    const tiReturned =
      (esitoTiNum !== null && Number.isFinite(esitoTiNum)) ||
      (statoTiNum === statoApprovata) ||
      (statoTiNum === statoRespinta)

    return {
      hasAssignedTi: !!tiUser,
      tiUser,
      higherTouched,
      statoTiNum,
      presaTiNum,
      esitoTiNum,
      tiReturned,
      isInTiIstruttoria: !!tiUser && !higherTouched && !tiReturned
    }
  }

  // ── computeSintetico: workflow-aware su tutti i ruoli ──────────────────────
  //
  // Logica:
  //   - Scansiona i ruoli dal più avanzato (DA) al meno avanzato (TR)
  //   - Il primo ruolo con dati valorizzati è il "nodo corrente"
  //   - presa=1 (DA PRENDERE) → la pratica è stata trasmessa ma non ancora presa in carico
  //     → "Trasmessa a [ruolo]"  chip arancio
  //   - presa=2 (PRESA) o stato=presa → il ruolo ci sta lavorando
  //     → "In lavorazione [ruolo]"  chip verde
  //   - stato/esito espliciti → mostrano l'azione già compiuta
  //
  // Pratiche senza nessun campo workflow:
  //   origine=1 (TR) → implicitamente trasmessa a RZ → "Trasmessa a RZ"  chip arancio
  //   origine=2 (TI) → TI l'ha creata, non ancora trasmessa → "In lavorazione TI"  chip verde

  const computeSintetico = (d: any): { ruolo: string, label: string, statoForChip: number | null } => {
    const scanOrder = ['DA', 'DT', 'RI', 'RZ', 'TI', 'TR']

    // Caso speciale: assegnazione RZ -> TI.
    // Finche' TI non "restituisce" la pratica, lo stato sintetico segue
    // le voci del file xlsx sul tratto RZ -> TI.
    const tiInfo = getTiIstruttoriaInfo(d)
    if (tiInfo.hasAssignedTi && tiInfo.isInTiIstruttoria) {
      if (tiInfo.statoTiNum !== null && Number.isFinite(tiInfo.statoTiNum)) {
        if (tiInfo.statoTiNum === statoDaPrendere) {
          return { ruolo: 'TI', label: 'Da prendere in carico TI', statoForChip: statoDaPrendere }
        }
        if (tiInfo.statoTiNum === statoPresa) {
          return { ruolo: 'TI', label: 'Presa in carico TI', statoForChip: statoPresa }
        }
        return { ruolo: 'TI', label: 'In carico TI', statoForChip: null }
      }
      if (tiInfo.presaTiNum !== null && Number.isFinite(tiInfo.presaTiNum)) {
        if (tiInfo.presaTiNum === presaDaPrendere) {
          return { ruolo: 'TI', label: 'Da prendere in carico TI', statoForChip: statoDaPrendere }
        }
        if (tiInfo.presaTiNum === presaPresa) {
          return { ruolo: 'TI', label: 'Presa in carico TI', statoForChip: statoPresa }
        }
      }
      return { ruolo: 'TI', label: 'Trasmessa a TI', statoForChip: statoDaPrendere }
    }

    for (const role of scanOrder) {
      if (!hasRuoloData(d, role)) continue

      const presaRaw = d[`presa_in_carico_${role}`]
      const statoRaw = d[`stato_${role}`]
      const esitoRaw = d[`esito_${role}`]

      const presaNum = presaRaw !== null && presaRaw !== undefined && presaRaw !== '' ? Number(presaRaw) : null
      const statoNum = statoRaw !== null && statoRaw !== undefined && statoRaw !== '' ? Number(statoRaw) : null
      const esitoNum = esitoRaw !== null && esitoRaw !== undefined && esitoRaw !== '' ? Number(esitoRaw) : null

      // Esito > stato > presa (in ordine di precedenza)

      if (esitoNum !== null && Number.isFinite(esitoNum)) {
        return { ruolo: role, label: `${labelEsito(esitoNum)} (${role})`, statoForChip: statoNumFromEsito(esitoNum) }
      }

      if (statoNum !== null && Number.isFinite(statoNum)) {
        // stato=1 (da prendere) → trasmessa, in attesa che qualcuno agisca
        if (statoNum === statoDaPrendere) {
          return { ruolo: role, label: `Trasmessa a ${role}`, statoForChip: statoDaPrendere }
        }
        // stato=2 (presa in carico) → in lavorazione presso quel ruolo
        if (statoNum === statoPresa) {
          return { ruolo: role, label: `Presa in carico ${role}`, statoForChip: statoPresa }
        }
        // altri stati espliciti (integrazione, approvata, respinta)
        return { ruolo: role, label: `${labelStato(statoNum)} (${role})`, statoForChip: statoNum }
      }

      if (presaNum !== null && Number.isFinite(presaNum)) {
        if (presaNum === presaDaPrendere) {
          // presa=1: trasmessa al ruolo, non ancora presa in carico
          return { ruolo: role, label: `Trasmessa a ${role}`, statoForChip: statoDaPrendere }
        }
        if (presaNum === presaPresa) {
          // presa=2: presa in carico, in lavorazione
          return { ruolo: role, label: `Presa in carico ${role}`, statoForChip: statoPresa }
        }
      }

      // Ha dati ma valore non riconosciuto
      return { ruolo: role, label: `In carico ${role}`, statoForChip: null }
    }

    // Nessun campo workflow → pratica appena creata
    const op = d['origine_pratica']
    const opNum = op !== null && op !== undefined && op !== '' ? Number(op) : null
    if (opNum === 2) {
      // TI ha creato la pratica, la sta ancora lavorando prima di trasmetterla a RZ
      return { ruolo: 'TI', label: 'Da trasmettere a RZ', statoForChip: statoPresa }
    }
    // origine=1 (TR) o non valorizzato: implicitamente trasmessa a RZ
    return { ruolo: 'RZ', label: 'Da prendere in carico RZ', statoForChip: statoDaPrendere }
  }

  // ── computeUltimoAggMs: considera timestamp di TUTTI i ruoli ──────────────
  const computeUltimoAggMs = (d: any): number | null => {
    const roles = ['TR', 'TI', 'RZ', 'RI', 'DT', 'DA']
    const candidates: number[] = []
    for (const role of roles) {
      const p = parseToMs(d[`dt_presa_in_carico_${role}`])
      const s = parseToMs(d[`dt_stato_${role}`])
      const e = parseToMs(d[`dt_esito_${role}`])
      if (p !== null) candidates.push(p)
      if (s !== null) candidates.push(s)
      if (e !== null) candidates.push(e)
    }
    if (candidates.length === 0) return null
    return Math.max(...candidates)
  }

  // ── computeProssima: azione attesa sul nodo corrente ──────────────────────
  //
  // Riceve il ruolo corrente da computeSintetico e restituisce la prossima azione attesa.
  // La logica è simmetrica a computeSintetico: stesso nodo, stessi campi.
  const computeProssima = (d: any, ruolo: string): string => {
    if (!ruolo) {
      // Fallback irraggiungibile — computeSintetico ritorna sempre un ruolo valorizzato
      const op = d['origine_pratica']
      const opNum = op !== null && op !== undefined && op !== '' ? Number(op) : null
      return opNum === 2 ? 'Trasmettere a RZ (TI)' : 'Prendere in carico (RZ)'
    }

    const presaRaw = d[`presa_in_carico_${ruolo}`]
    const statoRaw = d[`stato_${ruolo}`]
    const esitoRaw = d[`esito_${ruolo}`]

    const presaNum = presaRaw !== null && presaRaw !== undefined && presaRaw !== '' ? Number(presaRaw) : null
    const statoNum = statoRaw !== null && statoRaw !== undefined && statoRaw !== '' ? Number(statoRaw) : null
    const esitoNum = esitoRaw !== null && esitoRaw !== undefined && esitoRaw !== '' ? Number(esitoRaw) : null

    // Esito già espresso
    if (esitoNum !== null) {
      if (esitoNum === esitoApprovata) {
        // DT approva e trasmette a DA; DA approva = chiusa
        if (ruolo === 'DT') return 'Trasmettere a DA (DT)'
        return `Chiusa – approvata (${ruolo})`
      }
      if (esitoNum === esitoRespinta)    return `Chiusa – respinta (${ruolo})`
      if (esitoNum === esitoIntegrazione) return `Attendere integrazione (${ruolo})`
    }

    // Stato esplicito
    if (statoNum !== null) {
      if (statoNum === statoDaPrendere)  return `Prendere in carico (${ruolo})`
      if (statoNum === statoPresa) {
        // In lavorazione → azione dipende dal ruolo
        if (ruolo === 'RZ') return 'Trasmettere a RI (RZ)'
        if (ruolo === 'TI') return 'Trasmettere a RZ (TI)'
        if (ruolo === 'RI') return 'Trasmettere a DT (RI)'
        if (ruolo === 'DT') return 'Esprimere esito (DT)'
        if (ruolo === 'DA') return 'Esprimere esito finale (DA)'
        return `Esprimere esito (${ruolo})`
      }
      if (statoNum === statoIntegrazione) return `Gestire integrazione (${ruolo})`
      if (statoNum === statoApprovata) {
        if (ruolo === 'DT') return 'Trasmettere a DA (DT)'
        return `Chiusa – approvata (${ruolo})`
      }
      if (statoNum === statoRespinta)    return `Chiusa – respinta (${ruolo})`
    }

    // Solo presa in carico
    if (presaNum !== null) {
      if (presaNum === presaDaPrendere)  return `Prendere in carico (${ruolo})`
      if (presaNum === presaPresa) {
        if (ruolo === 'RZ') return 'Trasmettere a RI (RZ)'
        if (ruolo === 'TI') return 'Trasmettere a RZ (TI)'
        if (ruolo === 'RI') return 'Trasmettere a DT (RI)'
        if (ruolo === 'DT') return 'Esprimere esito (DT)'
        if (ruolo === 'DA') return 'Esprimere esito finale (DA)'
        return `Esprimere esito (${ruolo})`
      }
    }

    // Nessun campo → pratica appena creata, nessun workflow ancora avviato
    if (ruolo === 'RZ') return 'Prendere in carico (RZ)'
    if (ruolo === 'TI') return 'Trasmettere a RZ (TI)'

    return `Verificare stato (${ruolo})`
  }
  const getSortValue = (r: DataRecord, field: string): any => {
    const d = r.getData?.() || {}
    if (field === V_STATO) return computeSintetico(d).label
    if (field === V_ULTIMO) return computeUltimoAggMs(d)
    if (field === V_PROSSIMA) {
      const s = computeSintetico(d)
      return computeProssima(d, s.ruolo)
    }
    return d[field]
  }

  const sortRecords = (recs: DataRecord[], sort: SortItem[]): DataRecord[] => {
    if (!sort || sort.length === 0) return recs
    const copy = [...recs]
    copy.sort((ra, rb) => {
      for (const s of sort) {
        const a = getSortValue(ra, s.field)
        const b = getSortValue(rb, s.field)
        const cmp = compareValues(a, b)
        if (cmp !== 0) return (s.dir === 'ASC' ? cmp : -cmp)
      }
      return 0
    })
    return copy
  }

  const toggleSort = (field: string, multi: boolean) => {
    setSortState(prev => {
      const p = [...prev]
      const idx = p.findIndex(x => x.field === field)
      if (idx >= 0) {
        const cur = p[idx]
        const nextDir: SortDir = cur.dir === 'ASC' ? 'DESC' : 'ASC'
        p[idx] = { field, dir: nextDir }
        return multi ? p : [p[idx]]
      }
      const next: SortItem = { field, dir: 'ASC' }
      return multi ? [...p, next] : [next]
    })
  }

  const isCustomSort = sortSig(sortState) !== sortSig(defaultSort)

  // ── Record fusi e ordinati per il tab attivo ──
  const mergedRecs = React.useMemo(() => {
    if (!activeGroup) return [] as DataRecord[]
    const svcCache = new Map<string, string>()
    const uniq = new Map<string, DataRecord>()
    for (const di of activeGroup.dsIndices) {
      const dsId = String(filteredUseDsJs[di]?.dataSourceId || '')
      const entry = dsDataRef.current[dsId]
      if (entry?.recs) {
        for (const r of entry.recs) {
          const k = getRecordUniqKey(r, dsId, svcCache)
          if (!uniq.has(k)) uniq.set(k, r)
        }
      }
    }
    const allUniq: DataRecord[] = Array.from(uniq.values())
    const visibleForUser = allUniq.filter(r => isRecordVisibleForCurrentUser(r))
    // Applica filtro tab ruolo
    const filtered = filterByRoleTab(visibleForUser)
    // Ordinamento: prima priorità ruolo (in attesa mia in cima), poi sort utente
    const withPriority = sortByRolePriority(filtered)
    return sortRecords(withPriority, sortState)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeGroup, dsDataVer, sortState, activeRoleTab, statoRuoloField, isRecordVisibleForCurrentUser])

  // Lookup: record → dsId (via WeakMap su identità oggetto, sopravvive al sort)
  const recDsLookup = React.useMemo(() => {
    const map = new WeakMap<DataRecord, string>()
    if (!activeGroup) return map
    for (const di of activeGroup.dsIndices) {
      const dsId = String(filteredUseDsJs[di]?.dataSourceId || '')
      const entry = dsDataRef.current[dsId]
      if (entry?.recs) {
        for (const r of entry.recs) map.set(r, dsId)
      }
    }
    return map
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeGroup, dsDataVer])

  // Loading: true solo se TUTTI i DS del tab attivo stanno ancora caricando
  // (non se solo uno manca dall'entry — potrebbe essere che non ha ancora risposto)
  const anyLoading = activeGroup?.dsIndices.every(di => {
    const dsId = String(filteredUseDsJs[di]?.dataSourceId || '')
    const entry = dsDataRef.current[dsId]
    if (!entry) return true // mai aggiornato → stiamo aspettando
    return entry.loading
  }) ?? false

  // layout
  const gap = num(cfg.gap, 12)
  const padFirst = num(cfg.paddingLeftFirstCol, 0)

  // ── Colonne dinamiche da config ──
  const columns = migrateColumns(asJs(cfg))

  const gridCols = columns.map(c => `${c.width}px`).join(' ')
  const minWidth = columns.reduce((sum, c) => sum + c.width, 0) + (gap * Math.max(0, columns.length - 1)) + 24

  const rowGap = num(cfg.rowGap, 8)
  const rowPaddingX = num(cfg.rowPaddingX, 12)
  const rowPaddingY = num(cfg.rowPaddingY, 10)
  const rowMinHeight = num(cfg.rowMinHeight, 44)
  const rowRadius = num(cfg.rowRadius, 12)
  const rowBorderWidth = num(cfg.rowBorderWidth, 1)
  const rowBorderColor = txt(cfg.rowBorderColor || 'rgba(0,0,0,0.08)')

  const chipRadius = num(cfg.statoChipRadius, 999)
  const chipPadX = num(cfg.statoChipPadX, 10)
  const chipPadY = num(cfg.statoChipPadY, 4)
  const chipBorderW = num(cfg.statoChipBorderW, 1)
  const chipFontWeight = num(cfg.statoChipFontWeight, 600)
  const chipFontSize = num(cfg.statoChipFontSize, 12)
  const chipFontStyle = (cfg.statoChipFontStyle === 'italic' ? 'italic' : 'normal') as any
  const chipTextTransform = (['none', 'uppercase', 'lowercase', 'capitalize'].includes(cfg.statoChipTextTransform) ? cfg.statoChipTextTransform : 'none') as any
  const chipLetterSpacing = num(cfg.statoChipLetterSpacing, 0)

  const styles = css`
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;

    .tabBar {
      display: ${hasTabs ? 'flex' : 'none'};
      gap: 8px;
      padding: 8px 12px;
      border-bottom: 1px solid rgba(0,0,0,0.08);
      background: var(--bs-body-bg, #fff);
    }
    .tabBtn {
      border: 1px solid rgba(0,0,0,0.12);
      background: rgba(0,0,0,0.02);
      color: #111827;
      padding: 8px 10px;
      border-radius: 10px;
      cursor: pointer;
      font-weight: 700;
      font-size: 12px;
      white-space: nowrap;
    }
    .tabBtn.active {
      background: #eaf2ff;
      border-color: #2f6fed;
      color: #1d4ed8;
    }

    .viewport { flex: 1; min-height: 0; overflow: auto; }
    .content { min-width: ${minWidth}px; padding: 0 12px 10px; }

    .headerWrap {
      position: sticky;
      top: 0;
      z-index: 2;
      background: var(--bs-body-bg, #fff);
      border-bottom: 1px solid rgba(0,0,0,0.08);
      padding: 6px 12px;
      margin: 0 0 8px 0;
    }

    .gridHeader {
      display: grid;
      grid-template-columns: ${gridCols};
      column-gap: ${gap}px;
      align-items: center;
      min-height: 28px;
    }

    .headerCell {
      display: flex;
      align-items: center;
      min-width: 0;
      font-weight: 700;
      font-size: 12px;
      color: rgba(0,0,0,0.65);
    }

    .hdrBtn {
      width: 100%;
      border: none;
      background: transparent;
      padding: 0;
      margin: 0;
      text-align: left;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: inherit;
      font: inherit;
      line-height: 1;
    }
    .hdrBtn:hover { color: rgba(0,0,0,0.9); }

    .sortBadge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 12px;
      opacity: 0.85;
    }
    .sortPri {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 16px;
      height: 16px;
      border-radius: 4px;
      background: rgba(0,0,0,0.07);
      font-weight: 800;
    }

    .resetBtn {
      padding: 0 10px !important;
      height: 28px !important;
      min-height: 28px !important;
      line-height: 1 !important;
      white-space: nowrap !important;
      font-size: 12px !important;
      font-weight: 700 !important;
    }

    .first { padding-left: ${padFirst}px; }

    .list { display: flex; flex-direction: column; }

    .rowCard {
      display: grid;
      grid-template-columns: ${gridCols};
      column-gap: ${gap}px;
      align-items: center;

      padding: ${rowPaddingY}px ${rowPaddingX}px;
      min-height: ${rowMinHeight}px;

      border-radius: ${rowRadius}px;
      border: ${rowBorderWidth}px solid ${rowBorderColor};

      margin-bottom: ${rowGap}px;
      cursor: pointer;
    }
    .rowCard.even { background: ${txt(cfg.zebraEvenBg || '#ffffff')}; }
    .rowCard.odd  { background: ${txt(cfg.zebraOddBg || '#fbfbfb')}; }
    .rowCard:hover { background: ${txt(cfg.hoverBg || '#f2f6ff')}; }

    .rowCard.selected {
      border-color: ${txt(cfg.selectedBorderColor || '#2f6fed')};
      box-shadow: 0 0 0 ${num(cfg.selectedBorderWidth, 2)}px rgba(47,111,237,0.18);
      background: ${txt(cfg.selectedBg || '#eaf2ff')};
    }

    .cell {
      min-width: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .chip {
      display: inline-flex;
      align-items: center;
      padding: ${chipPadY}px ${chipPadX}px;
      border-radius: ${chipRadius}px;
      border: ${chipBorderW}px solid rgba(0,0,0,0.12);
      font-weight: ${chipFontWeight};
      font-size: ${chipFontSize}px;
      font-style: ${chipFontStyle};
      text-transform: ${chipTextTransform};
      letter-spacing: ${chipLetterSpacing}px;
      line-height: 1;
      white-space: nowrap;
      max-width: 100%;
    }

    .empty { padding: 14px; color: rgba(0,0,0,0.65); }
  `

  const Header = (p: { label: string, field: string, first?: boolean }) => {
    const idx = sortState.findIndex(x => x.field === p.field)
    const item = idx >= 0 ? sortState[idx] : null
    const dir = item?.dir

    const badge = item
      ? (
        <span className='sortBadge' aria-hidden>
          <span className='sortPri'>{idx + 1}</span>
          <span>{dir === 'ASC' ? '↑' : '↓'}</span>
        </span>
        )
      : <span className='sortBadge' style={{ opacity: 0.35 }} aria-hidden>↕</span>

    return (
      <div className={`headerCell ${p.first ? 'first' : ''}`}>
        <button
          type='button'
          className='hdrBtn'
          onClick={(e) => toggleSort(p.field, (e as any).shiftKey === true)}
          title='Click: ordina. Shift+Click: ordinamento multiplo.'
        >
          <span>{p.label}</span>
          {badge}
        </button>
      </div>
    )
  }

  const maskOuterOffset = Number.isFinite(Number(cfg.maskOuterOffset)) ? Number(cfg.maskOuterOffset) : 12
  const maskInnerPadding = Number.isFinite(Number(cfg.maskInnerPadding)) ? Number(cfg.maskInnerPadding) : 8
  const maskBg = String(cfg.maskBg ?? '#ffffff')
  const maskBorderColor = String(cfg.maskBorderColor ?? 'rgba(0,0,0,0.12)')
  const maskBorderWidth = Number.isFinite(Number(cfg.maskBorderWidth)) ? Number(cfg.maskBorderWidth) : 1
  const maskRadius = Number.isFinite(Number(cfg.maskRadius)) ? Number(cfg.maskRadius) : 12

  if (!useDsJs.length) {
    return <div style={{ padding: 12 }}>{txt(cfg.errorNoDs || 'Configura la fonte dati del widget.')}</div>
  }

  // Titolo elenco
  const listTitleText = txt(cfg.listTitleText || 'Elenco rapporti di rilevazione')
  const listTitleHeight = num(cfg.listTitleHeight, 28)
  const listTitlePaddingBottom = num(cfg.listTitlePaddingBottom, 10)
  const listTitlePaddingLeft = num(cfg.listTitlePaddingLeft, 0)
  const listTitleFontSize = num(cfg.listTitleFontSize, 14)
  const listTitleFontWeight = num(cfg.listTitleFontWeight, 600)
  const listTitleColor = txt(cfg.listTitleColor || 'rgba(0,0,0,0.85)')

  return (
    <div style={{ width: '100%', height: '100%', boxSizing: 'border-box', padding: maskOuterOffset, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      {/* Titolo elenco - sopra l'area bianca */}
      {listTitleText && (
        <div style={{
          height: listTitleHeight,
          paddingBottom: listTitlePaddingBottom,
          paddingLeft: listTitlePaddingLeft,
          display: 'flex',
          alignItems: 'center',
          boxSizing: 'border-box',
          flex: '0 0 auto'
        }}>
          <span style={{
            fontSize: listTitleFontSize,
            fontWeight: listTitleFontWeight,
            color: listTitleColor
          }}>
            {listTitleText}
          </span>
        </div>
      )}
      <div
        style={{
          width: '100%',
          flex: '1 1 auto',
          minHeight: 0,
          boxSizing: 'border-box',
          border: `${maskBorderWidth}px solid ${maskBorderColor}`,
          borderRadius: maskRadius,
          background: maskBg,
          padding: maskInnerPadding,
          overflow: 'hidden'
        }}
      >
        <div css={styles} style={{ width: '100%', height: '100%' }}>

          {/* ── Overlay bloccante: copre i dati finche' non c'e' login ── */}
          {(notLogged || userLoading) && (
            <div style={{
              position: 'absolute', inset: 0, zIndex: 100,
              background: 'rgba(255,255,255,0.97)',
              display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              gap: 16, padding: 32, textAlign: 'center',
              borderRadius: maskRadius,
              pointerEvents: 'all'
            }}>
              {userLoading
                ? (
                  <>
                    <Loading />
                    <div style={{ fontSize: 13, color: '#6b7280' }}>Verifica accesso in corso…</div>
                  </>
                )
                : (
                  <>
                    <div style={{ fontSize: 32 }}>🔒</div>
                    <div style={{ fontSize: 15, fontWeight: 700, color: '#111827' }}>
                      Accesso richiesto
                    </div>
                    <div style={{ fontSize: 13, color: '#6b7280', maxWidth: 300, lineHeight: 1.5 }}>
                      Utilizza il pulsante di accesso in alto a destra per entrare con le credenziali CBSM.
                    </div>
                  </>
                )
              }
            </div>
          )}

          {/* ── DataSource loaders: SEMPRE nel DOM (ExB richiede che siano registrati).
               Query "1=0" prima del login → nessun dato anonimo.
               Query reale dopo login → ExB ri-fetcha con credenziali. ── */}
          {useDsJs.map((u: any, i: number) => (
            <DataSourceComponent
              key={`${u?.dataSourceId || i}-${giiUser?.username || 'anon'}`}
              useDataSource={udsAny?.[i]}
              query={dsQuery}
              widgetId={props.id}
            >
              {(ds: DataSource, info: any) => (
                <RecordTracker ds={ds} dsId={String(u?.dataSourceId || '')} info={info} onUpdate={handleDsUpdate} />
              )}
            </DataSourceComponent>
          ))}

          {/* ── Tab ruolo: Tutte / In attesa mia / In attesa di altri ── */}
          {!userLoading && statoRuoloField && (
            <div style={{ display: 'flex', gap: 8, padding: '8px 12px', borderBottom: '1px solid rgba(0,0,0,0.08)', alignItems: 'center', flexWrap: 'wrap' }}>
              <span style={{ fontSize: 11, color: '#6b7280', marginRight: 4 }}>
                {`👤 ${(giiUser?.ruoloLabel ?? '')}`}
              </span>
              {ROLE_TABS.map(t => (
                <button
                  key={t.id}
                  type='button'
                  className={`tabBtn ${activeRoleTab === t.id ? 'active' : ''}`}
                  onClick={() => setActiveRoleTab(t.id)}
                >
                  {t.label}
                  {/* Conteggio record per tab */}
                  {(() => {
                    if (!activeGroup) return null
                    const svcCache = new Map<string, string>()
                    const uniq = new Map<string, DataRecord>()
                    for (const di of activeGroup.dsIndices) {
                      const dsId = String(filteredUseDsJs[di]?.dataSourceId || '')
                      const entry = dsDataRef.current[dsId]
                      if (entry?.recs) {
                        for (const r of entry.recs) {
                          const k = getRecordUniqKey(r, dsId, svcCache)
                          if (!uniq.has(k)) uniq.set(k, r)
                        }
                      }
                    }
                    const all: DataRecord[] = Array.from(uniq.values())
                    const count = t.id === 'tutte'
                      ? all.length
                      : all.filter(r => passesRoleTab(r, t.id)).length
                    return count > 0 ? (
                      <span style={{
                        marginLeft: 6, background: activeRoleTab === t.id ? '#2f6fed' : 'rgba(0,0,0,0.1)',
                        color: activeRoleTab === t.id ? '#fff' : '#374151',
                        borderRadius: 999, padding: '1px 7px', fontSize: 11, fontWeight: 700
                      }}>{count}</span>
                    ) : null
                  })()}
                </button>
              ))}
            </div>
          )}

          {/* Indicatore admin: vede tutto senza filtri */}
          {!userLoading && giiUser?.isAdmin && (
            <div style={{ padding: '6px 12px', fontSize: 11, color: '#6b7280', borderBottom: '1px solid rgba(0,0,0,0.06)', background: '#fafafa' }}>
              👤 AMM — visualizzazione completa senza filtri ruolo
            </div>
          )}

          {/* Indicatore caricamento ruolo (visibile solo quando loggato ma ancora caricando) */}
          {userLoading && !notLogged && (
            <div style={{ padding: '6px 12px', fontSize: 11, color: '#6b7280' }}>
              Rilevamento ruolo utente…
            </div>
          )}

          {/* ── Tab bar datasource (raggruppati per etichetta) — solo se ci sono tab multiple E non ci sono tab ruolo ── */}
          {hasTabs && !statoRuoloField && (
            <div className='tabBar'>
              {tabGroups.map((g, i) => (
                <button
                  key={g.label}
                  type='button'
                  className={`tabBtn ${i === activeTab ? 'active' : ''}`}
                  onClick={() => {
                    // Clear selezioni per i DS del tab corrente
                    const curGroup = tabGroups[activeTab]
                    if (curGroup) {
                      curGroup.dsIndices.forEach(di => {
                        const dsId = String(filteredUseDsJs[di]?.dataSourceId || '')
                        const entry = dsDataRef.current[dsId]
                        if (entry?.ds) tryClearSelection(entry.ds)
                      })
                      notifySelectionCleared()
                      setLocalSelectedByDs(prev => {
                        const updated = { ...prev }
                        curGroup.dsIndices.forEach(di => {
                          delete updated[String(filteredUseDsJs[di]?.dataSourceId || '')]
                        })
                        return updated
                      })
                    }
                    setActiveTab(i)
                  }}
                  title={g.label}
                >
                  {g.label}
                </button>
              ))}
            </div>
          )}

          {/* ── Contenuto: record fusi da tutti i DS del tab attivo ── */}
          <div className='viewport'>
            <div className='content'>
              {anyLoading && <Loading />}

              {!anyLoading && mergedRecs.length === 0 && (
                <div className='empty'>{txt(cfg.emptyMessage || 'Nessun record trovato.')}</div>
              )}

              {mergedRecs.length > 0 && (
                <>
                  {cfg.showHeader !== false && (
                    <div className='headerWrap'>
                      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 6 }}>
                        {isCustomSort && (
                          <Button
                            size='sm'
                            type='tertiary'
                            className='resetBtn'
                            onClick={() => setSortState(defaultSort)}
                            title='Ripristina ordinamento di default'
                            aria-label='Reset ordinamento'
                          >
                            Reset
                          </Button>
                        )}
                      </div>

                      <div className='gridHeader'>
                        {columns.map((col, ci) => (
                          <Header key={col.id} first={ci === 0} label={col.label} field={col.field} />
                        ))}
                      </div>
                    </div>
                  )}

                  <div className='list'>
                    {mergedRecs.map((r, idx) => {
                      const d = r.getData?.() || {}
                      const oid = Number(d.OBJECTID)
                      const rid = String(r.getId?.() ?? oid)
                      const recDsId = recDsLookup.get(r) || ''

                      const fp = String(fieldPratica || '').toLowerCase()
                      const pratica = (fp === 'objectid' || fp === 'oid' || fp === 'object_id')
                        ? getCodPraticaDisplay(r)
                        : txt(d[fieldPratica])
                      const dataRil = formatDateIt(d[fieldDataRil])
                      const ufficio = txt(d[fieldUfficio])

                      const sintetico = computeSintetico(d)
                      const statoLabel = txt(sintetico.label)
                      const statoChipNum = sintetico.statoForChip

                      const ultimoMs = computeUltimoAggMs(d)
                      const ultimo = ultimoMs ? formatDateIt(ultimoMs) : '—'

                      const prossima = computeProssima(d, sintetico.ruolo)

                      const isSel = (localSelectedByDs[recDsId] === rid)
                      const even = idx % 2 === 0

                      return (
                        <div
                          key={`${recDsId}_${rid}`}
                          className={`rowCard ${even ? 'even' : 'odd'} ${isSel ? 'selected' : ''}`}
                          onClick={() => {
                            if (isSel) {
                              // Deseleziona su TUTTI i DS
                              setLocalSelectedByDs({})
                              Object.keys(dsDataRef.current).forEach(id => {
                                const e = dsDataRef.current[id]
                                if (e?.ds) tryClearSelection(e.ds)
                              })
                              // Deseleziona anche su tutti i DS parent via DataSourceManager
                              filteredUseDsJs.forEach((u: any) => {
                                const dsId = String(u?.dataSourceId || '')
                                try {
                                  const mainDs = DataSourceManager.getInstance().getDataSource(dsId)
                                  if (mainDs) tryClearSelection(mainDs)
                                  const parentId = (mainDs as any)?.parentDataSource?.id || (mainDs as any)?.getMainDataSource?.()?.id
                                  if (parentId) {
                                    const parentDs = DataSourceManager.getInstance().getDataSource(parentId)
                                    if (parentDs) tryClearSelection(parentDs)
                                  }
                                } catch {}
                              })
                              notifySelectionCleared()
                            } else {
                              // Pulisci tutte le selezioni precedenti su tutti i DS
                              Object.keys(dsDataRef.current).forEach(id => {
                                const e = dsDataRef.current[id]
                                if (e?.ds) tryClearSelection(e.ds)
                              })
                              notifySelectionCleared()
                              // Seleziona questo record sul suo DS nativo
                              setLocalSelectedByDs({ [recDsId]: rid })
                              const entry = dsDataRef.current[recDsId]
                              if (entry?.ds) trySelectRecord(entry.ds, r, rid)
                              // Notifica azioni del record selezionato
                              try {
                                const oidVal = Number(r.getData?.()[entry?.ds?.getIdField?.() || 'OBJECTID'] ?? rid)
                                sessionStorage.setItem('GII_SELECTED_OID', String(oidVal))
                                window.dispatchEvent(new CustomEvent('gii-selection-changed'))
                              } catch {}

                              // Propaga: forza setSelectedRecords con lo stesso record
                              // su TUTTI i DS del gruppo (ExB usa l'interfaccia DataRecord)
                              if (activeGroup) {
                                activeGroup.dsIndices.forEach(di => {
                                  const otherId = String(filteredUseDsJs[di]?.dataSourceId || '')
                                  if (otherId === recDsId) return
                                  const otherEntry = dsDataRef.current[otherId]
                                  if (otherEntry?.ds) {
                                    try { (otherEntry.ds as any).setSelectedRecords?.([r]) } catch {}
                                    try { (otherEntry.ds as any).selectRecordsByIds?.([rid]) } catch {}
                                  }
                                  // Anche sul parent DS (il feature layer principale)
                                  try {
                                    const mainDs = DataSourceManager.getInstance().getDataSource(otherId)
                                    const parentDs = (mainDs as any)?.parentDataSource || (mainDs as any)?.getMainDataSource?.()
                                    if (parentDs) {
                                      try { parentDs.setSelectedRecords?.([r]) } catch {}
                                    }
                                  } catch {}
                                })
                              }
                            }
                          }}
                        >
                          {columns.map((col, ci) => {
                            const f = col.field
                            if (f === V_STATO) {
                              return (
                                <div key={col.id} className={ci === 0 ? 'cell first' : 'cell'} title={statoLabel}>
                                  <span className='chip' style={getChipStyle(Number.isFinite(Number(statoChipNum)) ? Number(statoChipNum) : null)}>
                                    {statoLabel}
                                  </span>
                                </div>
                              )
                            }
                            if (f === V_ULTIMO) {
                              return <div key={col.id} className={ci === 0 ? 'cell first' : 'cell'} title={ultimo}>{ultimo}</div>
                            }
                            if (f === V_PROSSIMA) {
                              return <div key={col.id} className={ci === 0 ? 'cell first' : 'cell'} title={prossima}>{prossima}</div>
                            }
                            const fl = f.toLowerCase()
                            if (fl === 'objectid' || fl === 'oid' || fl === 'object_id') {
                              return <div key={col.id} className={ci === 0 ? 'cell first' : 'cell'} title={pratica}>{pratica}</div>
                            }
                            if (fl.startsWith('data_') || fl.startsWith('dt_')) {
                              const val = formatDateIt(d[f])
                              return <div key={col.id} className={ci === 0 ? 'cell first' : 'cell'} title={val}>{val}</div>
                            }
                            const val = txt(d[f])
                            return <div key={col.id} className={ci === 0 ? 'cell first' : 'cell'} title={val}>{val}</div>
                          })}
                        </div>
                      )
                    })}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}