/** @jsx jsx */
/** @jsxFrag React.Fragment */
import { React, jsx } from 'jimu-core'

type Props = {
  url: string | null
  fileName?: string
  title?: string
  subtitle?: string
  loading?: boolean
  error?: string | null
  emptyText?: string
  onDownload?: () => void
  onClose?: () => void
  style?: React.CSSProperties
}

function cleanPdfUrl (url?: string | null): string {
  return String(url || '').split('#')[0]
}

function fallbackFileName (url?: string | null, fileName?: string): string {
  const explicit = String(fileName || '').trim()
  if (explicit) return explicit.endsWith('.pdf') ? explicit : `${explicit}.pdf`
  const hash = String(url || '').split('#')[1]
  if (hash) return hash.endsWith('.pdf') ? hash : `${hash}.pdf`
  return 'rapporto.pdf'
}

function printPdfUrl (url?: string | null): void {
  const src = cleanPdfUrl(url)
  if (!src) return
  const iframe = document.createElement('iframe')
  iframe.style.position = 'fixed'
  iframe.style.right = '0'
  iframe.style.bottom = '0'
  iframe.style.width = '0'
  iframe.style.height = '0'
  iframe.style.border = '0'
  iframe.style.opacity = '0'
  iframe.src = src
  let printed = false
  const cleanup = () => {
    window.setTimeout(() => {
      try { iframe.remove() } catch {}
    }, 60000)
  }
  const doPrint = () => {
    if (printed) return
    printed = true
    try {
      iframe.contentWindow?.focus()
      iframe.contentWindow?.print()
    } catch {
      try { window.open(src, '_blank', 'noopener,noreferrer') } catch {}
    }
    cleanup()
  }
  iframe.onload = () => { window.setTimeout(doPrint, 300) }
  document.body.appendChild(iframe)
  window.setTimeout(doPrint, 1500)
}

function downloadPdfUrl (url?: string | null, fileName?: string): void {
  const src = cleanPdfUrl(url)
  if (!src) return
  const link = document.createElement('a')
  link.href = src
  link.download = fallbackFileName(url, fileName)
  link.rel = 'noopener noreferrer'
  document.body.appendChild(link)
  link.click()
  link.remove()
}

export default function RapportoPdfViewer (props: Props): any {
  const viewerRef = React.useRef<HTMLDivElement | null>(null)
  const url = props.url || null
  const fileName = fallbackFileName(url, props.fileName)

  const onDownload = React.useCallback(() => {
    if (!url) return
    if (props.onDownload) props.onDownload()
    else downloadPdfUrl(url, fileName)
  }, [fileName, props, url])

  const onPrint = React.useCallback(() => {
    if (!url) return
    printPdfUrl(url)
  }, [url])

  const onFullscreen = React.useCallback(async () => {
    try {
      const el = viewerRef.current
      if (!el) return
      const docAny = document as any
      const currentFs = document.fullscreenElement || docAny.webkitFullscreenElement || docAny.msFullscreenElement
      if (currentFs === el) {
        if (document.exitFullscreen) await document.exitFullscreen()
        else if (docAny.webkitExitFullscreen) await docAny.webkitExitFullscreen()
        else if (docAny.msExitFullscreen) await docAny.msExitFullscreen()
        return
      }
      const req = (el as any).requestFullscreen || (el as any).webkitRequestFullscreen || (el as any).msRequestFullscreen
      if (req) await req.call(el)
    } catch {}
  }, [])

  const showToolbar = !!url && !props.loading && !props.error

  return (
    <div
      ref={viewerRef}
      style={{
        width: '100%',
        height: '100%',
        minHeight: 0,
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box',
        borderRadius: 12,
        overflow: 'hidden',
        border: '1px solid rgba(255,255,255,0.12)',
        background: '#000',
        color: '#fff',
        ...(props.style || {})
      }}
    >
      {(props.title || props.subtitle) && (
        <div style={{ flex: '0 0 auto', padding: '10px 14px 6px', textAlign: 'center' }}>
          {props.title && <div style={{ fontSize: 13, fontWeight: 800, color: '#fff' }}>{props.title}</div>}
          {props.subtitle && <div style={{ marginTop: 2, fontSize: 11, color: 'rgba(255,255,255,0.70)', wordBreak: 'break-word' }}>{props.subtitle}</div>}
        </div>
      )}

      <div style={{ flex: '1 1 auto', minHeight: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000', padding: 0 }}>
        {props.loading && <div style={{ color: 'rgba(255,255,255,0.76)', fontSize: 14 }}>Generazione anteprima…</div>}
        {!props.loading && props.error && <div style={{ color: '#fca5a5', fontSize: 14, padding: 20, textAlign: 'center' }}>{props.error}</div>}
        {!props.loading && !props.error && !url && <div style={{ color: 'rgba(255,255,255,0.64)', fontSize: 14, padding: 20, textAlign: 'center' }}>{props.emptyText || 'Nessun dato disponibile per l\'anteprima.'}</div>}
        {!props.loading && !props.error && url && (
          <iframe
            src={url}
            title={props.title || 'Anteprima rapporto PDF'}
            style={{ width: '100%', height: '100%', flex: '1 1 auto', minHeight: 0, border: 'none', background: '#000' }}
          />
        )}
      </div>

      {showToolbar && (
        <div style={{ flex: '0 0 auto', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, flexWrap: 'wrap', padding: '9px 12px', background: '#2f2f2f', color: '#fff' }}>
          <button type='button' onClick={onDownload} style={btnStyle} title='Scarica PDF'>Scarica</button>
          <button type='button' onClick={onPrint} style={btnStyle} title='Stampa PDF'>Stampa</button>
          <button type='button' onClick={() => { void onFullscreen() }} style={btnStyle} title='Schermo intero'>Fullscreen</button>
          {props.onClose && <button type='button' onClick={props.onClose} style={btnStyle} title='Chiudi anteprima'>Chiudi</button>}
        </div>
      )}
    </div>
  )
}

const btnStyle: React.CSSProperties = {
  height: 30,
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 12,
  fontWeight: 800,
  color: '#fff',
  background: '#3b3b3b',
  border: '1px solid rgba(255,255,255,0.14)',
  borderRadius: 8,
  padding: '0 12px',
  cursor: 'pointer'
}
