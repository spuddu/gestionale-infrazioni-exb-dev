// =================================================================
// fascicolo-builder.ts
// PUNTO UNICO di costruzione del fascicolo documentale. Nessun widget deve
// costruire il PDF autonomamente: azioni, editing-ti ed editing-amm chiamano
// tutti buildFascicolo(...) con lo stesso oid e le stesse opzioni, e ottengono
// lo stesso identico risultato — a prescindere da dove è stato aperto.
//
// Principio: il builder non riceve mai 'data' da un widget. Fa lui stesso una
// query fresca e completa (con geometria) sul mother layer — confermato
// leggibile da tutti i ruoli, tecnici e amministrativi — eliminando alla
// radice il problema dei permessi differenziati per vista/area.
// =================================================================

import { PDFDocument } from 'pdf-lib'
import { buildPlaceholderMap, type UtenteCached } from './documenti-tecnici/rapporto/rapporto-placeholder-map'
import { applyNotaSpeseToRapportoMap, buildArt30RapportoSummary, type NotaSpeseConfig } from './documenti-tecnici/rapporto/rapporto-nota-spese-summary'
import { buildRapportoPdf, loadRapportoIterCicliForPdf, type RapportoIterCicloPdf } from './documenti-tecnici/rapporto/rapporto-pdf-builder'
import { buildNotaSpesePdf, type NotaSpeseData } from './documenti-tecnici/rapporto/notaspese-pdf-builder'
import { buildVerbalePdfBlob, type LayerFieldInfo } from './documenti-amministrativi/proposta-contestazione/proposta-contestazione-data-map'
import { RAPPORTO_TECHNICAL_BODY_BOX, drawRapportoTechnicalHeadersByPage, attachmentTechnicalDocumentTitle, wrapMapPdfBlobWithRapportoTechnicalHeader } from './documenti-tecnici/rapporto/technical-document-header'

// Mother layer: stesso URL usato da gii-editing-ti, confermato leggibile da
// tutti i ruoli (tecnici e amministrativi). Unica fonte dati del builder.
const FASCICOLO_MOTHER_LAYER_URL = 'https://services2.arcgis.com/vH5RykSdaAwiEGOJ/arcgis/rest/services/service_da9d790b10de4f2c82155df52d577055/FeatureServer/0'

let _cachedLayer: any = null

/** Risolve (una sola volta per sessione) il layer sorgente unico dei dati. */
async function resolveReadableLayer (): Promise<{ layer: any, url: string }> {
  if (_cachedLayer) return { layer: _cachedLayer, url: FASCICOLO_MOTHER_LAYER_URL }
  const FeatureLayer = await loadEsriModule<any>('esri/layers/FeatureLayer')
  const layer = new FeatureLayer({ url: FASCICOLO_MOTHER_LAYER_URL })
  if (typeof layer.load === 'function') await layer.load()
  _cachedLayer = layer
  return { layer, url: FASCICOLO_MOTHER_LAYER_URL }
}

export type FascicoloDocumentSelection = {
  includeTecnici: boolean           // rapporto tecnico + mappa (se disponibile) + allegati
  includeAmministrativi: boolean    // proposta di contestazione (+ determinazione, quando implementata qui)
  includeMappa?: boolean            // default: true se includeTecnici e la geometria è disponibile
  includeRapporto?: boolean         // default: true — se false, la pagina del rapporto tecnico non viene inclusa (anche se nota spese/allegati sì)
  includeNotaSpese?: boolean        // default: true — se false, nessuna nota spesa viene inclusa
  selectedAttachmentIds?: number[]  // undefined = tutti gli allegati stampabili
  selectedNotaSpeseKeys?: Record<string, boolean> // undefined = tutte (solo se includeNotaSpese non è false)
}

export type FascicoloBuildParams = {
  oid: number
  profile: { username: string, fullName: string }
  selection: FascicoloDocumentSelection
  notaSpeseConfig?: NotaSpeseConfig
  mapConfig?: { printServiceUrl?: string, basemapId?: string }
  fileNamePrefix?: string // es. 'fascicolo' oppure 'documenti' — solo cosmetico, non cambia il contenuto
}

type AttachmentInfo = { id: number, name: string, contentType: string, url?: string }

function pickAttrCI (data: any, names: string[]): any {
  if (!data) return null
  for (const n of names) { if (data[n] != null && data[n] !== '') return data[n] }
  return null
}

function loadEsriModule<T = any> (path: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const req = (window as any).require
    if (!req) { reject(new Error('AMD require non disponibile')); return }
    req([path], (mod: T) => resolve(mod), (err: any) => reject(err))
  })
}

/** Recupera (senza sfidare l'utente) una credenziale già registrata da IdentityManager per l'URL indicato. */
async function getEsriTokenForUrl (url: string): Promise<string> {
  try {
    const IdentityManager = await loadEsriModule<any>('esri/identity/IdentityManager')
    const cred = IdentityManager?.findCredential?.(url) || IdentityManager?.findCredential?.(url.replace(/\/\d+$/, ''))
    return cred?.token ? String(cred.token) : ''
  } catch {
    return ''
  }
}

/** Appende il token già registrato all'URL, se disponibile, per evitare la sfida automatica di IdentityManager (che qui apre il banner nativo del browser invece di usare silenziosamente la sessione esistente). */
async function withToken (url: string): Promise<string> {
  const token = await getEsriTokenForUrl(url)
  if (!token) return url
  return `${url}${url.includes('?') ? '&' : '?'}token=${encodeURIComponent(token)}`
}

/** Query fresca e completa del record, con geometria e definizione campi (per alias/domini). Unica fonte dati per tutto il builder. */
async function queryFascicoloRecord (oid: number): Promise<{ attrs: Record<string, any>, geometry: any | null, fields: LayerFieldInfo[], resolvedUrl: string }> {
  const { layer, url } = await resolveReadableLayer()
  const idField = String(layer.objectIdField || 'OBJECTID')
  const res = await layer.queryFeatures({ where: `${idField} = ${Number(oid)}`, outFields: ['*'], returnGeometry: true, num: 1 })
  const feature = res?.features?.[0]
  if (!feature) throw new Error(`Pratica con OID ${oid} non trovata su ${url}.`)
  const fields: LayerFieldInfo[] = (layer.fields || []).map((f: any) => ({
    name: String(f.name), type: String(f.type || ''), alias: String(f.alias || f.name), domain: f.domain || null, editable: f.editable !== false
  }))
  return { attrs: feature.attributes || {}, geometry: feature.geometry || null, fields, resolvedUrl: url }
}

async function queryFascicoloAttachments (oid: number): Promise<{ attachments: AttachmentInfo[], resolvedUrl: string }> {
  const { layer, url } = await resolveReadableLayer()
  if (typeof layer.queryAttachments !== 'function') return { attachments: [], resolvedUrl: url }
  let res: any = null
  try {
    res = await layer.queryAttachments({ objectIds: [Number(oid)], returnMetadata: true, returnUrl: true })
  } catch {
    return { attachments: [], resolvedUrl: url }
  }
  const groups: any[] = Array.isArray(res) ? res : (Array.isArray(res?.attachmentGroups) ? res.attachmentGroups : [])
  const group = groups.find(g => Number(g?.parentObjectId ?? g?.objectId) === Number(oid)) || groups[0]
  const infos: any[] = group?.attachmentInfos || group?.infos || (Array.isArray(res) ? res : [])
  const attachments = infos.map((a: any) => ({
    id: Number(a.id ?? a.attachmentId),
    name: String(a.name ?? a.attachmentName ?? ''),
    contentType: String(a.contentType ?? ''),
    url: a.url ? String(a.url) : undefined
  })).filter((a: AttachmentInfo) => Number.isFinite(a.id))
  return { attachments, resolvedUrl: url }
}

async function fetchAttachmentBlob (att: AttachmentInfo, oid: number, resolvedUrl: string): Promise<Blob> {
  const raw = att.url || `${resolvedUrl}/${Number(oid)}/attachments/${att.id}`
  const url = await withToken(raw)
  const resp = await fetch(url, { credentials: 'omit' })
  if (!resp.ok) throw new Error(`Caricamento allegato fallito (HTTP ${resp.status}): ${att.name}`)
  return await resp.blob()
}

function isImageAttachment (att: AttachmentInfo): boolean {
  const ct = att.contentType.toLowerCase()
  const name = att.name.toLowerCase()
  return ct.includes('image') || /\.(jpe?g|png)$/i.test(name)
}

async function ensureUtentiCache (): Promise<Map<string, UtenteCached> | null> {
  try {
    const FeatureLayer = await loadEsriModule<any>('esri/layers/FeatureLayer')
    const layer = new FeatureLayer({ url: 'https://services2.arcgis.com/vH5RykSdaAwiEGOJ/arcgis/rest/services/GII_utenti/FeatureServer/0' })
    if (typeof layer.load === 'function') await layer.load()
    const res = await layer.queryFeatures({ where: '1=1', outFields: ['*'], returnGeometry: false })
    const map = new Map<string, UtenteCached>()
    for (const f of (res?.features || [])) {
      const a = f.attributes || {}
      const username = String(a.username || '').trim().toLowerCase()
      if (!username) continue
      map.set(username, a as UtenteCached)
    }
    return map
  } catch {
    return null
  }
}

async function buildRapportoSection (attrs: Record<string, any>, notaSpeseConfig: NotaSpeseConfig | undefined, selection: FascicoloDocumentSelection): Promise<Array<{ blob: Blob, fileName: string }>> {
  const items: Array<{ blob: Blob, fileName: string }> = []
  const [utentiCache, cicli] = await Promise.all([
    ensureUtentiCache(),
    loadRapportoIterCicliForPdf(pickAttrCI(attrs, ['globalid', 'GlobalID', 'GLOBALID'])).catch((): RapportoIterCicloPdf[] => [])
  ])
  const map = buildPlaceholderMap(attrs, utentiCache, cicli)
  const { selectedGroups } = await applyNotaSpeseToRapportoMap(map, attrs, notaSpeseConfig, {
    includeNotaSpese: selection.includeNotaSpese !== false,
    selectedNotaSpeseKeys: selection.selectedNotaSpeseKeys
  })
  const base = String(map.cod_pratica || 'rapporto').replace(/[^a-zA-Z0-9_-]/g, '_')
  if (selection.includeRapporto !== false) {
    const rapportoBytes = await buildRapportoPdf(map)
    items.push({ blob: new Blob([rapportoBytes as any], { type: 'application/pdf' }), fileName: `rapporto_tecnico_${base}.pdf` })
  }

  if (selectedGroups.length) {
    const art30Summary = buildArt30RapportoSummary(attrs)
    const luogoData = 'Cagliari, ' + new Date().toLocaleDateString('it-IT', { day: '2-digit', month: '2-digit', year: 'numeric' })
    for (let i = 0; i < selectedGroups.length; i++) {
      const group = selectedGroups[i]
      const nsData: NotaSpeseData = {
        cod_pratica: map.cod_pratica || '',
        area_label: map.area_label || '',
        settore_label: map.settore_label || '',
        codice_casistica: group.codiceCasistica,
        label_casistica: group.label,
        rows: group.rows,
        summary: group.summary,
        art30: group.codiceCasistica === 'C104_ATTREZZATURE_DANNEGGIATE' && art30Summary.hasData
          ? {
              rows: art30Summary.rows.map(row => ({
                codice: row.codice,
                descrizione: row.descrizione,
                quantita: row.quantita,
                valore_unitario: row.valoreUnitario,
                importo: row.importo ?? ((row.valoreUnitario ?? 0) * row.quantita)
              })),
              rimborso: art30Summary.rimborso,
              cauzione: art30Summary.cauzione,
              cauzione_quantita: art30Summary.cauzioneQuantita,
              cauzione_valore_unitario: art30Summary.cauzioneValoreUnitario,
              cauzione_unita_misura: art30Summary.cauzioneUnitaMisura,
              netto: art30Summary.netto
            }
          : null,
        luogo_data: luogoData,
        firma_nome: map.iter_compilazione_nome || map.generato_da || '',
        rapporto_respinto: map.rapporto_respinto,
        rapporto_approvato: map.rapporto_approvato,
        rapporto_istruttoria: map.rapporto_istruttoria
      } as any
      const bytes = await buildNotaSpesePdf(nsData)
      const suffix = selectedGroups.length > 1 ? `_nota_${i + 1}` : ''
      items.push({ blob: new Blob([bytes as any], { type: 'application/pdf' }), fileName: `nota_spese_${base}${suffix}.pdf` })
    }
  }
  return items
}

async function buildAllegatiSection (oid: number, selection: FascicoloDocumentSelection, numeroRapportoTecnico: string): Promise<{ blob: Blob, fileName: string } | null> {
  const { attachments: all, resolvedUrl } = await queryFascicoloAttachments(oid)
  const selected = selection.selectedAttachmentIds ? all.filter(a => selection.selectedAttachmentIds!.includes(a.id)) : all
  if (!selected.length) return null

  const out = await PDFDocument.create()
  let added = 0
  let imageIndex = 0
  const pageTitles: string[] = []
  for (const att of selected) {
    const blob = await fetchAttachmentBlob(att, oid, resolvedUrl)
    const bytes = new Uint8Array(await blob.arrayBuffer())
    if (att.contentType.toLowerCase().includes('pdf') || att.name.toLowerCase().endsWith('.pdf')) {
      const src = await PDFDocument.load(bytes)
      const pages = await out.copyPages(src, src.getPageIndices())
      pages.forEach(pg => { out.addPage(pg); added++; pageTitles.push('') })
    } else if (isImageAttachment(att)) {
      imageIndex++
      const img = (att.contentType.toLowerCase().includes('png') || att.name.toLowerCase().endsWith('.png'))
        ? await out.embedPng(bytes)
        : await out.embedJpg(bytes)
      const page = out.addPage([595.28, 841.89])
      const box = RAPPORTO_TECHNICAL_BODY_BOX
      const scale = Math.min(box.width / Math.max(1, img.width), box.height / Math.max(1, img.height))
      const w = img.width * scale
      const h = img.height * scale
      page.drawImage(img, { x: box.x + (box.width - w) / 2, y: box.y + (box.height - h) / 2, width: w, height: h })
      pageTitles.push(attachmentTechnicalDocumentTitle(imageIndex, numeroRapportoTecnico))
      added++
    }
  }
  if (!added) return null
  await drawRapportoTechnicalHeadersByPage(out, index => pageTitles[index] || attachmentTechnicalDocumentTitle(index + 1, numeroRapportoTecnico))
  const bytes = await out.save()
  return { blob: new Blob([bytes as any], { type: 'application/pdf' }), fileName: `allegati_${numeroRapportoTecnico}.pdf`.replace(/[^a-zA-Z0-9_.-]/g, '_') }
}

/**
 * Esporta la pagina mappa in modo interamente headless: nessuna MapView montata
 * necessaria. Costruisce una specifica webmap (basemap + un punto dalla geometria
 * del record) e la invia al servizio di stampa server-side.
 * Se mapConfig/geometria non sono disponibili, ritorna null (sezione omessa)
 * invece di far fallire l'intero fascicolo.
 */
async function buildMappaSection (geometry: any | null, mapConfig: { printServiceUrl?: string, basemapId?: string } | undefined, numeroRapportoTecnico: string): Promise<{ blob: Blob, fileName: string } | null> {
  const serviceUrl = String(mapConfig?.printServiceUrl || '').trim()
  if (!geometry || !serviceUrl) return null
  try {
    const print = await loadEsriModule<any>('esri/rest/print')
    const PrintTemplate = await loadEsriModule<any>('esri/rest/support/PrintTemplate')
    const PrintParameters = await loadEsriModule<any>('esri/rest/support/PrintParameters')

    const scale = 1000
    const halfExtentMeters = 50 // ~ scala 1:1000 su A4 ritratto
    const x = Number(geometry.x)
    const y = Number(geometry.y)
    const wkid = geometry.spatialReference?.wkid || 3857
    const webMapAsJSON = {
      mapOptions: {
        extent: { xmin: x - halfExtentMeters, ymin: y - halfExtentMeters, xmax: x + halfExtentMeters, ymax: y + halfExtentMeters, spatialReference: { wkid } },
        spatialReference: { wkid },
        scale
      },
      operationalLayers: [
        {
          id: 'gii-fascicolo-punto',
          title: 'Localizzazione rilevazione',
          featureCollection: {
            layers: [{
              layerDefinition: {
                geometryType: 'esriGeometryPoint',
                objectIdField: 'OBJECTID',
                fields: [{ name: 'OBJECTID', type: 'esriFieldTypeOID', alias: 'OBJECTID' }],
                drawingInfo: {
                  renderer: {
                    type: 'simple',
                    symbol: { type: 'esriSMS', style: 'esriSMSCircle', color: [255, 0, 0, 255], size: 8, outline: { color: [255, 255, 0, 255], width: 1 } }
                  }
                }
              },
              featureSet: {
                geometryType: 'esriGeometryPoint',
                features: [{ geometry: { x, y, spatialReference: { wkid } }, attributes: { OBJECTID: 1 } }]
              }
            }]
          }
        }
      ],
      baseMap: { baseMapLayers: [{ id: 'basemap', layerType: 'ArcGISTiledMapServiceLayer', url: 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer' }], title: 'Ortofoto' }
    }

    const template = new PrintTemplate({
      format: 'pdf',
      layout: 'A4 Portrait',
      layoutOptions: { titleText: '', authorText: '', copyrightText: '' },
      exportOptions: { dpi: 96 }
    })
    const params = new PrintParameters({ webMapAsJSON, template } as any)
    const result = await print.execute(serviceUrl, params)
    const url = String(result?.url || result?.href || '')
    if (!url) return null
    const resp = await fetch(url)
    if (!resp.ok) return null
    const rawBlob = await resp.blob()
    const wrapped = await wrapMapPdfBlobWithRapportoTechnicalHeader(rawBlob, `ELABORATO CARTOGRAFICO ALLEGATO AL RAPPORTO TECNICO DI RILEVAZIONE N. ${numeroRapportoTecnico}`, {
      scale,
      basemapLabel: 'Ortofoto',
      legendItems: [{ key: 'gii-marker-pratica', label: 'Localizzazione rilevazione', kind: 'point' }],
      sourceLayout: 'A4 Portrait'
    })
    return { blob: wrapped, fileName: `mappa_${numeroRapportoTecnico}.pdf`.replace(/[^a-zA-Z0-9_.-]/g, '_') }
  } catch {
    // Non blocca il resto del fascicolo se la mappa fallisce: sezione omessa.
    return null
  }
}

function getNumeroRapportoTecnico (attrs: Record<string, any>): string {
  return String(pickAttrCI(attrs, ['numero_rapporto_tecnico', 'n_rapporto']) || '').trim() || '-'
}

/**
 * Punto unico di generazione del fascicolo documentale. Chiamato identicamente
 * da editing-ti, editing-amm e azioni: nessuno di loro passa dati propri, solo
 * l'OID e le opzioni scelte dall'utente (selezione documenti/allegati/nota spese).
 */
export async function buildFascicolo (params: FascicoloBuildParams): Promise<{ blob: Blob, fileName: string }> {
  const { attrs, geometry, fields } = await queryFascicoloRecord(params.oid)
  const numeroRapportoTecnico = getNumeroRapportoTecnico(attrs)
  const items: Array<{ blob: Blob, fileName: string }> = []

  if (params.selection.includeTecnici) {
    const rapportoItems = await buildRapportoSection(attrs, params.notaSpeseConfig, params.selection)
    rapportoItems.forEach(item => items.push(item))

    const wantsMappa = params.selection.includeMappa !== false
    if (wantsMappa) {
      const mappaItem = await buildMappaSection(geometry, params.mapConfig, numeroRapportoTecnico)
      if (mappaItem) items.push(mappaItem)
    }

    const allegatiItem = await buildAllegatiSection(params.oid, params.selection, numeroRapportoTecnico)
    if (allegatiItem) items.push(allegatiItem)
  }

  if (params.selection.includeAmministrativi) {
    items.push(await buildVerbalePdfBlob(attrs, fields, params.profile))
  }

  if (!items.length) throw new Error('Nessun documento selezionato da includere nel fascicolo.')

  const blob = items.length === 1 ? items[0].blob : await mergePdfItems(items)
  const prefix = params.fileNamePrefix || 'fascicolo'
  const safe = String(numeroRapportoTecnico || params.oid).replace(/[^a-zA-Z0-9_-]/g, '_')
  return { blob, fileName: `${prefix}_${safe}.pdf` }
}

async function mergePdfItems (items: Array<{ blob: Blob, fileName: string }>): Promise<Blob> {
  const merged = await PDFDocument.create()
  for (const item of items) {
    const src = await PDFDocument.load(new Uint8Array(await item.blob.arrayBuffer()))
    const pages = await merged.copyPages(src, src.getPageIndices())
    pages.forEach(pg => merged.addPage(pg))
  }
  const bytes = await merged.save()
  return new Blob([bytes as any], { type: 'application/pdf' })
}
