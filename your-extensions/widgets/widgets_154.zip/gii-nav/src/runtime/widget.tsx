/** @jsx jsx */
/** @jsxFrag React.Fragment */
import { React, jsx, ReactRedux, type IMState, type AllWidgetProps, SessionManager, UrlManager, getAppStore } from 'jimu-core'
import type { IMConfig, NavItem } from '../config'
import { defaultConfig } from '../config'
import { buildNavItemsFromHome, resolvePageIdFromAppConfig } from '../home-card-colors'


const GII_PORTAL     = 'https://cbsm-hub.maps.arcgis.com'
const RUOLO_FULL:  Record<string, string> = {
  TR:'Tecnico Rilevatore', IT:'Istruttore tecnico', IA:'Istruttore amministrativo', CS:'Capo Settore',
  RIT:'Responsabile istruttoria tecnica', RIA:'Responsabile istruttoria amministrativa', DT:'Direttore Tecnico',
  DA:'Direttore Amministrativo', ADMIN:'Amministratore'
}
const AREA_LABEL: Record<number, string> = { 1:'AMM', 2:'AGR', 3:'TEC' }
const RUOLI_VALIDI = new Set(['TR', 'IT', 'IA', 'CS', 'RIT', 'RIA', 'DT', 'DA', 'ADMIN'])
const AREE_VALIDE = new Set(['AMM', 'AGR', 'TEC'])

function normCode(value: any): string {
  return String(value ?? '').trim().toUpperCase()
}

function normalizeRoleCode(value: any, isAdmin?: boolean): string {
  const direct = normCode(value).replace(/[\s-]+/g, '_')
  if (RUOLI_VALIDI.has(direct)) return direct
  if (isAdmin) return 'ADMIN'
  return ''
}

function normalizeAreaCode(value: any, numericFallback: any): string {
  const direct = normCode(value)
  if (AREE_VALIDE.has(direct)) return direct

  const legacy = numericFallback != null && numericFallback !== '' ? Number(numericFallback) : NaN
  if (Number.isFinite(legacy) && AREA_LABEL[legacy]) return AREA_LABEL[legacy]

  return ''
}

function resolveWorkflowRole(ruoloLabel: string, area: string): string {
  const role = normCode(ruoloLabel)
  const areaCode = normCode(area)
  if (role === 'IA') return 'IA'
  if (role === 'RIA') return 'RIA'
  return role
}

function normalizeSectorCode(value: any, numericFallback: any): string {
  const direct = normCode(value)
  if (direct) return direct

  const legacy = numericFallback != null && numericFallback !== '' ? Number(numericFallback) : NaN
  const legacyMap: Record<number, string> = { 1:'CR', 2:'GI', 3:'D1', 4:'D2', 5:'D3', 6:'D4', 7:'D5', 8:'D6', 9:'DS', 10:'D7' }
  return Number.isFinite(legacy) ? (legacyMap[legacy] || '') : ''
}

function isSignedIn(): boolean {
  try {
    const sm = SessionManager.getInstance()
    const session: any = sm?.getMainSession?.() || sm?.getSessionByUrl?.(GII_PORTAL)
    const u = session?.username || session?.userId || ''
    return !!u
  } catch { return false }
}

interface UserInfo { username: string; fullName: string; ruoloLabel: string; ruoloFull: string; area: string; settore: string; roleCodes: string[]; isAdmin: boolean }

async function loadUser(): Promise<UserInfo | null> {
  const cached: any = (window as any).__giiUserRole
  if (cached?.username) {
    const area = normalizeAreaCode(cached.areaCod ?? cached.area_cod ?? cached.areaLabel, cached.area)
    const rawRole = normalizeRoleCode(
      cached.profiloCod ?? cached.profilo_cod ?? cached.ruoloCod ?? cached.ruolo_cod,
      cached.isAdmin
    )
    const ruoloLabel = resolveWorkflowRole(rawRole, area)
    const settore = normalizeSectorCode(cached.settoreCod ?? cached.settore_cod ?? cached.settoreLabel, cached.settore)
    const isAdmin = cached.isAdmin === true || ruoloLabel === 'ADMIN'
    const profiloLabel = String(cached.profiloLabel || cached.profilo_label || '').trim()
    const roleCodes = new Set<string>()
    if (ruoloLabel) roleCodes.add(ruoloLabel)
    const assignments = Array.isArray(cached.assignments) ? cached.assignments : []
    assignments.forEach((assignment: any) => {
      const assignmentArea = normalizeAreaCode(assignment?.areaCod ?? assignment?.area_cod, assignment?.area)
      const assignmentRawRole = normalizeRoleCode(assignment?.profiloCod ?? assignment?.profilo_cod ?? assignment?.ruoloCod ?? assignment?.ruolo_cod, false)
      const assignmentRole = resolveWorkflowRole(assignmentRawRole, assignmentArea)
      if (assignmentRole) roleCodes.add(assignmentRole)
    })

    return {
      username: String(cached.username),
      fullName: String(cached.fullName || cached.full_name || cached.username),
      ruoloLabel,
      ruoloFull: profiloLabel || RUOLO_FULL[ruoloLabel] || ruoloLabel,
      area,
      settore,
      roleCodes: Array.from(roleCodes),
      isAdmin
    }
  }
  return null
}

/** Normalizza un valore configurato (name/id/url) e prova a ricavare il pageId reale */
function resolvePageId(pageTokenRaw: string): string | null {
  const tok0 = (pageTokenRaw || '').trim()
  if (!tok0) return null

  // Rimuove eventuali prefissi tipo "#", "#/", "/"
  let tok = tok0.replace(/^#+\/?/, '').replace(/^\/+/, '')

  // Accetta anche "page/<qualcosa>"
  if (tok.startsWith('page/')) tok = tok.slice(5)

  try {
    const state: any = getAppStore()?.getState?.()
    const appConfig: any = state?.appConfig
    const rawPages: any = appConfig?.pages ?? {}

    const pagesMap: Record<string, any> =
      rawPages?.asMutable ? rawPages.asMutable({ deep: true }) :
      rawPages?.toJS ? rawPages.toJS() :
      rawPages

    // 1) Se è già un pageId (chiave della mappa), ok
    if (pagesMap && pagesMap[tok]) return tok

    // 2) Prova a matchare per page.name (slug), historyLabels, title/label
    const hist = appConfig?.historyLabels?.page || {}
    for (const [pageId, pg] of Object.entries(pagesMap || {})) {
      if (!pg) continue
      if (pg.name === tok) return pageId
      if (hist && hist[pageId] === tok) return pageId
      if (pg.label === tok || pg.title === tok) return pageId
    }
  } catch { /* ignore */ }

  // 3) Fallback: non risolto
  return null
}

/** Naviga alla pagina usando UrlManager (metodo ufficiale ExB) */
function gotoPage(pageToken: string): void {
  const pageId = resolvePageId(pageToken)
  if (pageId) {
    UrlManager.getInstance().changePage(pageId)
    return
  }

  // Fallback "best effort" (se non troviamo il pageId)
  const clean = (pageToken || '').trim().replace(/^#+\/?/, '').replace(/^\/+/, '')
  const t = clean.startsWith('page/') ? clean.slice(5) : clean
  window.location.hash = `#/page/${t}`
}

// ── Icone ─────────────────────────────────────────────────────────────────────
const NAV_ICONS: Record<string, string> = {
  home:        `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
  elenco:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>`,
  regolamento: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4.4v15.8"/><path d="M12 4.4C9.2 2.8 5.8 2.3 2.6 3.2v15.9c3.3-.9 6.6-.4 9.4 1.2"/><path d="M12 4.4c2.8-1.6 6.2-2.1 9.4-1.2v15.9c-3.3-.9-6.6-.4-9.4 1.2"/></svg>`,
  guida:       `<svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><!-- Generator: Adobe Illustrator 29.1.0, SVG Export Plug-In . SVG Version: 2.1.0 Build 142) --><defs><style> .st0 { stroke-width: 1.8px; } .st0, .st1 { fill: none; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; } .st1 { stroke-width: 1.8px; } </style></defs><path class="st0" d="M12,19.5h-6.2c-1,0-1.8-.8-1.8-1.8V4.5c0-1.4,1.1-2.5,2.5-2.5h13.5v17.5h-4"/><path class="st0" d="M20,16H5.8c-1,0-1.8.8-1.8,1.8"/><polyline class="st0" points="12 16 12 22.5 14 20.8 16 22.5 16 16"/><g><line class="st1" x1="12.2" y1="8.9" x2="8" y2="13.2"/><path d="M14.5,4.1l-1.7,1.7.5,2,2,.5,1.7-1.7c.5,1.9-.6,3.8-2.5,4.3-1.9.5-3.8-.6-4.3-2.5-.5-1.9.6-3.8,2.5-4.3.6-.2,1.2-.2,1.8,0Z"/></g></svg>`,
  nuova:       `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>`,
  mappa:       `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/></svg>`,
  dashboard:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="13" width="8" height="8" rx="1.5"/><rect x="14" y="13" width="8" height="8" rx="1.5"/><rect x="2" y="3" width="8" height="8" rx="1.5"/><rect x="14" y="3" width="8" height="8" rx="1.5"/></svg>`,
  report:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>`,
  utenti:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="7" r="4"/><path d="M5.5 21a6.5 6.5 0 0 1 13 0"/></svg>`,
  gruppo:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="7" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><circle cx="17" cy="8" r="2.8"/><path d="M15.5 18.5a5 5 0 0 1 6 1.5"/></svg>`,
  prezzari:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><text x="12" y="16" text-anchor="middle" font-size="12" font-family="Arial, sans-serif" font-weight="700" fill="currentColor" stroke="none">€</text></svg>`,
  impostazioni:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.05.05a2 2 0 1 1-2.83 2.83l-.05-.05A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21a2 2 0 1 1-4 0v-.08A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.05.05a2 2 0 1 1-2.83-2.83l.05-.05A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H3a2 2 0 1 1 0-4h.08A1.7 1.7 0 0 0 4.6 8.6a1.7 1.7 0 0 0-.34-1.88l-.05-.05a2 2 0 1 1 2.83-2.83l.05.05A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V3a2 2 0 1 1 4 0v.08A1.7 1.7 0 0 0 15.4 4.6a1.7 1.7 0 0 0 1.88-.34l.05-.05a2 2 0 1 1 2.83 2.83l-.05.05A1.7 1.7 0 0 0 19.4 9c.25.36.6.6 1 .6h.1a2 2 0 1 1 0 4h-.08a1.7 1.7 0 0 0-1.02 1.4z"/></svg>`,
  allegati:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21.4 11.6l-8.8 8.8a6 6 0 0 1-8.5-8.5l9.4-9.4a4 4 0 0 1 5.7 5.7l-9.4 9.4a2 2 0 0 1-2.8-2.8l8.8-8.8"/></svg>`,
  calendario:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`,
  allarmi:     `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>`,
  archivio:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5" rx="1"/><line x1="10" y1="12" x2="14" y2="12"/></svg>`,
  ricerca:     `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  modifica:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>`,
  verbale:     `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h9l5 5v15H6z"/><polyline points="15 2 15 7 20 7"/><line x1="9" y1="12" x2="17" y2="12"/><line x1="9" y1="16" x2="17" y2="16"/><path d="M4 6v16h12"/></svg>`,
  tabelle:     `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>`,
  statistiche: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="20" x2="20" y2="20"/><rect x="6" y="11" width="3" height="7" rx="1"/><rect x="11" y="6" width="3" height="12" rx="1"/><rect x="16" y="3" width="3" height="15" rx="1"/></svg>`,
  documenti:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h8l4 4v14H7z"/><polyline points="15 3 15 7 19 7"/><path d="M5 7H4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h11"/></svg>`
}
const NAV_DEFAULT_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/></svg>`

// ── NavButton ─────────────────────────────────────────────────────────────────
function colorWithAlpha(color: string, factor: number): string {
  const s = String(color || '').trim()
  const f = Math.max(0, Math.min(1, factor))
  const rgba = s.match(/^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})(?:\s*,\s*([0-9.]+))?\s*\)$/i)
  if (rgba) {
    const a = rgba[4] == null ? 1 : Math.max(0, Math.min(1, Number(rgba[4])))
    return `rgba(${rgba[1]},${rgba[2]},${rgba[3]},${a * f})`
  }
  const hex = s.match(/^#([0-9a-f]{6})([0-9a-f]{2})?$/i)
  if (hex) {
    const rgb = hex[1]
    const a = hex[2] ? parseInt(hex[2], 16) / 255 : 1
    return `rgba(${parseInt(rgb.slice(0,2),16)},${parseInt(rgb.slice(2,4),16)},${parseInt(rgb.slice(4,6),16)},${a * f})`
  }
  return s
}

// Gruppi di pagine collegate da uno stesso nav orizzontale (es. Prezzari / Voci interne /
// Analisi prezzi / Parametri / Consultazione): per il nav verticale sono un'unica sezione.
function buildHorizontalNavPageGroups (appConfig: any): string[][] {
  const groups: string[][] = []
  try {
    const raw: any = appConfig?.widgets || {}
    const widgets: any = typeof raw?.asMutable === 'function' ? raw.asMutable({ deep: true }) : raw
    Object.values<any>(widgets || {}).forEach((w: any) => {
      if (!String(w?.uri || '').includes('gii-nav-orizzontale')) return
      const items: any[] = Array.isArray(w?.config?.items) ? w.config.items : []
      const pages = Array.from(new Set(items
        .map((it: any) => resolvePageIdFromAppConfig(appConfig, String(it?.hashPage || '')))
        .filter((x: any): x is string => !!x)))
      if (pages.length > 1) groups.push(pages)
    })
  } catch { /* ignore */ }
  return groups
}

function NavButton(p: { item: NavItem; cfg: any; idx: number; currentPageId: string | null; animate: boolean; active?: boolean }) {
  const { item, cfg, currentPageId, animate } = p
  const [hov, setHov] = React.useState(false)
  const itemPageId = item.hashPage ? resolvePageId(item.hashPage) : null
  const isActive = typeof p.active === 'boolean' ? p.active : (!!currentPageId && !!itemPageId && currentPageId === itemPageId)
  const hot = hov || isActive
  // Hover e Selezionata sono due stati indipendenti.
  // Nessun fallback: se i colori Selezionata non sono impostati nella Home,
  // lo stato selezionato resta trasparente finché l'utente non li definisce.
  const stateBg = isActive
    ? (String(item.colorBgSelected || '').trim() || 'transparent')
    : (hov ? item.colorBgHover : item.colorBgRest)
  const stateAccent = isActive
    ? (String(item.colorAccentSelected || '').trim() || 'transparent')
    : (hov ? item.colorAccent : 'rgba(255,255,255,0.10)')
  const itemText = `${item.id || ''} ${item.hashPage || ''} ${item.label || ''}`.toLowerCase()
  const iconKey =
    /guida\s+operativa|(^|[^a-z])guida([^a-z]|$)/.test(itemText) && (!item.icon || item.icon === 'nuova')
      ? 'guida'
      : (/regolamento/.test(itemText) && (!item.icon || item.icon === 'elenco') ? 'regolamento' : item.icon)
  const icon = NAV_ICONS[iconKey] || NAV_DEFAULT_ICON
  // Leggibilità: le vecchie istanze salvano ancora 14px/600 nel config.
  // Applichiamo una soglia minima a runtime senza richiedere di aggiornare
  // manualmente tutte le istanze già presenti nelle pagine.
  const effectiveLabelSize = Math.max(16, Number(cfg.labelSize) || 16)
  const effectiveLabelWeight = Math.max(700, Number(cfg.labelWeight) || 700)
  const iconBoxSize = 36
  const iconGlyphPadding = 5

  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      onClick={() => { if (item.hashPage) gotoPage(item.hashPage) }}
      style={{
        cursor: 'pointer',
        borderRadius: cfg.itemBorderRadius,
        border: `1.5px solid ${stateAccent}`,
        background: stateBg,
        backdropFilter: 'blur(12px)',
        padding: cfg.itemPadding,
        display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 12,
        transition: 'all 0.25s cubic-bezier(0.4,0,0.2,1)',
        boxShadow: hot ? `0 20px 40px rgba(0,0,0,0.3),0 0 0 1px ${colorWithAlpha(stateAccent, 0.27)}` : '0 4px 16px rgba(0,0,0,0.15)',
        ...(animate ? {
          animationName: 'fadeInUp', animationDuration: '0.5s',
          animationDelay: `${p.idx * 80}ms`, animationFillMode: 'both',
          animationTimingFunction: 'cubic-bezier(0.4,0,0.2,1)'
        } : {})
      }}>
      <div style={{
        width: iconBoxSize, height: iconBoxSize, borderRadius: 8, flexShrink: 0,
        background: hot ? colorWithAlpha(stateAccent, 0.24) : 'rgba(255,255,255,0.11)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: hot ? stateAccent : 'rgba(255,255,255,0.92)',
        transition: 'background 0.25s, color 0.25s', padding: iconGlyphPadding, boxSizing: 'border-box' as const
      }}>
        <div style={{ width: '100%', height: '100%' }} dangerouslySetInnerHTML={{ __html: icon }}/>
      </div>
      <span style={{
        fontFamily: cfg.labelFont, fontSize: effectiveLabelSize, fontWeight: effectiveLabelWeight,
        color: '#ffffff',
        transition: 'color 0.2s', textAlign: 'left', lineHeight: 1.28,
        letterSpacing: '0.01em', textShadow: '0 1px 1px rgba(0,0,0,0.20)'
      }}>
        {item.label}
      </span>
    </div>
  )
}


// ── Widget ────────────────────────────────────────────────────────────────────
type Props = AllWidgetProps<IMConfig>

export default function Widget(props: Props) {
  const cfg: any = { ...defaultConfig, ...(props.config as any) }

  // La Home è la fonte unica delle voci del menu. In Builder leggiamo la copia in editing,
  // così modifiche a etichetta, icona, colori, ordine, ruoli e visibilità si riflettono
  // immediatamente in tutte le istanze del nav senza doverle configurare una per una.
  const appConfig = ReactRedux.useSelector((state: IMState) => {
    const s: any = state as any
    return s?.appStateInBuilder?.appConfig ?? s?.appConfig
  })

  const homeItems = React.useMemo(() => buildNavItemsFromHome(appConfig), [appConfig])
  // Compatibilità di sicurezza: se la Home non è leggibile, non svuotiamo il menu.
  const effectiveItems: NavItem[] = homeItems.length
    ? homeItems
    : (Array.isArray(cfg.items) ? cfg.items : defaultConfig.items)

  // Pagina corrente dallo store Redux di ExB (reagisce a UrlManager.changePage)
  const currentPageId = ReactRedux.useSelector((state: IMState) => {
    const s: any = state
    return (s?.appRuntimeInfo?.currentPageId as string) ?? null
  })

  // ── Animazione cascata: solo se si arriva dalla Home ──
  // ExB tiene in vita i widget di pagine non correnti. Più istanze di
  // gii-nav reagiscono allo stesso cambio currentPageId. Solo l'istanza
  // VISIBILE (offsetParent !== null) deve consumare il flag.
  // useLayoutEffect esegue prima del paint → zero flash.
  const containerRef = React.useRef<HTMLDivElement>(null)
  const [animate, setAnimate] = React.useState(false)

  React.useLayoutEffect(() => {
    if (!currentPageId) return

    // Solo l'istanza visibile processa il flag
    const el = containerRef.current
    if (!el || el.offsetParent === null) return

    let fromHome = false
    try {
      const v = sessionStorage.getItem('GII_FROM_HOME')
      if (v) { sessionStorage.removeItem('GII_FROM_HOME'); fromHome = true }
    } catch { /* ignore */ }
    setAnimate(fromHome)
  }, [currentPageId])

  const [user,  setUser]  = React.useState<UserInfo | null>(null)
  const [uLoad, setULoad] = React.useState(true)

  React.useEffect(() => {
  let cancelled = false

  const apply = () => {
    loadUser().then(u => {
      if (cancelled) return
      if (u) {
        setUser(u)
        setULoad(false)
        return
      }
      if (!isSignedIn()) {
        setUser(null)
        setULoad(false)
      } else {
        setUser(null)
        setULoad(true)
      }
    })
  }

  apply()
  window.addEventListener('gii:userLoaded', apply)
  return () => {
    cancelled = true
    window.removeEventListener('gii:userLoaded', apply)
  }
}, [])


  const isVisible = (item: NavItem) => {
    if (!item.visible) return false
    if (item.roles.includes('*')) return true
    if (uLoad) return false
    if (!user) return false
    if (user.isAdmin) return true
    const effectiveRoles = user.roleCodes?.length ? user.roleCodes : [user.ruoloLabel]
    return item.roles.some(role => effectiveRoles.includes(role))
  }

  const visibleItems = [...effectiveItems]
    .sort((a, b) => a.order - b.order)
    .filter(isVisible)
  // Voce attiva: la pagina corrente; se nessuna voce punta a questa pagina, la voce della
  // stessa sezione (pagine collegate dal nav orizzontale), così "Gestione prezzari" resta
  // accesa anche passando a Voci interne, Analisi prezzi, ecc.
  const pageGroups = React.useMemo(() => buildHorizontalNavPageGroups(appConfig), [appConfig])
  const itemPage = (item: NavItem) => (item.hashPage ? resolvePageIdFromAppConfig(appConfig, item.hashPage) || resolvePageId(item.hashPage) : null)
  const exactActive = !!currentPageId && visibleItems.some(item => itemPage(item) === currentPageId)
  const currentGroup = currentPageId ? pageGroups.find(g => g.includes(currentPageId)) || null : null
  const isItemActive = (item: NavItem): boolean => {
    const pid = itemPage(item)
    if (!pid || !currentPageId) return false
    if (pid === currentPageId) return true
    return !exactActive && !!currentGroup && currentGroup.includes(pid)
  }
  const isHorizontal = cfg.direction === 'horizontal'
  const initialPadding = Number.isFinite(Number(cfg.initialPadding)) ? Number(cfg.initialPadding) : 8

  return (
    <div ref={containerRef} style={{
      width: '100%', height: '100%',
      display: 'flex',
      flexDirection: isHorizontal ? 'row' : 'column',
      gap: cfg.gap,
      paddingTop: isHorizontal ? 8 : initialPadding,
      paddingRight: 8,
      paddingBottom: 8,
      paddingLeft: isHorizontal ? initialPadding : 8,
      boxSizing: 'border-box', overflow: 'auto'
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;600;700&display=swap');
        @keyframes fadeInUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
      `}</style>
      {visibleItems.map((item, i) => (
        <NavButton key={item.id} item={item} cfg={cfg} idx={i} currentPageId={currentPageId} animate={animate} active={isItemActive(item)}/>
      ))}
    </div>
  )
}
